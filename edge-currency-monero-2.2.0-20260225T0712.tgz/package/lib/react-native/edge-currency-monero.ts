/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/@mymonero/mymonero-bigint/index.js":
/*!*********************************************************!*\
  !*** ./node_modules/@mymonero/mymonero-bigint/index.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, exports) => {

/*
	JavaScript BigInteger library version 0.9.1
	http://silentmatt.com/biginteger/

	Copyright (c) 2009 Matthew Crumley <email@matthewcrumley.com>
	Copyright (c) 2010,2011 by John Tobey <John.Tobey@gmail.com>
	Licensed under the MIT license.

	Support for arbitrary internal representation base was added by
	Vitaly Magerya.
*/
/*

This file has been modified by Paul Shapiro:

1. to bring in the function lowVal which was written by Lucas Jones
2. to expose CONSTRUCT

*/
/*
	File: biginteger.js

	Exports:

		 <BigInteger>
*/
(function (exports) {
  'use strict'
  /*
	Class: BigInteger
	An arbitrarily-large integer.

	<BigInteger> objects should be considered immutable. None of the "built-in"
	methods modify *this* or their arguments. All properties should be
	considered private.

	All the methods of <BigInteger> instances can be called "statically". The
	static versions are convenient if you don't already have a <BigInteger>
	object.

	As an example, these calls are equivalent.

	> BigInteger(4).multiply(5); // returns BigInteger(20);
	> BigInteger.multiply(4, 5); // returns BigInteger(20);

	> var a = 42;
	> var a = BigInteger.toJSValue("0b101010"); // Not completely useless...
*/

  var CONSTRUCT = {} // Unique token to call "private" version of constructor

  /*
	Constructor: BigInteger()
	Convert a value to a <BigInteger>.

	Although <BigInteger()> is the constructor for <BigInteger> objects, it is
	best not to call it as a constructor. If *n* is a <BigInteger> object, it is
	simply returned as-is. Otherwise, <BigInteger()> is equivalent to <parse>
	without a radix argument.

	> var n0 = BigInteger();	  // Same as <BigInteger.ZERO>
	> var n1 = BigInteger("123"); // Create a new <BigInteger> with value 123
	> var n2 = BigInteger(123);   // Create a new <BigInteger> with value 123
	> var n3 = BigInteger(n2);	// Return n2, unchanged

	The constructor form only takes an array and a sign. *n* must be an
	array of numbers in little-endian order, where each digit is between 0
	and BigInteger.base.  The second parameter sets the sign: -1 for
	negative, +1 for positive, or 0 for zero. The array is *not copied and
	may be modified*. If the array contains only zeros, the sign parameter
	is ignored and is forced to zero.

	> new BigInteger([5], -1): create a new BigInteger with value -5

	Parameters:

		n - Value to convert to a <BigInteger>.

	Returns:

		A <BigInteger> value.

	See Also:

		<parse>, <BigInteger>
*/
  function BigInteger (n, s, token) {
    if (token !== CONSTRUCT) {
      if (n instanceof BigInteger) {
        return n
      } else if (typeof n === 'undefined') {
        return ZERO
      }
      return BigInteger.parse(n)
    }

    n = n || [] // Provide the nullary constructor for subclasses.
    while (n.length && !n[n.length - 1]) {
      --n.length
    }
    this._d = n
    this._s = n.length ? (s || 1) : 0
  }
  BigInteger.CONSTRUCT = CONSTRUCT // added by PS to actually use the constructor

  BigInteger._construct = function (n, s) {
    return new BigInteger(n, s, CONSTRUCT)
  }

  // Base-10 speedup hacks in parse, toString, exp10 and log functions
  // require base to be a power of 10. 10^7 is the largest such power
  // that won't cause a precision loss when digits are multiplied.
  var BigInteger_base = 10000000
  var BigInteger_base_log10 = 7

  BigInteger.base = BigInteger_base
  BigInteger.base_log10 = BigInteger_base_log10

  var ZERO = new BigInteger([], 0, CONSTRUCT)
  // Constant: ZERO
  // <BigInteger> 0.
  BigInteger.ZERO = ZERO

  var ONE = new BigInteger([1], 1, CONSTRUCT)
  // Constant: ONE
  // <BigInteger> 1.
  BigInteger.ONE = ONE

  var M_ONE = new BigInteger(ONE._d, -1, CONSTRUCT)
  // Constant: M_ONE
  // <BigInteger> -1.
  BigInteger.M_ONE = M_ONE

  // Constant: _0
  // Shortcut for <ZERO>.
  BigInteger._0 = ZERO

  // Constant: _1
  // Shortcut for <ONE>.
  BigInteger._1 = ONE

  /*
	Constant: small
	Array of <BigIntegers> from 0 to 36.

	These are used internally for parsing, but useful when you need a "small"
	<BigInteger>.

	See Also:

		<ZERO>, <ONE>, <_0>, <_1>
*/
  BigInteger.small = [
    ZERO,
    ONE,
    /* Assuming BigInteger_base > 36 */
    new BigInteger([2], 1, CONSTRUCT),
    new BigInteger([3], 1, CONSTRUCT),
    new BigInteger([4], 1, CONSTRUCT),
    new BigInteger([5], 1, CONSTRUCT),
    new BigInteger([6], 1, CONSTRUCT),
    new BigInteger([7], 1, CONSTRUCT),
    new BigInteger([8], 1, CONSTRUCT),
    new BigInteger([9], 1, CONSTRUCT),
    new BigInteger([10], 1, CONSTRUCT),
    new BigInteger([11], 1, CONSTRUCT),
    new BigInteger([12], 1, CONSTRUCT),
    new BigInteger([13], 1, CONSTRUCT),
    new BigInteger([14], 1, CONSTRUCT),
    new BigInteger([15], 1, CONSTRUCT),
    new BigInteger([16], 1, CONSTRUCT),
    new BigInteger([17], 1, CONSTRUCT),
    new BigInteger([18], 1, CONSTRUCT),
    new BigInteger([19], 1, CONSTRUCT),
    new BigInteger([20], 1, CONSTRUCT),
    new BigInteger([21], 1, CONSTRUCT),
    new BigInteger([22], 1, CONSTRUCT),
    new BigInteger([23], 1, CONSTRUCT),
    new BigInteger([24], 1, CONSTRUCT),
    new BigInteger([25], 1, CONSTRUCT),
    new BigInteger([26], 1, CONSTRUCT),
    new BigInteger([27], 1, CONSTRUCT),
    new BigInteger([28], 1, CONSTRUCT),
    new BigInteger([29], 1, CONSTRUCT),
    new BigInteger([30], 1, CONSTRUCT),
    new BigInteger([31], 1, CONSTRUCT),
    new BigInteger([32], 1, CONSTRUCT),
    new BigInteger([33], 1, CONSTRUCT),
    new BigInteger([34], 1, CONSTRUCT),
    new BigInteger([35], 1, CONSTRUCT),
    new BigInteger([36], 1, CONSTRUCT)
  ]

  // Used for parsing/radix conversion
  BigInteger.digits = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('')

  /*
	Method: toString
	Convert a <BigInteger> to a string.

	When *base* is greater than 10, letters are upper case.

	Parameters:

		base - Optional base to represent the number in (default is base 10).
			   Must be between 2 and 36 inclusive, or an Error will be thrown.

	Returns:

		The string representation of the <BigInteger>.
*/
  BigInteger.prototype.toString = function (base) {
    base = +base || 10
    if (base < 2 || base > 36) {
      throw new Error('illegal radix ' + base + '.')
    }
    if (this._s === 0) {
      return '0'
    }
    if (base === 10) {
      var str = this._s < 0 ? '-' : ''
      str += this._d[this._d.length - 1].toString()
      for (var i = this._d.length - 2; i >= 0; i--) {
        var group = this._d[i].toString()
        while (group.length < BigInteger_base_log10) group = '0' + group
        str += group
      }
      return str
    } else {
      var numerals = BigInteger.digits
      base = BigInteger.small[base]
      var sign = this._s

      var n = this.abs()
      var digits = []
      var digit

      while (n._s !== 0) {
        var divmod = n.divRem(base)
        n = divmod[0]
        digit = divmod[1]
        // TODO: This could be changed to unshift instead of reversing at the end.
        // Benchmark both to compare speeds.
        digits.push(numerals[digit.valueOf()])
      }
      return (sign < 0 ? '-' : '') + digits.reverse().join('')
    }
  }

  // Verify strings for parsing
  BigInteger.radixRegex = [
    /^$/,
    /^$/,
    /^[01]*$/,
    /^[012]*$/,
    /^[0-3]*$/,
    /^[0-4]*$/,
    /^[0-5]*$/,
    /^[0-6]*$/,
    /^[0-7]*$/,
    /^[0-8]*$/,
    /^[0-9]*$/,
    /^[0-9aA]*$/,
    /^[0-9abAB]*$/,
    /^[0-9abcABC]*$/,
    /^[0-9a-dA-D]*$/,
    /^[0-9a-eA-E]*$/,
    /^[0-9a-fA-F]*$/,
    /^[0-9a-gA-G]*$/,
    /^[0-9a-hA-H]*$/,
    /^[0-9a-iA-I]*$/,
    /^[0-9a-jA-J]*$/,
    /^[0-9a-kA-K]*$/,
    /^[0-9a-lA-L]*$/,
    /^[0-9a-mA-M]*$/,
    /^[0-9a-nA-N]*$/,
    /^[0-9a-oA-O]*$/,
    /^[0-9a-pA-P]*$/,
    /^[0-9a-qA-Q]*$/,
    /^[0-9a-rA-R]*$/,
    /^[0-9a-sA-S]*$/,
    /^[0-9a-tA-T]*$/,
    /^[0-9a-uA-U]*$/,
    /^[0-9a-vA-V]*$/,
    /^[0-9a-wA-W]*$/,
    /^[0-9a-xA-X]*$/,
    /^[0-9a-yA-Y]*$/,
    /^[0-9a-zA-Z]*$/
  ]

  /*
	Function: parse
	Parse a string into a <BigInteger>.

	*base* is optional but, if provided, must be from 2 to 36 inclusive. If
	*base* is not provided, it will be guessed based on the leading characters
	of *s* as follows:

	- "0x" or "0X": *base* = 16
	- "0c" or "0C": *base* = 8
	- "0b" or "0B": *base* = 2
	- else: *base* = 10

	If no base is provided, or *base* is 10, the number can be in exponential
	form. For example, these are all valid:

	> BigInteger.parse("1e9");			  // Same as "1000000000"
	> BigInteger.parse("1.234*10^3");	   // Same as 1234
	> BigInteger.parse("56789 * 10 ** -2"); // Same as 567

	If any characters fall outside the range defined by the radix, an exception
	will be thrown.

	Parameters:

		s - The string to parse.
		base - Optional radix (default is to guess based on *s*).

	Returns:

		a <BigInteger> instance.
*/
  BigInteger.parse = function (s, base) {
    // Expands a number in exponential form to decimal form.
    // expandExponential("-13.441*10^5") === "1344100";
    // expandExponential("1.12300e-1") === "0.112300";
    // expandExponential(1000000000000000000000000000000) === "1000000000000000000000000000000";
    function expandExponential (str) {
      str = str.replace(/\s*[*xX]\s*10\s*(\^|\*\*)\s*/, 'e')

      return str.replace(/^([+\-])?(\d+)\.?(\d*)[eE]([+\-]?\d+)$/, function (x, s, n, f, c) {
        c = +c
        var l = c < 0
        var i = n.length + c
        x = (l ? n : f).length
        c = ((c = Math.abs(c)) >= x ? c - x + l : 0)
        var z = (new Array(c + 1)).join('0')
        var r = n + f
        return (s || '') + (l ? r = z + r : r += z).substr(0, i += l ? z.length : 0) + (i < r.length ? '.' + r.substr(i) : '')
      })
    }

    s = s.toString()
    if (typeof base === 'undefined' || +base === 10) {
      s = expandExponential(s)
    }

    var prefixRE
    if (typeof base === 'undefined') {
      prefixRE = '0[xcb]'
    } else if (base == 16) {
      prefixRE = '0x'
    } else if (base == 8) {
      prefixRE = '0c'
    } else if (base == 2) {
      prefixRE = '0b'
    } else {
      prefixRE = ''
    }
    var parts = new RegExp('^([+\\-]?)(' + prefixRE + ')?([0-9a-z]*)(?:\\.\\d*)?$', 'i').exec(s)
    if (parts) {
      var sign = parts[1] || '+'
      var baseSection = parts[2] || ''
      var digits = parts[3] || ''

      if (typeof base === 'undefined') {
        // Guess base
        if (baseSection === '0x' || baseSection === '0X') { // Hex
          base = 16
        } else if (baseSection === '0c' || baseSection === '0C') { // Octal
          base = 8
        } else if (baseSection === '0b' || baseSection === '0B') { // Binary
          base = 2
        } else {
          base = 10
        }
      } else if (base < 2 || base > 36) {
        throw new Error('Illegal radix ' + base + '.')
      }

      base = +base

      // Check for digits outside the range
      if (!(BigInteger.radixRegex[base].test(digits))) {
        throw new Error('Bad digit for radix ' + base)
      }

      // Strip leading zeros, and convert to array
      digits = digits.replace(/^0+/, '').split('')
      if (digits.length === 0) {
        return ZERO
      }

      // Get the sign (we know it's not zero)
      sign = (sign === '-') ? -1 : 1

      // Optimize 10
      if (base == 10) {
        var d = []
        while (digits.length >= BigInteger_base_log10) {
          d.push(parseInt(digits.splice(digits.length - BigInteger.base_log10, BigInteger.base_log10).join(''), 10))
        }
        d.push(parseInt(digits.join(''), 10))
        return new BigInteger(d, sign, CONSTRUCT)
      }

      // Do the conversion
      var d = ZERO
      base = BigInteger.small[base]
      var small = BigInteger.small
      for (var i = 0; i < digits.length; i++) {
        d = d.multiply(base).add(small[parseInt(digits[i], 36)])
      }
      return new BigInteger(d._d, sign, CONSTRUCT)
    } else {
      throw new Error('Invalid BigInteger format: ' + s)
    }
  }

  /*
	Function: add
	Add two <BigIntegers>.

	Parameters:

		n - The number to add to *this*. Will be converted to a <BigInteger>.

	Returns:

		The numbers added together.

	See Also:

		<subtract>, <multiply>, <quotient>, <next>
*/
  BigInteger.prototype.add = function (n) {
    if (this._s === 0) {
      return BigInteger(n)
    }

    n = BigInteger(n)
    if (n._s === 0) {
      return this
    }
    if (this._s !== n._s) {
      n = n.negate()
      return this.subtract(n)
    }

    var a = this._d
    var b = n._d
    var al = a.length
    var bl = b.length
    var sum = new Array(Math.max(al, bl) + 1)
    var size = Math.min(al, bl)
    var carry = 0
    var digit

    for (var i = 0; i < size; i++) {
      digit = a[i] + b[i] + carry
      sum[i] = digit % BigInteger_base
      carry = (digit / BigInteger_base) | 0
    }
    if (bl > al) {
      a = b
      al = bl
    }
    for (i = size; carry && i < al; i++) {
      digit = a[i] + carry
      sum[i] = digit % BigInteger_base
      carry = (digit / BigInteger_base) | 0
    }
    if (carry) {
      sum[i] = carry
    }

    for (; i < al; i++) {
      sum[i] = a[i]
    }

    return new BigInteger(sum, this._s, CONSTRUCT)
  }

  /*
	Function: negate
	Get the additive inverse of a <BigInteger>.

	Returns:

		A <BigInteger> with the same magnatude, but with the opposite sign.

	See Also:

		<abs>
*/
  BigInteger.prototype.negate = function () {
    return new BigInteger(this._d, (-this._s) | 0, CONSTRUCT)
  }

  /*
	Function: abs
	Get the absolute value of a <BigInteger>.

	Returns:

		A <BigInteger> with the same magnatude, but always positive (or zero).

	See Also:

		<negate>
*/
  BigInteger.prototype.abs = function () {
    return (this._s < 0) ? this.negate() : this
  }

  /*
	Function: subtract
	Subtract two <BigIntegers>.

	Parameters:

		n - The number to subtract from *this*. Will be converted to a <BigInteger>.

	Returns:

		The *n* subtracted from *this*.

	See Also:

		<add>, <multiply>, <quotient>, <prev>
*/
  BigInteger.prototype.subtract = function (n) {
    if (this._s === 0) {
      return BigInteger(n).negate()
    }

    n = BigInteger(n)
    if (n._s === 0) {
      return this
    }
    if (this._s !== n._s) {
      n = n.negate()
      return this.add(n)
    }

    var m = this
    // negative - negative => -|a| - -|b| => -|a| + |b| => |b| - |a|
    if (this._s < 0) {
      m = new BigInteger(n._d, 1, CONSTRUCT)
      n = new BigInteger(this._d, 1, CONSTRUCT)
    }

    // Both are positive => a - b
    var sign = m.compareAbs(n)
    if (sign === 0) {
      return ZERO
    } else if (sign < 0) {
      // swap m and n
      var t = n
      n = m
      m = t
    }

    // a > b
    var a = m._d
    var b = n._d
    var al = a.length
    var bl = b.length
    var diff = new Array(al) // al >= bl since a > b
    var borrow = 0
    var i
    var digit

    for (i = 0; i < bl; i++) {
      digit = a[i] - borrow - b[i]
      if (digit < 0) {
        digit += BigInteger_base
        borrow = 1
      } else {
        borrow = 0
      }
      diff[i] = digit
    }
    for (i = bl; i < al; i++) {
      digit = a[i] - borrow
      if (digit < 0) {
        digit += BigInteger_base
      } else {
        diff[i++] = digit
        break
      }
      diff[i] = digit
    }
    for (; i < al; i++) {
      diff[i] = a[i]
    }

    return new BigInteger(diff, sign, CONSTRUCT)
  };

  (function () {
    function addOne (n, sign) {
      var a = n._d
      var sum = a.slice()
      var carry = true
      var i = 0

      while (true) {
        var digit = (a[i] || 0) + 1
        sum[i] = digit % BigInteger_base
        if (digit <= BigInteger_base - 1) {
          break
        }
        ++i
      }

      return new BigInteger(sum, sign, CONSTRUCT)
    }

    function subtractOne (n, sign) {
      var a = n._d
      var sum = a.slice()
      var borrow = true
      var i = 0

      while (true) {
        var digit = (a[i] || 0) - 1
        if (digit < 0) {
          sum[i] = digit + BigInteger_base
        } else {
          sum[i] = digit
          break
        }
        ++i
      }

      return new BigInteger(sum, sign, CONSTRUCT)
    }

    /*
		Function: next
		Get the next <BigInteger> (add one).

		Returns:

			*this* + 1.

		See Also:

			<add>, <prev>
	*/
    BigInteger.prototype.next = function () {
      switch (this._s) {
        case 0:
          return ONE
        case -1:
          return subtractOne(this, -1)
          // case 1:
        default:
          return addOne(this, 1)
      }
    }

    /*
		Function: prev
		Get the previous <BigInteger> (subtract one).

		Returns:

			*this* - 1.

		See Also:

			<next>, <subtract>
	*/
    BigInteger.prototype.prev = function () {
      switch (this._s) {
        case 0:
          return M_ONE
        case -1:
          return addOne(this, -1)
          // case 1:
        default:
          return subtractOne(this, 1)
      }
    }
  })()

  /*
	Function: compareAbs
	Compare the absolute value of two <BigIntegers>.

	Calling <compareAbs> is faster than calling <abs> twice, then <compare>.

	Parameters:

		n - The number to compare to *this*. Will be converted to a <BigInteger>.

	Returns:

		-1, 0, or +1 if *|this|* is less than, equal to, or greater than *|n|*.

	See Also:

		<compare>, <abs>
*/
  BigInteger.prototype.compareAbs = function (n) {
    if (this === n) {
      return 0
    }

    if (!(n instanceof BigInteger)) {
      if (!isFinite(n)) {
        return (isNaN(n) ? n : -1)
      }
      n = BigInteger(n)
    }

    if (this._s === 0) {
      return (n._s !== 0) ? -1 : 0
    }
    if (n._s === 0) {
      return 1
    }

    var l = this._d.length
    var nl = n._d.length
    if (l < nl) {
      return -1
    } else if (l > nl) {
      return 1
    }

    var a = this._d
    var b = n._d
    for (var i = l - 1; i >= 0; i--) {
      if (a[i] !== b[i]) {
        return a[i] < b[i] ? -1 : 1
      }
    }

    return 0
  }

  /*
	Function: compare
	Compare two <BigIntegers>.

	Parameters:

		n - The number to compare to *this*. Will be converted to a <BigInteger>.

	Returns:

		-1, 0, or +1 if *this* is less than, equal to, or greater than *n*.

	See Also:

		<compareAbs>, <isPositive>, <isNegative>, <isUnit>
*/
  BigInteger.prototype.compare = function (n) {
    if (this === n) {
      return 0
    }

    n = BigInteger(n)

    if (this._s === 0) {
      return -n._s
    }

    if (this._s === n._s) { // both positive or both negative
      var cmp = this.compareAbs(n)
      return cmp * this._s
    } else {
      return this._s
    }
  }

  /*
	Function: isUnit
	Return true iff *this* is either 1 or -1.

	Returns:

		true if *this* compares equal to <BigInteger.ONE> or <BigInteger.M_ONE>.

	See Also:

		<isZero>, <isNegative>, <isPositive>, <compareAbs>, <compare>,
		<BigInteger.ONE>, <BigInteger.M_ONE>
*/
  BigInteger.prototype.isUnit = function () {
    return this === ONE ||
		this === M_ONE ||
		(this._d.length === 1 && this._d[0] === 1)
  }

  /*
	Function: multiply
	Multiply two <BigIntegers>.

	Parameters:

		n - The number to multiply *this* by. Will be converted to a
		<BigInteger>.

	Returns:

		The numbers multiplied together.

	See Also:

		<add>, <subtract>, <quotient>, <square>
*/
  BigInteger.prototype.multiply = function (n) {
    // TODO: Consider adding Karatsuba multiplication for large numbers
    if (this._s === 0) {
      return ZERO
    }

    n = BigInteger(n)
    if (n._s === 0) {
      return ZERO
    }
    if (this.isUnit()) {
      if (this._s < 0) {
        return n.negate()
      }
      return n
    }
    if (n.isUnit()) {
      if (n._s < 0) {
        return this.negate()
      }
      return this
    }
    if (this === n) {
      return this.square()
    }

    var r = (this._d.length >= n._d.length)
    var a = (r ? this : n)._d // a will be longer than b
    var b = (r ? n : this)._d
    var al = a.length
    var bl = b.length

    var pl = al + bl
    var partial = new Array(pl)
    var i
    for (i = 0; i < pl; i++) {
      partial[i] = 0
    }

    for (i = 0; i < bl; i++) {
      var carry = 0
      var bi = b[i]
      var jlimit = al + i
      var digit
      for (var j = i; j < jlimit; j++) {
        digit = partial[j] + bi * a[j - i] + carry
        carry = (digit / BigInteger_base) | 0
        partial[j] = (digit % BigInteger_base) | 0
      }
      if (carry) {
        digit = partial[j] + carry
        carry = (digit / BigInteger_base) | 0
        partial[j] = digit % BigInteger_base
      }
    }
    return new BigInteger(partial, this._s * n._s, CONSTRUCT)
  }

  // Multiply a BigInteger by a single-digit native number
  // Assumes that this and n are >= 0
  // This is not really intended to be used outside the library itself
  BigInteger.prototype.multiplySingleDigit = function (n) {
    if (n === 0 || this._s === 0) {
      return ZERO
    }
    if (n === 1) {
      return this
    }

    var digit
    if (this._d.length === 1) {
      digit = this._d[0] * n
      if (digit >= BigInteger_base) {
        return new BigInteger([(digit % BigInteger_base) | 0,
          (digit / BigInteger_base) | 0], 1, CONSTRUCT)
      }
      return new BigInteger([digit], 1, CONSTRUCT)
    }

    if (n === 2) {
      return this.add(this)
    }
    if (this.isUnit()) {
      return new BigInteger([n], 1, CONSTRUCT)
    }

    var a = this._d
    var al = a.length

    var pl = al + 1
    var partial = new Array(pl)
    for (var i = 0; i < pl; i++) {
      partial[i] = 0
    }

    var carry = 0
    for (var j = 0; j < al; j++) {
      digit = n * a[j] + carry
      carry = (digit / BigInteger_base) | 0
      partial[j] = (digit % BigInteger_base) | 0
    }
    if (carry) {
      partial[j] = carry
    }

    return new BigInteger(partial, 1, CONSTRUCT)
  }

  /*
	Function: square
	Multiply a <BigInteger> by itself.

	This is slightly faster than regular multiplication, since it removes the
	duplicated multiplcations.

	Returns:

		> this.multiply(this)

	See Also:
		<multiply>
*/
  BigInteger.prototype.square = function () {
    // Normally, squaring a 10-digit number would take 100 multiplications.
    // Of these 10 are unique diagonals, of the remaining 90 (100-10), 45 are repeated.
    // This procedure saves (N*(N-1))/2 multiplications, (e.g., 45 of 100 multiplies).
    // Based on code by Gary Darby, Intellitech Systems Inc., www.DelphiForFun.org

    if (this._s === 0) {
      return ZERO
    }
    if (this.isUnit()) {
      return ONE
    }

    var digits = this._d
    var length = digits.length
    var imult1 = new Array(length + length + 1)
    var product, carry, k
    var i

    // Calculate diagonal
    for (i = 0; i < length; i++) {
      k = i * 2
      product = digits[i] * digits[i]
      carry = (product / BigInteger_base) | 0
      imult1[k] = product % BigInteger_base
      imult1[k + 1] = carry
    }

    // Calculate repeating part
    for (i = 0; i < length; i++) {
      carry = 0
      k = i * 2 + 1
      for (var j = i + 1; j < length; j++, k++) {
        product = digits[j] * digits[i] * 2 + imult1[k] + carry
        carry = (product / BigInteger_base) | 0
        imult1[k] = product % BigInteger_base
      }
      k = length + i
      var digit = carry + imult1[k]
      carry = (digit / BigInteger_base) | 0
      imult1[k] = digit % BigInteger_base
      imult1[k + 1] += carry
    }

    return new BigInteger(imult1, 1, CONSTRUCT)
  }

  /*
	Function: quotient
	Divide two <BigIntegers> and truncate towards zero.

	<quotient> throws an exception if *n* is zero.

	Parameters:

		n - The number to divide *this* by. Will be converted to a <BigInteger>.

	Returns:

		The *this* / *n*, truncated to an integer.

	See Also:

		<add>, <subtract>, <multiply>, <divRem>, <remainder>
*/
  BigInteger.prototype.quotient = function (n) {
    return this.divRem(n)[0]
  }

  /*
	Function: divide
	Deprecated synonym for <quotient>.
*/
  BigInteger.prototype.divide = BigInteger.prototype.quotient

  /*
	Function: remainder
	Calculate the remainder of two <BigIntegers>.

	<remainder> throws an exception if *n* is zero.

	Parameters:

		n - The remainder after *this* is divided *this* by *n*. Will be
			converted to a <BigInteger>.

	Returns:

		*this* % *n*.

	See Also:

		<divRem>, <quotient>
*/
  BigInteger.prototype.remainder = function (n) {
    return this.divRem(n)[1]
  }

  /*
	Function: divRem
	Calculate the integer quotient and remainder of two <BigIntegers>.

	<divRem> throws an exception if *n* is zero.

	Parameters:

		n - The number to divide *this* by. Will be converted to a <BigInteger>.

	Returns:

		A two-element array containing the quotient and the remainder.

		> a.divRem(b)

		is exactly equivalent to

		> [a.quotient(b), a.remainder(b)]

		except it is faster, because they are calculated at the same time.

	See Also:

		<quotient>, <remainder>
*/
  BigInteger.prototype.divRem = function (n) {
    n = BigInteger(n)
    if (n._s === 0) {
      throw new Error('Divide by zero')
    }
    if (this._s === 0) {
      return [ZERO, ZERO]
    }
    if (n._d.length === 1) {
      return this.divRemSmall(n._s * n._d[0])
    }

    // Test for easy cases -- |n1| <= |n2|
    switch (this.compareAbs(n)) {
      case 0: // n1 == n2
        return [this._s === n._s ? ONE : M_ONE, ZERO]
      case -1: // |n1| < |n2|
        return [ZERO, this]
    }

    var sign = this._s * n._s
    var a = n.abs()
    var b_digits = this._d
    var b_index = b_digits.length
    var digits = n._d.length
    var quot = []
    var guess

    var part = new BigInteger([], 0, CONSTRUCT)

    while (b_index) {
      part._d.unshift(b_digits[--b_index])
      part = new BigInteger(part._d, 1, CONSTRUCT)

      if (part.compareAbs(n) < 0) {
        quot.push(0)
        continue
      }
      if (part._s === 0) {
        guess = 0
      } else {
        var xlen = part._d.length; var ylen = a._d.length
        var highx = part._d[xlen - 1] * BigInteger_base + part._d[xlen - 2]
        var highy = a._d[ylen - 1] * BigInteger_base + a._d[ylen - 2]
        if (part._d.length > a._d.length) {
          // The length of part._d can either match a._d length,
          // or exceed it by one.
          highx = (highx + 1) * BigInteger_base
        }
        guess = Math.ceil(highx / highy)
      }
      do {
        var check = a.multiplySingleDigit(guess)
        if (check.compareAbs(part) <= 0) {
          break
        }
        guess--
      } while (guess)

      quot.push(guess)
      if (!guess) {
        continue
      }
      var diff = part.subtract(check)
      part._d = diff._d.slice()
    }

    return [new BigInteger(quot.reverse(), sign, CONSTRUCT),
		   new BigInteger(part._d, this._s, CONSTRUCT)]
  }

  // Throws an exception if n is outside of (-BigInteger.base, -1] or
  // [1, BigInteger.base).  It's not necessary to call this, since the
  // other division functions will call it if they are able to.
  BigInteger.prototype.divRemSmall = function (n) {
    var r
    n = +n
    if (n === 0) {
      throw new Error('Divide by zero')
    }

    var n_s = n < 0 ? -1 : 1
    var sign = this._s * n_s
    n = Math.abs(n)

    if (n < 1 || n >= BigInteger_base) {
      throw new Error('Argument out of range')
    }

    if (this._s === 0) {
      return [ZERO, ZERO]
    }

    if (n === 1 || n === -1) {
      return [(sign === 1) ? this.abs() : new BigInteger(this._d, sign, CONSTRUCT), ZERO]
    }

    // 2 <= n < BigInteger_base

    // divide a single digit by a single digit
    if (this._d.length === 1) {
      var q = new BigInteger([(this._d[0] / n) | 0], 1, CONSTRUCT)
      r = new BigInteger([(this._d[0] % n) | 0], 1, CONSTRUCT)
      if (sign < 0) {
        q = q.negate()
      }
      if (this._s < 0) {
        r = r.negate()
      }
      return [q, r]
    }

    var digits = this._d.slice()
    var quot = new Array(digits.length)
    var part = 0
    var diff = 0
    var i = 0
    var guess

    while (digits.length) {
      part = part * BigInteger_base + digits[digits.length - 1]
      if (part < n) {
        quot[i++] = 0
        digits.pop()
        diff = BigInteger_base * diff + part
        continue
      }
      if (part === 0) {
        guess = 0
      } else {
        guess = (part / n) | 0
      }

      var check = n * guess
      diff = part - check
      quot[i++] = guess
      if (!guess) {
        digits.pop()
        continue
      }

      digits.pop()
      part = diff
    }

    r = new BigInteger([diff], 1, CONSTRUCT)
    if (this._s < 0) {
      r = r.negate()
    }
    return [new BigInteger(quot.reverse(), sign, CONSTRUCT), r]
  }

  /*
	Function: isEven
	Return true iff *this* is divisible by two.

	Note that <BigInteger.ZERO> is even.

	Returns:

		true if *this* is even, false otherwise.

	See Also:

		<isOdd>
*/
  BigInteger.prototype.isEven = function () {
    var digits = this._d
    return this._s === 0 || digits.length === 0 || (digits[0] % 2) === 0
  }

  /*
	Function: isOdd
	Return true iff *this* is not divisible by two.

	Returns:

		true if *this* is odd, false otherwise.

	See Also:

		<isEven>
*/
  BigInteger.prototype.isOdd = function () {
    return !this.isEven()
  }

  /*
	Function: sign
	Get the sign of a <BigInteger>.

	Returns:

		* -1 if *this* < 0
		* 0 if *this* == 0
		* +1 if *this* > 0

	See Also:

		<isZero>, <isPositive>, <isNegative>, <compare>, <BigInteger.ZERO>
*/
  BigInteger.prototype.sign = function () {
    return this._s
  }

  /*
	Function: isPositive
	Return true iff *this* > 0.

	Returns:

		true if *this*.compare(<BigInteger.ZERO>) == 1.

	See Also:

		<sign>, <isZero>, <isNegative>, <isUnit>, <compare>, <BigInteger.ZERO>
*/
  BigInteger.prototype.isPositive = function () {
    return this._s > 0
  }

  /*
	Function: isNegative
	Return true iff *this* < 0.

	Returns:

		true if *this*.compare(<BigInteger.ZERO>) == -1.

	See Also:

		<sign>, <isPositive>, <isZero>, <isUnit>, <compare>, <BigInteger.ZERO>
*/
  BigInteger.prototype.isNegative = function () {
    return this._s < 0
  }

  /*
	Function: isZero
	Return true iff *this* == 0.

	Returns:

		true if *this*.compare(<BigInteger.ZERO>) == 0.

	See Also:

		<sign>, <isPositive>, <isNegative>, <isUnit>, <BigInteger.ZERO>
*/
  BigInteger.prototype.isZero = function () {
    return this._s === 0
  }

  /*
	Function: exp10
	Multiply a <BigInteger> by a power of 10.

	This is equivalent to, but faster than

	> if (n >= 0) {
	>	 return this.multiply(BigInteger("1e" + n));
	> }
	> else { // n <= 0
	>	 return this.quotient(BigInteger("1e" + -n));
	> }

	Parameters:

		n - The power of 10 to multiply *this* by. *n* is converted to a
		javascipt number and must be no greater than <BigInteger.MAX_EXP>
		(0x7FFFFFFF), or an exception will be thrown.

	Returns:

		*this* * (10 ** *n*), truncated to an integer if necessary.

	See Also:

		<pow>, <multiply>
*/
  BigInteger.prototype.exp10 = function (n) {
    n = +n
    if (n === 0) {
      return this
    }
    if (Math.abs(n) > Number(MAX_EXP)) {
      throw new Error('exponent too large in BigInteger.exp10')
    }
    // Optimization for this == 0. This also keeps us from having to trim zeros in the positive n case
    if (this._s === 0) {
      return ZERO
    }
    if (n > 0) {
      var k = new BigInteger(this._d.slice(), this._s, CONSTRUCT)

      for (; n >= BigInteger_base_log10; n -= BigInteger_base_log10) {
        k._d.unshift(0)
      }
      if (n == 0) { return k }
      k._s = 1
      k = k.multiplySingleDigit(Math.pow(10, n))
      return (this._s < 0 ? k.negate() : k)
    } else if (-n >= this._d.length * BigInteger_base_log10) {
      return ZERO
    } else {
      var k = new BigInteger(this._d.slice(), this._s, CONSTRUCT)

      for (n = -n; n >= BigInteger_base_log10; n -= BigInteger_base_log10) {
        k._d.shift()
      }
      return (n == 0) ? k : k.divRemSmall(Math.pow(10, n))[0]
    }
  }

  /*
	Function: pow
	Raise a <BigInteger> to a power.

	In this implementation, 0**0 is 1.

	Parameters:

		n - The exponent to raise *this* by. *n* must be no greater than
		<BigInteger.MAX_EXP> (0x7FFFFFFF), or an exception will be thrown.

	Returns:

		*this* raised to the *nth* power.

	See Also:

		<modPow>
*/
  BigInteger.prototype.pow = function (n) {
    if (this.isUnit()) {
      if (this._s > 0) {
        return this
      } else {
        return BigInteger(n).isOdd() ? this : this.negate()
      }
    }

    n = BigInteger(n)
    if (n._s === 0) {
      return ONE
    } else if (n._s < 0) {
      if (this._s === 0) {
        throw new Error('Divide by zero')
      } else {
        return ZERO
      }
    }
    if (this._s === 0) {
      return ZERO
    }
    if (n.isUnit()) {
      return this
    }

    if (n.compareAbs(MAX_EXP) > 0) {
      throw new Error('exponent too large in BigInteger.pow')
    }
    var x = this
    var aux = ONE
    var two = BigInteger.small[2]

    while (n.isPositive()) {
      if (n.isOdd()) {
        aux = aux.multiply(x)
        if (n.isUnit()) {
          return aux
        }
      }
      x = x.square()
      n = n.quotient(two)
    }

    return aux
  }

  /*
	Function: modPow
	Raise a <BigInteger> to a power (mod m).

	Because it is reduced by a modulus, <modPow> is not limited by
	<BigInteger.MAX_EXP> like <pow>.

	Parameters:

		exponent - The exponent to raise *this* by. Must be positive.
		modulus - The modulus.

	Returns:

		*this* ^ *exponent* (mod *modulus*).

	See Also:

		<pow>, <mod>
*/
  BigInteger.prototype.modPow = function (exponent, modulus) {
    var result = ONE
    var base = this

    while (exponent.isPositive()) {
      if (exponent.isOdd()) {
        result = result.multiply(base).remainder(modulus)
      }

      exponent = exponent.quotient(BigInteger.small[2])
      if (exponent.isPositive()) {
        base = base.square().remainder(modulus)
      }
    }

    return result
  }

  /*
	Function: log
	Get the natural logarithm of a <BigInteger> as a native JavaScript number.

	This is equivalent to

	> Math.log(this.toJSValue())

	but handles values outside of the native number range.

	Returns:

		log( *this* )

	See Also:

		<toJSValue>
*/
  BigInteger.prototype.log = function () {
    switch (this._s) {
      case 0:	 return -Infinity
      case -1: return NaN
      default: // Fall through.
    }

    var l = this._d.length

    if (l * BigInteger_base_log10 < 30) {
      return Math.log(this.valueOf())
    }

    var N = Math.ceil(30 / BigInteger_base_log10)
    var firstNdigits = this._d.slice(l - N)
    return Math.log((new BigInteger(firstNdigits, 1, CONSTRUCT)).valueOf()) + (l - N) * Math.log(BigInteger_base)
  }

  /*
	Function: valueOf
	Convert a <BigInteger> to a native JavaScript integer.

	This is called automatically by JavaScipt to convert a <BigInteger> to a
	native value.

	Returns:

		> parseInt(this.toString(), 10)

	See Also:

		<toString>, <toJSValue>
*/
  BigInteger.prototype.valueOf = function () {
    return parseInt(this.toString(), 10)
  }

  /*
	Function: toJSValue
	Convert a <BigInteger> to a native JavaScript integer.

	This is the same as valueOf, but more explicitly named.

	Returns:

		> parseInt(this.toString(), 10)

	See Also:

		<toString>, <valueOf>
*/
  BigInteger.prototype.toJSValue = function () {
    return parseInt(this.toString(), 10)
  }

  /*
	Function: lowVal
	Author: Lucas Jones
*/
  BigInteger.prototype.lowVal = function () {
    return this._d[0] || 0
  }

  var MAX_EXP = BigInteger(0x7FFFFFFF)
  // Constant: MAX_EXP
  // The largest exponent allowed in <pow> and <exp10> (0x7FFFFFFF or 2147483647).
  BigInteger.MAX_EXP = MAX_EXP;

  (function () {
    function makeUnary (fn) {
      return function (a) {
        return fn.call(BigInteger(a))
      }
    }

    function makeBinary (fn) {
      return function (a, b) {
        return fn.call(BigInteger(a), BigInteger(b))
      }
    }

    function makeTrinary (fn) {
      return function (a, b, c) {
        return fn.call(BigInteger(a), BigInteger(b), BigInteger(c))
      }
    }

    (function () {
      var i, fn
      var unary = 'toJSValue,isEven,isOdd,sign,isZero,isNegative,abs,isUnit,square,negate,isPositive,toString,next,prev,log'.split(',')
      var binary = 'compare,remainder,divRem,subtract,add,quotient,divide,multiply,pow,compareAbs'.split(',')
      var trinary = ['modPow']

      for (i = 0; i < unary.length; i++) {
        fn = unary[i]
        BigInteger[fn] = makeUnary(BigInteger.prototype[fn])
      }

      for (i = 0; i < binary.length; i++) {
        fn = binary[i]
        BigInteger[fn] = makeBinary(BigInteger.prototype[fn])
      }

      for (i = 0; i < trinary.length; i++) {
        fn = trinary[i]
        BigInteger[fn] = makeTrinary(BigInteger.prototype[fn])
      }

      BigInteger.exp10 = function (x, n) {
        return BigInteger(x).exp10(n)
      }
    })()
  })()

  exports.BigInteger = BigInteger
})( true ? exports : 0)


/***/ }),

/***/ "./node_modules/@mymonero/mymonero-money-format/crypto_formatter.js":
/*!**************************************************************************!*\
  !*** ./node_modules/@mymonero/mymonero-money-format/crypto_formatter.js ***!
  \**************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const JSBigInt = (__webpack_require__(/*! @mymonero/mymonero-bigint */ "./node_modules/@mymonero/mymonero-bigint/index.js").BigInteger)
//
module.exports = function (currencyConfig) {
  // `currencyConfig` needs coinUnitPlaces, and coinSymbol
  var config = {} // shallow copy of initConfig
  {
    for (var key in currencyConfig) {
      config[key] = currencyConfig[key]
    }
    config.coinUnits = new JSBigInt(10).pow(config.coinUnitPlaces)
  }
  this.formatMoneyFull = function (units) {
    units = units.toString()
    var symbol = units[0] === '-' ? '-' : ''
    if (symbol === '-') {
      units = units.slice(1)
    }
    var decimal
    if (units.length >= config.coinUnitPlaces) {
      decimal = units.substr(
        units.length - config.coinUnitPlaces,
        config.coinUnitPlaces
      )
    } else {
      decimal = padLeft(units, config.coinUnitPlaces, '0')
    }
    return (
      symbol +
			(units.substr(0, units.length - config.coinUnitPlaces) || '0') +
			'.' +
			decimal
    )
  }

  this.formatMoneyFullSymbol = function (units) {
    return this.formatMoneyFull(units) + ' ' + config.coinSymbol
  }

  function padLeft (str, len, char) {
    while (str.length < len) str = char + str
    return str
  }
  function trimRight (str, char) {
    while (str[str.length - 1] == char) str = str.slice(0, -1)
    return str
  }
  this.formatMoney = function (units) {
    var f = trimRight(this.formatMoneyFull(units), '0')
    if (f[f.length - 1] === '.') {
      return f.slice(0, f.length - 1)
    }
    return f
  }

  this.formatMoneySymbol = function (units) {
    return this.formatMoney(units) + ' ' + config.coinSymbol
  }

  this.parseMoney = function (str) {
    if (!str) return JSBigInt.ZERO
    var negative = str[0] === '-'
    if (negative) {
      str = str.slice(1)
    }
    var decimalIndex = str.indexOf('.')
    if (decimalIndex == -1) {
      if (negative) {
        return JSBigInt.multiply(str, config.coinUnits).negate()
      }
      return JSBigInt.multiply(str, config.coinUnits)
    }
    if (decimalIndex + config.coinUnitPlaces + 1 < str.length) {
      str = str.substr(0, decimalIndex + config.coinUnitPlaces + 1)
    }
    if (negative) {
      return new JSBigInt(str.substr(0, decimalIndex))
        .exp10(config.coinUnitPlaces)
        .add(
          new JSBigInt(str.substr(decimalIndex + 1)).exp10(
            decimalIndex + config.coinUnitPlaces - str.length + 1
          )
        ).negate
    }
    return new JSBigInt(str.substr(0, decimalIndex))
      .exp10(config.coinUnitPlaces)
      .add(
        new JSBigInt(str.substr(decimalIndex + 1)).exp10(
          decimalIndex + config.coinUnitPlaces - str.length + 1
        )
      )
  }

  return this
}


/***/ }),

/***/ "./node_modules/@mymonero/mymonero-money-format/index.js":
/*!***************************************************************!*\
  !*** ./node_modules/@mymonero/mymonero-money-format/index.js ***!
  \***************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
// Copyright (c) 2014-2019, MyMonero.com
//
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without modification, are
// permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice, this list of
//	conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright notice, this list
//	of conditions and the following disclaimer in the documentation and/or other
//	materials provided with the distribution.
//
// 3. Neither the name of the copyright holder nor the names of its contributors may be
//	used to endorse or promote products derived from this software without specific
//	prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
// THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
// STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
// THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

//
const monero_config = __webpack_require__(/*! ./monero_config */ "./node_modules/@mymonero/mymonero-money-format/monero_config.js")
const money_format_utils = __webpack_require__(/*! ./crypto_formatter */ "./node_modules/@mymonero/mymonero-money-format/crypto_formatter.js")
const instance = money_format_utils(monero_config)
//
module.exports = instance

/***/ }),

/***/ "./node_modules/@mymonero/mymonero-money-format/monero_config.js":
/*!***********************************************************************!*\
  !*** ./node_modules/@mymonero/mymonero-money-format/monero_config.js ***!
  \***********************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
// Copyright (c) 2014-2019, MyMonero.com
//
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without modification, are
// permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice, this list of
//	conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright notice, this list
//	of conditions and the following disclaimer in the documentation and/or other
//	materials provided with the distribution.
//
// 3. Neither the name of the copyright holder nor the names of its contributors may be
//	used to endorse or promote products derived from this software without specific
//	prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
// THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
// STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
// THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

//
const JSBigInt = (__webpack_require__(/*! @mymonero/mymonero-bigint */ "./node_modules/@mymonero/mymonero-bigint/index.js").BigInteger)
//
module.exports = {
  // Number of atomic units in one unit of currency. e.g. 12 => 10^12 = 1000000000000
  coinUnitPlaces: 12,

  // Minimum number of confirmations for a transaction to show as confirmed
  txMinConfirms: 10,

  // Currency symbol
  coinSymbol: 'XMR',

  // OpenAlias prefix
  openAliasPrefix: 'xmr',

  // Currency name
  coinName: 'Monero',

  // Payment URI Prefix
  coinUriPrefix: 'monero:',

  // Dust threshold in atomic units
  // 2*10^9 used for choosing outputs/change - we decompose all the way down if the receiver wants now regardless of threshold
  dustThreshold: new JSBigInt('2000000000'),

  // Maximum block number, used for tx unlock time
  maxBlockNumber: 500000000,

  // Average block time in seconds, used for unlock time estimation
  avgBlockTime: 60
}


/***/ }),

/***/ "./src/MoneroEngine.ts":
/*!*****************************!*\
  !*** ./src/MoneroEngine.ts ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MoneroEngine: () => (/* binding */ MoneroEngine),
/* harmony export */   makeCurrencyEngine: () => (/* binding */ makeCurrencyEngine)
/* harmony export */ });
/* harmony import */ var biggystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! biggystring */ "./node_modules/biggystring/lib/src/index.js");
/* harmony import */ var biggystring__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(biggystring__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var edge_core_js_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! edge-core-js/types */ "./node_modules/edge-core-js/types.mjs");
/* harmony import */ var _moneroInfo__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./moneroInfo */ "./src/moneroInfo.ts");
/* harmony import */ var _MoneroLocalData__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./MoneroLocalData */ "./src/MoneroLocalData.ts");
/* harmony import */ var _moneroTypes__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./moneroTypes */ "./src/moneroTypes.ts");
/* harmony import */ var _MyMoneroApi__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./MyMoneroApi */ "./src/MyMoneroApi.ts");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./utils */ "./src/utils.ts");
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { var _i = arr && (typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]); if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/**
 * Created by paul on 7/7/17.
 */







var SYNC_INTERVAL_MILLISECONDS = 5000;
var SAVE_DATASTORE_MILLISECONDS = 10000; // const ADDRESS_QUERY_LOOKBACK_BLOCKS = '8' // ~ 2 minutes
// const ADDRESS_QUERY_LOOKBACK_BLOCKS = (4 * 60 * 24 * 7) // ~ one week

var PRIMARY_CURRENCY_TOKEN_ID = null; // Global throttle: max 1 onAddressesChecked per 500ms; ratio=1 always passes.

var lastSyncEmitTime = 0;
var MoneroEngine = /*#__PURE__*/function () {
  function MoneroEngine(env, tools, walletInfo, opts) {
    var _env$initOptions,
        _this = this;

    _classCallCheck(this, MoneroEngine);

    _defineProperty(this, "loginPromise", null);

    var callbacks = opts.callbacks,
        _opts$userSettings = opts.userSettings,
        userSettings = _opts$userSettings === void 0 ? {} : _opts$userSettings,
        walletLocalDisklet = opts.walletLocalDisklet;
    var initOptions = (0,_moneroTypes__WEBPACK_IMPORTED_MODULE_4__.asMoneroInitOptions)((_env$initOptions = env.initOptions) !== null && _env$initOptions !== void 0 ? _env$initOptions : {});
    var networkInfo = tools.networkInfo;
    this.apiKey = initOptions.edgeApiKey;
    this.io = env.io;
    this.log = opts.log;
    this.engineOn = false;
    this.loggedIn = false;
    this.addressesChecked = false;
    this.walletLocalDataDirty = false;
    this.transactionEventArray = [];
    this.walletInfo = walletInfo; // We derive the public keys at init

    this.walletId = walletInfo.id;
    this.currencyInfo = _moneroInfo__WEBPACK_IMPORTED_MODULE_2__.currencyInfo;
    this.currencyTools = tools; // this.customTokens = []

    this.timers = {};
    this.currentSettings = _objectSpread(_objectSpread({}, _moneroInfo__WEBPACK_IMPORTED_MODULE_2__.currencyInfo.defaultSettings), (0,_moneroTypes__WEBPACK_IMPORTED_MODULE_4__.asMoneroUserSettings)(userSettings));

    this.engineFetch = /*#__PURE__*/function () {
      var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(uri, init) {
        var networkPrivacy;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                networkPrivacy = _this.currentSettings.networkPrivacy;
                _context.next = 3;
                return _this.io.fetch(uri, _objectSpread(_objectSpread({}, networkPrivacy === 'nym' ? {
                  privacy: 'nym'
                } : {}), init));

              case 3:
                return _context.abrupt("return", _context.sent);

              case 4:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }));

      return function (_x, _x2) {
        return _ref.apply(this, arguments);
      };
    }();

    this.myMoneroApi = new _MyMoneroApi__WEBPACK_IMPORTED_MODULE_5__.MyMoneroApi(tools.cppBridge, {
      apiKey: initOptions.edgeApiKey,
      apiServer: networkInfo.defaultServer,
      fetch: this.engineFetch,
      nettype: networkInfo.nettype
    });
    this.seenTxCheckpoint = (0,_moneroTypes__WEBPACK_IMPORTED_MODULE_4__.asSeenTxCheckpoint)(opts.seenTxCheckpoint);

    if (this.currentSettings.enableCustomServers && this.currentSettings.moneroLightwalletServer != null) {
      this.myMoneroApi.changeServer(this.currentSettings.moneroLightwalletServer, '');
    }

    this.edgeTxLibCallbacks = callbacks;
    this.walletLocalDisklet = walletLocalDisklet;
    this.log("Created Wallet Type ".concat(this.walletInfo.type, " for Currency Plugin ").concat(this.currencyInfo.pluginId, " "));
  }

  _createClass(MoneroEngine, [{
    key: "init",
    value: function () {
      var _init = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
        var safeWalletInfo;
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.next = 2;
                return (0,_moneroTypes__WEBPACK_IMPORTED_MODULE_4__.makeSafeWalletInfo)(this.currencyTools, this.walletInfo);

              case 2:
                safeWalletInfo = _context2.sent;
                this.walletInfo.keys = _objectSpread(_objectSpread({}, this.walletInfo.keys), safeWalletInfo.keys);

              case 4:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      function init() {
        return _init.apply(this, arguments);
      }

      return init;
    }()
  }, {
    key: "updateOnAddressesChecked",
    value: function updateOnAddressesChecked(numTx, totalTxs) {
      if (this.addressesChecked) {
        return;
      }

      if (numTx !== totalTxs) {
        var now = Date.now();
        if (now - lastSyncEmitTime < 500) return;
        lastSyncEmitTime = now;
        var progress = numTx / totalTxs;
        this.edgeTxLibCallbacks.onAddressesChecked(progress);
      } else {
        this.addressesChecked = true;
        this.edgeTxLibCallbacks.onAddressesChecked(1);
        this.walletLocalData.lastAddressQueryHeight = this.walletLocalData.blockHeight;
      }
    } // **********************************************
    // Login to mymonero.com server
    // **********************************************

  }, {
    key: "loginIfNewAddress",
    value: function () {
      var _loginIfNewAddress = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(privateKeys) {
        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                if (!(this.loginPromise != null)) {
                  _context3.next = 4;
                  break;
                }

                _context3.next = 3;
                return this.loginPromise;

              case 3:
                return _context3.abrupt("return", _context3.sent);

              case 4:
                this.loginPromise = this.performLogin(privateKeys);
                _context3.prev = 5;
                _context3.next = 8;
                return this.loginPromise;

              case 8:
                _context3.prev = 8;
                // Clear the promise once completed (success OR failure)
                this.loginPromise = null;
                return _context3.finish(8);

              case 11:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this, [[5,, 8, 11]]);
      }));

      function loginIfNewAddress(_x3) {
        return _loginIfNewAddress.apply(this, arguments);
      }

      return loginIfNewAddress;
    }()
  }, {
    key: "performLogin",
    value: function () {
      var _performLogin = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(privateKeys) {
        var result;
        return regeneratorRuntime.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.prev = 0;
                _context4.next = 3;
                return this.myMoneroApi.login({
                  address: this.walletInfo.keys.moneroAddress,
                  privateViewKey: this.walletInfo.keys.moneroViewKeyPrivate,
                  privateSpendKey: privateKeys.moneroSpendKeyPrivate,
                  publicSpendKey: privateKeys.moneroSpendKeyPublic
                });

              case 3:
                result = _context4.sent;

                if ('new_address' in result && !this.loggedIn) {
                  this.loggedIn = true;
                  this.walletLocalData.hasLoggedIn = true; // eslint-disable-next-line @typescript-eslint/no-floating-promises

                  this.addToLoop('saveWalletLoop', SAVE_DATASTORE_MILLISECONDS);
                  this.edgeTxLibCallbacks.onAddressChanged();
                }

                _context4.next = 10;
                break;

              case 7:
                _context4.prev = 7;
                _context4.t0 = _context4["catch"](0);
                this.log.error('Error logging into mymonero', _context4.t0);

              case 10:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this, [[0, 7]]);
      }));

      function performLogin(_x4) {
        return _performLogin.apply(this, arguments);
      }

      return performLogin;
    }() // ***************************************************
    // Check address for updated block height and balance
    // ***************************************************

  }, {
    key: "checkAddressInnerLoop",
    value: function () {
      var _checkAddressInnerLoop = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5(privateKeys) {
        var addrResult, nativeBalance;
        return regeneratorRuntime.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                _context5.prev = 0;
                _context5.next = 3;
                return this.myMoneroApi.getAddressInfo({
                  address: this.walletInfo.keys.moneroAddress,
                  privateViewKey: this.walletInfo.keys.moneroViewKeyPrivate,
                  privateSpendKey: privateKeys.moneroSpendKeyPrivate,
                  publicSpendKey: privateKeys.moneroSpendKeyPublic
                });

              case 3:
                addrResult = _context5.sent;

                if (this.walletLocalData.blockHeight !== addrResult.blockHeight) {
                  this.walletLocalData.blockHeight = addrResult.blockHeight; // Convert to decimal

                  this.walletLocalDataDirty = true;
                  this.edgeTxLibCallbacks.onBlockHeightChanged(this.walletLocalData.blockHeight);
                }

                nativeBalance = (0,biggystring__WEBPACK_IMPORTED_MODULE_0__.sub)(addrResult.totalReceived, addrResult.totalSent);

                if (this.walletLocalData.totalBalances.get(PRIMARY_CURRENCY_TOKEN_ID) !== nativeBalance) {
                  this.walletLocalData.totalBalances.set(PRIMARY_CURRENCY_TOKEN_ID, nativeBalance);
                  this.edgeTxLibCallbacks.onTokenBalanceChanged(PRIMARY_CURRENCY_TOKEN_ID, nativeBalance);
                }

                this.walletLocalData.lockedXmrBalance = addrResult.lockedBalance;
                _context5.next = 13;
                break;

              case 10:
                _context5.prev = 10;
                _context5.t0 = _context5["catch"](0);
                this.log.error("Error fetching address info: ".concat(this.walletInfo.keys.moneroAddress, " ").concat(String(_context5.t0)));

              case 13:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, this, [[0, 10]]);
      }));

      function checkAddressInnerLoop(_x5) {
        return _checkAddressInnerLoop.apply(this, arguments);
      }

      return checkAddressInnerLoop;
    }()
  }, {
    key: "processMoneroTransaction",
    value: function processMoneroTransaction(tx) {
      var ourReceiveAddresses = [];
      var nativeNetworkFee = tx.fee != null ? tx.fee : '0';
      var netNativeAmount = (0,biggystring__WEBPACK_IMPORTED_MODULE_0__.sub)(tx.total_received, tx.total_sent);

      if (netNativeAmount.slice(0, 1) !== '-') {
        ourReceiveAddresses.push(this.walletInfo.keys.moneroAddress.toLowerCase());
      }

      var blockHeight = tx.height == null || tx.mempool ? 0 : tx.height;
      var date = tx.timestamp == null ? new Date() : new Date(tx.timestamp); // Expose legacy payment ID's to the GUI. This only applies
      // to really old transactions, before integrated addresses:

      var memos = [];

      if (tx.payment_id != null) {
        memos.push({
          memoName: 'payment id',
          type: 'hex',
          value: tx.payment_id
        });
      }

      var edgeTransaction = {
        blockHeight: blockHeight,
        currencyCode: 'XMR',
        date: date.valueOf() / 1000,
        isSend: (0,biggystring__WEBPACK_IMPORTED_MODULE_0__.lt)(netNativeAmount, '0'),
        memos: memos,
        nativeAmount: netNativeAmount,
        networkFee: nativeNetworkFee,
        networkFees: [{
          tokenId: null,
          nativeAmount: nativeNetworkFee
        }],
        otherParams: {},
        ourReceiveAddresses: ourReceiveAddresses,
        signedTx: '',
        tokenId: null,
        txid: tx.hash,
        walletId: this.walletId
      };
      this.saveTransactionState(PRIMARY_CURRENCY_TOKEN_ID, edgeTransaction);

      if (this.transactionEventArray.length > 0) {
        this.edgeTxLibCallbacks.onTransactions(this.transactionEventArray);
        this.transactionEventArray = [];
      }

      return blockHeight;
    }
  }, {
    key: "checkTransactionsInnerLoop",
    value: function () {
      var _checkTransactionsInnerLoop = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee6(privateKeys) {
        var _this$seenTxCheckpoin, seenTxCheckpoint, transactions, i, tx, blockHeight, newCheckpoint, oldCheckpoint;

        return regeneratorRuntime.wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                _context6.prev = 0;
                // Let the seenTxCheckpoint be defined before querying transactions.
                seenTxCheckpoint = (_this$seenTxCheckpoin = this.seenTxCheckpoint) !== null && _this$seenTxCheckpoin !== void 0 ? _this$seenTxCheckpoin : 0;
                _context6.next = 4;
                return this.myMoneroApi.getTransactions({
                  address: this.walletInfo.keys.moneroAddress,
                  privateViewKey: this.walletInfo.keys.moneroViewKeyPrivate,
                  privateSpendKey: privateKeys.moneroSpendKeyPrivate,
                  publicSpendKey: privateKeys.moneroSpendKeyPublic
                });

              case 4:
                transactions = _context6.sent;
                this.log("Fetched transactions count: ".concat(transactions.length)); // Get transactions
                // Iterate over transactions in address

                for (i = 0; i < transactions.length; i++) {
                  tx = transactions[i];
                  blockHeight = this.processMoneroTransaction(tx);
                  seenTxCheckpoint = Math.max(seenTxCheckpoint, blockHeight);

                  if (i % 10 === 0) {
                    this.updateOnAddressesChecked(i, transactions.length);
                  }
                }

                this.updateOnAddressesChecked(transactions.length, transactions.length); // Only update the seenTxCheckpoint if it actually advanced:

                newCheckpoint = (0,_moneroTypes__WEBPACK_IMPORTED_MODULE_4__.wasSeenTxCheckpoint)(seenTxCheckpoint);
                oldCheckpoint = (0,_moneroTypes__WEBPACK_IMPORTED_MODULE_4__.wasSeenTxCheckpoint)(this.seenTxCheckpoint);

                if (newCheckpoint !== oldCheckpoint) {
                  this.seenTxCheckpoint = seenTxCheckpoint;
                  this.edgeTxLibCallbacks.onSeenTxCheckpoint(newCheckpoint);
                }

                _context6.next = 16;
                break;

              case 13:
                _context6.prev = 13;
                _context6.t0 = _context6["catch"](0);
                this.log.error('checkTransactionsInnerLoop', _context6.t0);

              case 16:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6, this, [[0, 13]]);
      }));

      function checkTransactionsInnerLoop(_x6) {
        return _checkTransactionsInnerLoop.apply(this, arguments);
      }

      return checkTransactionsInnerLoop;
    }()
  }, {
    key: "findTransaction",
    value: function findTransaction(tokenId, txid) {
      var txs = this.getTxs(tokenId);
      return txs.findIndex(function (element) {
        return (0,_utils__WEBPACK_IMPORTED_MODULE_6__.normalizeAddress)(element.txid) === (0,_utils__WEBPACK_IMPORTED_MODULE_6__.normalizeAddress)(txid);
      });
    }
  }, {
    key: "sortTxByDate",
    value: function sortTxByDate(a, b) {
      return b.date - a.date;
    }
  }, {
    key: "getTxs",
    value: function getTxs(tokenId) {
      var txs = this.walletLocalData.transactionsObj.get(tokenId);

      if (txs == null) {
        var _txs = [];
        this.walletLocalData.transactionsObj.set(tokenId, _txs);
        return _txs;
      }

      return txs;
    }
  }, {
    key: "saveTransactionState",
    value: function saveTransactionState(tokenId, edgeTransaction) {
      // Add or update tx in transactionsObj
      var idx = this.findTransaction(tokenId, edgeTransaction.txid);

      if (idx === -1) {
        this.log("New transaction: ".concat(edgeTransaction.txid));
        this.log.warn('addTransaction: adding and sorting:' + edgeTransaction.txid + edgeTransaction.nativeAmount);
        var txs = this.getTxs(tokenId);
        txs.push(edgeTransaction); // Sort

        txs.sort(this.sortTxByDate);
        this.walletLocalDataDirty = true;
        var txCheckpoint = edgeTransaction.blockHeight;
        var isNew = // New if unconfirmed
        txCheckpoint === 0 || // No checkpoint means initial sync
        this.seenTxCheckpoint != null && // New if txCheckpoint exceeds the last seen checkpoint
        txCheckpoint >= this.seenTxCheckpoint;
        this.transactionEventArray.push({
          isNew: isNew,
          transaction: edgeTransaction
        });
      } else {
        var _txs2 = this.getTxs(tokenId);

        var oldTx = _txs2[idx]; // Keep the first-seen date for unconfirmed transactions:

        if (edgeTransaction.blockHeight === 0) edgeTransaction.date = oldTx.date; // Already have this tx in the database. Consider a change if blockHeight changed

        if (oldTx.blockHeight === edgeTransaction.blockHeight) return;
        this.log("Update transaction: ".concat(edgeTransaction.txid, " height:").concat(edgeTransaction.blockHeight)); // The native amounts returned from the API take some time before they're
        // accurate. We can trust the amounts we saved instead.

        edgeTransaction.nativeAmount = oldTx.nativeAmount; // Update the transaction

        _txs2[idx] = edgeTransaction;
        this.walletLocalDataDirty = true;
        this.transactionEventArray.push({
          isNew: false,
          transaction: edgeTransaction
        });
        this.log.warn('updateTransaction' + edgeTransaction.txid + edgeTransaction.nativeAmount);
      }
    } // *************************************
    // Save the wallet data store
    // *************************************

  }, {
    key: "saveWalletLoop",
    value: function () {
      var _saveWalletLoop = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
        var walletJson;
        return regeneratorRuntime.wrap(function _callee7$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
                if (!this.walletLocalDataDirty) {
                  _context7.next = 12;
                  break;
                }

                _context7.prev = 1;
                this.log('walletLocalDataDirty. Saving...');
                walletJson = (0,_MoneroLocalData__WEBPACK_IMPORTED_MODULE_3__.wasMoneroLocalData)(this.walletLocalData);
                _context7.next = 6;
                return this.walletLocalDisklet.setText(_MoneroLocalData__WEBPACK_IMPORTED_MODULE_3__.DATA_STORE_FILE, walletJson);

              case 6:
                this.walletLocalDataDirty = false;
                _context7.next = 12;
                break;

              case 9:
                _context7.prev = 9;
                _context7.t0 = _context7["catch"](1);
                this.log.error('saveWalletLoop', _context7.t0);

              case 12:
              case "end":
                return _context7.stop();
            }
          }
        }, _callee7, this, [[1, 9]]);
      }));

      function saveWalletLoop() {
        return _saveWalletLoop.apply(this, arguments);
      }

      return saveWalletLoop;
    }()
  }, {
    key: "doInitialCallbacks",
    value: function doInitialCallbacks() {
      for (var _i2 = 0, _this$walletLocalData2 = this.walletLocalData.enabledTokens; _i2 < _this$walletLocalData2.length; _i2++) {
        var tokenId = _this$walletLocalData2[_i2];

        try {
          var _this$walletLocalData3;

          var _bal = (_this$walletLocalData3 = this.walletLocalData.totalBalances.get(tokenId)) !== null && _this$walletLocalData3 !== void 0 ? _this$walletLocalData3 : '0';

          this.edgeTxLibCallbacks.onTokenBalanceChanged(tokenId, _bal);
        } catch (e) {
          this.log.error('Error for currencyCode', tokenId, e);
        }
      }
    }
  }, {
    key: "addToLoop",
    value: function () {
      var _addToLoop = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee8(func, timer) {
        var _this2 = this;

        return regeneratorRuntime.wrap(function _callee8$(_context8) {
          while (1) {
            switch (_context8.prev = _context8.next) {
              case 0:
                _context8.prev = 0;
                _context8.next = 3;
                return this[func]();

              case 3:
                _context8.next = 8;
                break;

              case 5:
                _context8.prev = 5;
                _context8.t0 = _context8["catch"](0);
                this.log.error('Error in Loop:', func, _context8.t0);

              case 8:
                if (this.engineOn) {
                  this.timers[func] = setTimeout(function () {
                    if (_this2.engineOn) {
                      // eslint-disable-next-line @typescript-eslint/no-floating-promises
                      _this2.addToLoop(func, timer);
                    }
                  }, timer);
                }

              case 9:
              case "end":
                return _context8.stop();
            }
          }
        }, _callee8, this, [[0, 5]]);
      }));

      function addToLoop(_x7, _x8) {
        return _addToLoop.apply(this, arguments);
      }

      return addToLoop;
    }() // *************************************
    // Public methods
    // *************************************

  }, {
    key: "changeUserSettings",
    value: function () {
      var _changeUserSettings = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee9(userSettings) {
        return regeneratorRuntime.wrap(function _callee9$(_context9) {
          while (1) {
            switch (_context9.prev = _context9.next) {
              case 0:
                this.currentSettings = _objectSpread(_objectSpread({}, this.currencyInfo.defaultSettings), (0,_moneroTypes__WEBPACK_IMPORTED_MODULE_4__.asMoneroUserSettings)(userSettings));

                if (this.currentSettings.enableCustomServers && this.currentSettings.moneroLightwalletServer != null) {
                  this.myMoneroApi.changeServer(this.currentSettings.moneroLightwalletServer, '');
                } else {
                  this.myMoneroApi.changeServer(this.currencyTools.networkInfo.defaultServer, this.apiKey);
                }

              case 2:
              case "end":
                return _context9.stop();
            }
          }
        }, _callee9, this);
      }));

      function changeUserSettings(_x9) {
        return _changeUserSettings.apply(this, arguments);
      }

      return changeUserSettings;
    }()
  }, {
    key: "startEngine",
    value: function () {
      var _startEngine = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee10() {
        return regeneratorRuntime.wrap(function _callee10$(_context10) {
          while (1) {
            switch (_context10.prev = _context10.next) {
              case 0:
                this.engineOn = true;
                this.doInitialCallbacks();

              case 2:
              case "end":
                return _context10.stop();
            }
          }
        }, _callee10, this);
      }));

      function startEngine() {
        return _startEngine.apply(this, arguments);
      }

      return startEngine;
    }()
  }, {
    key: "killEngine",
    value: function () {
      var _killEngine = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee11() {
        var timer;
        return regeneratorRuntime.wrap(function _callee11$(_context11) {
          while (1) {
            switch (_context11.prev = _context11.next) {
              case 0:
                // Set status flag to false
                this.engineOn = false;
                this.loggedIn = false; // Clear Inner loops timers

                for (timer in this.timers) {
                  clearTimeout(this.timers[timer]);
                }

                this.timers = {};

              case 4:
              case "end":
                return _context11.stop();
            }
          }
        }, _callee11, this);
      }));

      function killEngine() {
        return _killEngine.apply(this, arguments);
      }

      return killEngine;
    }()
  }, {
    key: "resyncBlockchain",
    value: function () {
      var _resyncBlockchain = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee12() {
        return regeneratorRuntime.wrap(function _callee12$(_context12) {
          while (1) {
            switch (_context12.prev = _context12.next) {
              case 0:
                _context12.next = 2;
                return this.killEngine();

              case 2:
                this.myMoneroApi.keyImageCache = {};
                this.walletLocalData = (0,_MoneroLocalData__WEBPACK_IMPORTED_MODULE_3__.asMoneroLocalData)(JSON.stringify({
                  enabledTokens: this.walletLocalData.enabledTokens
                }));
                this.walletLocalDataDirty = true;
                this.addressesChecked = false;
                _context12.next = 8;
                return this.saveWalletLoop();

              case 8:
                _context12.next = 10;
                return this.startEngine();

              case 10:
              case "end":
                return _context12.stop();
            }
          }
        }, _callee12, this);
      }));

      function resyncBlockchain() {
        return _resyncBlockchain.apply(this, arguments);
      }

      return resyncBlockchain;
    }()
  }, {
    key: "syncNetwork",
    value: function () {
      var _syncNetwork = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee13(opts) {
        var xmrPrivateKeys;
        return regeneratorRuntime.wrap(function _callee13$(_context13) {
          while (1) {
            switch (_context13.prev = _context13.next) {
              case 0:
                xmrPrivateKeys = (0,_moneroTypes__WEBPACK_IMPORTED_MODULE_4__.asPrivateKeys)(opts.privateKeys); // Login only if not logged in

                if (this.loggedIn) {
                  _context13.next = 4;
                  break;
                }

                _context13.next = 4;
                return this.loginIfNewAddress(xmrPrivateKeys);

              case 4:
                _context13.next = 6;
                return this.checkAddressInnerLoop(xmrPrivateKeys);

              case 6:
                _context13.next = 8;
                return this.checkTransactionsInnerLoop(xmrPrivateKeys);

              case 8:
                return _context13.abrupt("return", SYNC_INTERVAL_MILLISECONDS);

              case 9:
              case "end":
                return _context13.stop();
            }
          }
        }, _callee13, this);
      }));

      function syncNetwork(_x10) {
        return _syncNetwork.apply(this, arguments);
      }

      return syncNetwork;
    }()
  }, {
    key: "getBlockHeight",
    value: function getBlockHeight() {
      return this.walletLocalData.blockHeight;
    }
  }, {
    key: "enableTokens",
    value: function () {
      var _enableTokens = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee14(tokens) {
        return regeneratorRuntime.wrap(function _callee14$(_context14) {
          while (1) {
            switch (_context14.prev = _context14.next) {
              case 0:
              case "end":
                return _context14.stop();
            }
          }
        }, _callee14);
      }));

      function enableTokens(_x11) {
        return _enableTokens.apply(this, arguments);
      }

      return enableTokens;
    }()
  }, {
    key: "disableTokens",
    value: function () {
      var _disableTokens = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee15(tokens) {
        return regeneratorRuntime.wrap(function _callee15$(_context15) {
          while (1) {
            switch (_context15.prev = _context15.next) {
              case 0:
              case "end":
                return _context15.stop();
            }
          }
        }, _callee15);
      }));

      function disableTokens(_x12) {
        return _disableTokens.apply(this, arguments);
      }

      return disableTokens;
    }()
  }, {
    key: "getEnabledTokens",
    value: function () {
      var _getEnabledTokens = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee16() {
        return regeneratorRuntime.wrap(function _callee16$(_context16) {
          while (1) {
            switch (_context16.prev = _context16.next) {
              case 0:
                return _context16.abrupt("return", []);

              case 1:
              case "end":
                return _context16.stop();
            }
          }
        }, _callee16);
      }));

      function getEnabledTokens() {
        return _getEnabledTokens.apply(this, arguments);
      }

      return getEnabledTokens;
    }()
  }, {
    key: "addCustomToken",
    value: function () {
      var _addCustomToken = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee17(tokenObj) {
        return regeneratorRuntime.wrap(function _callee17$(_context17) {
          while (1) {
            switch (_context17.prev = _context17.next) {
              case 0:
              case "end":
                return _context17.stop();
            }
          }
        }, _callee17);
      }));

      function addCustomToken(_x13) {
        return _addCustomToken.apply(this, arguments);
      }

      return addCustomToken;
    }()
  }, {
    key: "getTokenStatus",
    value: function getTokenStatus(token) {
      return false;
    }
  }, {
    key: "getBalance",
    value: function getBalance(options) {
      var _this$walletLocalData4;

      var _options$tokenId = options.tokenId,
          tokenId = _options$tokenId === void 0 ? PRIMARY_CURRENCY_TOKEN_ID : _options$tokenId;
      return (_this$walletLocalData4 = this.walletLocalData.totalBalances.get(tokenId)) !== null && _this$walletLocalData4 !== void 0 ? _this$walletLocalData4 : '0';
    }
  }, {
    key: "getNumTransactions",
    value: function getNumTransactions(options) {
      var _this$walletLocalData5, _this$walletLocalData6;

      var _options$tokenId2 = options.tokenId,
          tokenId = _options$tokenId2 === void 0 ? PRIMARY_CURRENCY_TOKEN_ID : _options$tokenId2;
      return (_this$walletLocalData5 = (_this$walletLocalData6 = this.walletLocalData.transactionsObj.get(tokenId)) === null || _this$walletLocalData6 === void 0 ? void 0 : _this$walletLocalData6.length) !== null && _this$walletLocalData5 !== void 0 ? _this$walletLocalData5 : 0;
    }
  }, {
    key: "getTransactions",
    value: function () {
      var _getTransactions = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee18(options) {
        var _this$walletLocalData7;

        var _options$tokenId3, tokenId;

        return regeneratorRuntime.wrap(function _callee18$(_context18) {
          while (1) {
            switch (_context18.prev = _context18.next) {
              case 0:
                _options$tokenId3 = options.tokenId, tokenId = _options$tokenId3 === void 0 ? PRIMARY_CURRENCY_TOKEN_ID : _options$tokenId3;
                return _context18.abrupt("return", (_this$walletLocalData7 = this.walletLocalData.transactionsObj.get(tokenId)) !== null && _this$walletLocalData7 !== void 0 ? _this$walletLocalData7 : []);

              case 2:
              case "end":
                return _context18.stop();
            }
          }
        }, _callee18, this);
      }));

      function getTransactions(_x14) {
        return _getTransactions.apply(this, arguments);
      }

      return getTransactions;
    }()
  }, {
    key: "getFreshAddress",
    value: function () {
      var _getFreshAddress = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee19(options) {
        return regeneratorRuntime.wrap(function _callee19$(_context19) {
          while (1) {
            switch (_context19.prev = _context19.next) {
              case 0:
                if (!(this.loginPromise != null)) {
                  _context19.next = 3;
                  break;
                }

                _context19.next = 3;
                return this.loginPromise;

              case 3:
                if (this.walletLocalData.hasLoggedIn) {
                  _context19.next = 6;
                  break;
                }

                this.log.warn('Attempted to retrieve `publicAddress` before successfully logging in');
                return _context19.abrupt("return", {
                  publicAddress: ''
                });

              case 6:
                return _context19.abrupt("return", {
                  publicAddress: this.walletInfo.keys.moneroAddress
                });

              case 7:
              case "end":
                return _context19.stop();
            }
          }
        }, _callee19, this);
      }));

      function getFreshAddress(_x15) {
        return _getFreshAddress.apply(this, arguments);
      }

      return getFreshAddress;
    }()
  }, {
    key: "addGapLimitAddresses",
    value: function () {
      var _addGapLimitAddresses = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee20(addresses) {
        return regeneratorRuntime.wrap(function _callee20$(_context20) {
          while (1) {
            switch (_context20.prev = _context20.next) {
              case 0:
              case "end":
                return _context20.stop();
            }
          }
        }, _callee20);
      }));

      function addGapLimitAddresses(_x16) {
        return _addGapLimitAddresses.apply(this, arguments);
      }

      return addGapLimitAddresses;
    }()
  }, {
    key: "isAddressUsed",
    value: function () {
      var _isAddressUsed = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee21(address) {
        return regeneratorRuntime.wrap(function _callee21$(_context21) {
          while (1) {
            switch (_context21.prev = _context21.next) {
              case 0:
                return _context21.abrupt("return", false);

              case 1:
              case "end":
                return _context21.stop();
            }
          }
        }, _callee21);
      }));

      function isAddressUsed(_x17) {
        return _isAddressUsed.apply(this, arguments);
      }

      return isAddressUsed;
    }()
  }, {
    key: "getMaxSpendable",
    value: function () {
      var _getMaxSpendable = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee22(edgeSpendInfo, opts) {
        var privateKeys, _edgeSpendInfo$spendT, spendTarget, publicAddress, options, result;

        return regeneratorRuntime.wrap(function _callee22$(_context22) {
          while (1) {
            switch (_context22.prev = _context22.next) {
              case 0:
                privateKeys = (0,_moneroTypes__WEBPACK_IMPORTED_MODULE_4__.asPrivateKeys)(opts === null || opts === void 0 ? void 0 : opts.privateKeys);
                _edgeSpendInfo$spendT = _slicedToArray(edgeSpendInfo.spendTargets, 1), spendTarget = _edgeSpendInfo$spendT[0];
                publicAddress = spendTarget.publicAddress;

                if (!(publicAddress == null)) {
                  _context22.next = 5;
                  break;
                }

                throw new TypeError('Missing destination address');

              case 5:
                options = {
                  isSweepTx: true,
                  priority: translateFee(edgeSpendInfo.networkFeeOption),
                  targets: [{
                    amount: '0',
                    targetAddress: publicAddress
                  }]
                };
                _context22.next = 8;
                return this.createMyMoneroTransaction(options, privateKeys);

              case 8:
                result = _context22.sent;
                return _context22.abrupt("return", result.final_total_wo_fee);

              case 10:
              case "end":
                return _context22.stop();
            }
          }
        }, _callee22, this);
      }));

      function getMaxSpendable(_x18, _x19) {
        return _getMaxSpendable.apply(this, arguments);
      }

      return getMaxSpendable;
    }()
  }, {
    key: "createMyMoneroTransaction",
    value: function () {
      var _createMyMoneroTransaction = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee23(options, privateKeys) {
        var regex, subst, msgFormatted;
        return regeneratorRuntime.wrap(function _callee23$(_context23) {
          while (1) {
            switch (_context23.prev = _context23.next) {
              case 0:
                _context23.prev = 0;
                _context23.next = 3;
                return this.myMoneroApi.createTransaction({
                  address: this.walletInfo.keys.moneroAddress,
                  privateViewKey: this.walletInfo.keys.moneroViewKeyPrivate,
                  privateSpendKey: privateKeys.moneroSpendKeyPrivate,
                  publicSpendKey: privateKeys.moneroSpendKeyPublic
                }, options);

              case 3:
                return _context23.abrupt("return", _context23.sent);

              case 6:
                _context23.prev = 6;
                _context23.t0 = _context23["catch"](0);

                if (_context23.t0 instanceof Error) {
                  _context23.next = 10;
                  break;
                }

                throw new Error(String(_context23.t0));

              case 10:
                if (!(_context23.t0.message === 'Not enough spendables')) {
                  _context23.next = 12;
                  break;
                }

                throw new edge_core_js_types__WEBPACK_IMPORTED_MODULE_1__.InsufficientFundsError({
                  tokenId: PRIMARY_CURRENCY_TOKEN_ID
                });

              case 12:
                // This error is specific to mymonero-core-js: github.com/mymonero/mymonero-core-cpp/blob/a53e57f2a376b05bb0f4d851713321c749e5d8d9/src/monero_transfer_utils.hpp#L112-L162
                this.log.error(_context23.t0.message);
                regex = / Have (\d*\.?\d+) XMR; need (\d*\.?\d+) XMR./gm;
                subst = "\nHave: $1 XMR.\nNeed: $2 XMR.";
                msgFormatted = _context23.t0.message.replace(regex, subst);
                throw new Error(msgFormatted);

              case 17:
              case "end":
                return _context23.stop();
            }
          }
        }, _callee23, this, [[0, 6]]);
      }));

      function createMyMoneroTransaction(_x20, _x21) {
        return _createMyMoneroTransaction.apply(this, arguments);
      }

      return createMyMoneroTransaction;
    }()
  }, {
    key: "makeSpend",
    value: function () {
      var _makeSpend = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee24(edgeSpendInfo, opts) {
        var _edgeSpendInfo$memos, memos, privateKeys, spendTargets, totalAmount, targets, _i4, _this$walletLocalData8, spendTarget, publicAddress, nativeAmount, options, result, date, edgeTransaction;

        return regeneratorRuntime.wrap(function _callee24$(_context24) {
          while (1) {
            switch (_context24.prev = _context24.next) {
              case 0:
                _edgeSpendInfo$memos = edgeSpendInfo.memos, memos = _edgeSpendInfo$memos === void 0 ? [] : _edgeSpendInfo$memos;
                privateKeys = (0,_moneroTypes__WEBPACK_IMPORTED_MODULE_4__.asPrivateKeys)(opts === null || opts === void 0 ? void 0 : opts.privateKeys);
                spendTargets = edgeSpendInfo.spendTargets;
                totalAmount = '0';
                targets = [];
                _i4 = 0;

              case 6:
                if (!(_i4 < spendTargets.length)) {
                  _context24.next = 24;
                  break;
                }

                spendTarget = spendTargets[_i4];
                publicAddress = spendTarget.publicAddress, nativeAmount = spendTarget.nativeAmount;

                if (!(publicAddress == null)) {
                  _context24.next = 11;
                  break;
                }

                throw new TypeError('Missing destination address');

              case 11:
                if (!(nativeAmount == null || (0,biggystring__WEBPACK_IMPORTED_MODULE_0__.eq)(nativeAmount, '0'))) {
                  _context24.next = 13;
                  break;
                }

                throw new edge_core_js_types__WEBPACK_IMPORTED_MODULE_1__.NoAmountSpecifiedError();

              case 13:
                totalAmount = (0,biggystring__WEBPACK_IMPORTED_MODULE_0__.add)(totalAmount, nativeAmount);

                if (!(0,biggystring__WEBPACK_IMPORTED_MODULE_0__.gte)(totalAmount, (_this$walletLocalData8 = this.walletLocalData.totalBalances.get(PRIMARY_CURRENCY_TOKEN_ID)) !== null && _this$walletLocalData8 !== void 0 ? _this$walletLocalData8 : '0')) {
                  _context24.next = 20;
                  break;
                }

                if (!(0,biggystring__WEBPACK_IMPORTED_MODULE_0__.gte)(this.walletLocalData.lockedXmrBalance, totalAmount)) {
                  _context24.next = 19;
                  break;
                }

                throw new edge_core_js_types__WEBPACK_IMPORTED_MODULE_1__.PendingFundsError();

              case 19:
                throw new edge_core_js_types__WEBPACK_IMPORTED_MODULE_1__.InsufficientFundsError({
                  tokenId: PRIMARY_CURRENCY_TOKEN_ID
                });

              case 20:
                targets.push({
                  amount: (0,biggystring__WEBPACK_IMPORTED_MODULE_0__.div)(nativeAmount, '1000000000000', 12),
                  targetAddress: publicAddress
                });

              case 21:
                _i4++;
                _context24.next = 6;
                break;

              case 24:
                options = {
                  isSweepTx: false,
                  priority: translateFee(edgeSpendInfo.networkFeeOption),
                  targets: targets
                };
                this.log("Creating transaction: ".concat(JSON.stringify(options, null, 1)));
                _context24.next = 28;
                return this.createMyMoneroTransaction(options, privateKeys);

              case 28:
                result = _context24.sent;
                date = Date.now() / 1000;
                this.log("Total sent: ".concat(result.total_sent, ", Fee: ").concat(result.used_fee));
                edgeTransaction = {
                  blockHeight: 0,
                  // blockHeight
                  currencyCode: 'XMR',
                  // currencyCode
                  date: date,
                  isSend: true,
                  memos: memos,
                  nativeAmount: '-' + result.total_sent,
                  networkFee: result.used_fee,
                  networkFees: [{
                    tokenId: null,
                    nativeAmount: result.used_fee
                  }],
                  ourReceiveAddresses: [],
                  // ourReceiveAddresses
                  signedTx: result.serialized_signed_tx,
                  tokenId: null,
                  txid: result.tx_hash,
                  txSecret: result.tx_key,
                  walletId: this.walletId
                };
                this.log.warn("makeSpend edgeTransaction ".concat((0,_utils__WEBPACK_IMPORTED_MODULE_6__.cleanTxLogs)(edgeTransaction)));
                return _context24.abrupt("return", edgeTransaction);

              case 34:
              case "end":
                return _context24.stop();
            }
          }
        }, _callee24, this);
      }));

      function makeSpend(_x22, _x23) {
        return _makeSpend.apply(this, arguments);
      }

      return makeSpend;
    }()
  }, {
    key: "signTx",
    value: function () {
      var _signTx = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee25(edgeTransaction, privateKeys) {
        return regeneratorRuntime.wrap(function _callee25$(_context25) {
          while (1) {
            switch (_context25.prev = _context25.next) {
              case 0:
                return _context25.abrupt("return", edgeTransaction);

              case 1:
              case "end":
                return _context25.stop();
            }
          }
        }, _callee25);
      }));

      function signTx(_x24, _x25) {
        return _signTx.apply(this, arguments);
      }

      return signTx;
    }()
  }, {
    key: "broadcastTx",
    value: function () {
      var _broadcastTx = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee26(edgeTransaction) {
        return regeneratorRuntime.wrap(function _callee26$(_context26) {
          while (1) {
            switch (_context26.prev = _context26.next) {
              case 0:
                _context26.prev = 0;
                _context26.next = 3;
                return this.myMoneroApi.broadcastTransaction(edgeTransaction.signedTx);

              case 3:
                this.log.warn("broadcastTx success ".concat((0,_utils__WEBPACK_IMPORTED_MODULE_6__.cleanTxLogs)(edgeTransaction)));
                return _context26.abrupt("return", edgeTransaction);

              case 7:
                _context26.prev = 7;
                _context26.t0 = _context26["catch"](0);
                this.log.error("broadcastTx failed: ".concat(String(_context26.t0), " ").concat((0,_utils__WEBPACK_IMPORTED_MODULE_6__.cleanTxLogs)(edgeTransaction)));

                if (!(_context26.t0 instanceof Error && _context26.t0.message.includes(' 422 '))) {
                  _context26.next = 14;
                  break;
                }

                throw new Error('The Monero network rejected this transaction. You may need to wait for more confirmations');

              case 14:
                throw _context26.t0;

              case 15:
              case "end":
                return _context26.stop();
            }
          }
        }, _callee26, this, [[0, 7]]);
      }));

      function broadcastTx(_x26) {
        return _broadcastTx.apply(this, arguments);
      }

      return broadcastTx;
    }()
  }, {
    key: "saveTx",
    value: function () {
      var _saveTx = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee27(edgeTransaction) {
        return regeneratorRuntime.wrap(function _callee27$(_context27) {
          while (1) {
            switch (_context27.prev = _context27.next) {
              case 0:
                _context27.next = 2;
                return this.saveTransactionState(edgeTransaction.tokenId, edgeTransaction);

              case 2:
              case "end":
                return _context27.stop();
            }
          }
        }, _callee27, this);
      }));

      function saveTx(_x27) {
        return _saveTx.apply(this, arguments);
      }

      return saveTx;
    }()
  }, {
    key: "getDisplayPrivateSeed",
    value: function getDisplayPrivateSeed(privateKeys) {
      var xmrPrivateKeys = (0,_moneroTypes__WEBPACK_IMPORTED_MODULE_4__.asPrivateKeys)(privateKeys);
      return xmrPrivateKeys.moneroKey;
    }
  }, {
    key: "getDisplayPublicSeed",
    value: function getDisplayPublicSeed() {
      var _this$walletInfo$keys;

      if (((_this$walletInfo$keys = this.walletInfo.keys) === null || _this$walletInfo$keys === void 0 ? void 0 : _this$walletInfo$keys.moneroViewKeyPrivate) != null) {
        return this.walletInfo.keys.moneroViewKeyPrivate;
      }

      return '';
    }
  }, {
    key: "dumpData",
    value: function () {
      var _dumpData = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee28() {
        var dataDump;
        return regeneratorRuntime.wrap(function _callee28$(_context28) {
          while (1) {
            switch (_context28.prev = _context28.next) {
              case 0:
                dataDump = {
                  walletId: this.walletId,
                  walletType: this.walletInfo.type,
                  // @ts-expect-error
                  pluginType: this.currencyInfo.pluginId,
                  data: {
                    walletLocalData: this.walletLocalData
                  }
                };
                return _context28.abrupt("return", dataDump);

              case 2:
              case "end":
                return _context28.stop();
            }
          }
        }, _callee28, this);
      }));

      function dumpData() {
        return _dumpData.apply(this, arguments);
      }

      return dumpData;
    }()
  }]);

  return MoneroEngine;
}();

function translateFee(fee) {
  if (fee === 'low') return 1;
  if (fee === 'high') return 3;
  return 2;
}

function makeCurrencyEngine(_x28, _x29, _x30, _x31) {
  return _makeCurrencyEngine.apply(this, arguments);
}

function _makeCurrencyEngine() {
  _makeCurrencyEngine = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee29(env, tools, walletInfo, opts) {
    var safeWalletInfo, engine, result;
    return regeneratorRuntime.wrap(function _callee29$(_context29) {
      while (1) {
        switch (_context29.prev = _context29.next) {
          case 0:
            safeWalletInfo = (0,_moneroTypes__WEBPACK_IMPORTED_MODULE_4__.asSafeWalletInfo)(walletInfo);
            engine = new MoneroEngine(env, tools, safeWalletInfo, opts);
            _context29.next = 4;
            return engine.init();

          case 4:
            _context29.prev = 4;
            _context29.next = 7;
            return engine.walletLocalDisklet.getText(_MoneroLocalData__WEBPACK_IMPORTED_MODULE_3__.DATA_STORE_FILE);

          case 7:
            result = _context29.sent;
            engine.walletLocalData = (0,_MoneroLocalData__WEBPACK_IMPORTED_MODULE_3__.asMoneroLocalData)(result);
            _context29.next = 24;
            break;

          case 11:
            _context29.prev = 11;
            _context29.t0 = _context29["catch"](4);
            _context29.prev = 13;
            opts.log(_context29.t0);
            opts.log('No walletLocalData setup yet: Failure is ok');
            engine.walletLocalData = (0,_MoneroLocalData__WEBPACK_IMPORTED_MODULE_3__.asMoneroLocalData)('{}');
            _context29.next = 19;
            return engine.walletLocalDisklet.setText(_MoneroLocalData__WEBPACK_IMPORTED_MODULE_3__.DATA_STORE_FILE, (0,_MoneroLocalData__WEBPACK_IMPORTED_MODULE_3__.wasMoneroLocalData)(engine.walletLocalData));

          case 19:
            _context29.next = 24;
            break;

          case 21:
            _context29.prev = 21;
            _context29.t1 = _context29["catch"](13);
            opts.log.error("Error writing to localDataStore. Engine not started: ".concat(String(_context29.t1)));

          case 24:
            return _context29.abrupt("return", engine);

          case 25:
          case "end":
            return _context29.stop();
        }
      }
    }, _callee29, null, [[4, 11], [13, 21]]);
  }));
  return _makeCurrencyEngine.apply(this, arguments);
}

/***/ }),

/***/ "./src/MoneroLocalData.ts":
/*!********************************!*\
  !*** ./src/MoneroLocalData.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DATA_STORE_FILE: () => (/* binding */ DATA_STORE_FILE),
/* harmony export */   PRIMARY_CURRENCY_TOKEN_ID: () => (/* binding */ PRIMARY_CURRENCY_TOKEN_ID),
/* harmony export */   asMoneroLocalData: () => (/* binding */ asMoneroLocalData),
/* harmony export */   wasMoneroLocalData: () => (/* binding */ wasMoneroLocalData)
/* harmony export */ });
/* harmony import */ var cleaners__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! cleaners */ "./node_modules/cleaners/lib/esm/cleaners.js");

var DATA_STORE_FILE = 'txEngineFolder/walletLocalData.json';
var PRIMARY_CURRENCY_TOKEN_ID = null;

var asNotNull = function asNotNull(value) {
  if (value == null) throw new Error('Expected EdgeTransaction');
  return value;
};

var asMap = function asMap(asKey, asValue) {
  return (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asCodec)(function (value) {
    var unknownEntries = value instanceof Map ? Array.from(value.entries()) : value; // TODO: Merge "Expected a Map" to TypeError message

    var entries = (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asArray)((0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asTuple)(asKey, asValue))(unknownEntries);
    return new Map(entries);
  }, function (map) {
    var entries = map.entries();
    var entriesArray = Array.from(entries);
    return entriesArray;
  });
};

var asEdgeToken = (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asEither)(cleaners__WEBPACK_IMPORTED_MODULE_0__.asString, cleaners__WEBPACK_IMPORTED_MODULE_0__.asNull);

var asCompatibleEdgeToken = function asCompatibleEdgeToken(value) {
  // Backwards compatibility when the token used to be currencyCode
  if (value === 'XMR') return null;
  return asEdgeToken(value);
};

var asMoneroLocalData = (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asJSON)((0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asObject)({
  blockHeight: (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asOptional)(cleaners__WEBPACK_IMPORTED_MODULE_0__.asNumber, 0),
  hasLoggedIn: (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asOptional)(cleaners__WEBPACK_IMPORTED_MODULE_0__.asBoolean, false),
  lastAddressQueryHeight: (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asOptional)(cleaners__WEBPACK_IMPORTED_MODULE_0__.asNumber, 0),
  lockedXmrBalance: (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asOptional)(cleaners__WEBPACK_IMPORTED_MODULE_0__.asString, '0'),
  nextNonce: (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asOptional)(cleaners__WEBPACK_IMPORTED_MODULE_0__.asString, '0'),
  totalBalances: (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asOptional)(asMap(asEdgeToken, cleaners__WEBPACK_IMPORTED_MODULE_0__.asString), function () {
    return new Map([[null, '0']]);
  }),
  enabledTokens: (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asOptional)((0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asArray)(asCompatibleEdgeToken), [PRIMARY_CURRENCY_TOKEN_ID]),
  transactionsObj: (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asOptional)(asMap(asEdgeToken, (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asArray)(asNotNull)), function () {
    return new Map();
  })
}));
var wasMoneroLocalData = (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.uncleaner)(asMoneroLocalData);

/***/ }),

/***/ "./src/MoneroTools.ts":
/*!****************************!*\
  !*** ./src/MoneroTools.ts ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MoneroTools: () => (/* binding */ MoneroTools)
/* harmony export */ });
/* harmony import */ var biggystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! biggystring */ "./node_modules/biggystring/lib/src/index.js");
/* harmony import */ var biggystring__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(biggystring__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_native_mymonero_core_src_CppBridge__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-native-mymonero-core/src/CppBridge */ "./node_modules/react-native-mymonero-core/src/CppBridge.js");
/* harmony import */ var react_native_mymonero_core_src_CppBridge__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_native_mymonero_core_src_CppBridge__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var uri_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! uri-js */ "./node_modules/uri-js/dist/esnext/index.js");
/* harmony import */ var _moneroInfo__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./moneroInfo */ "./src/moneroInfo.ts");
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






function getDenomInfo(denom) {
  return _moneroInfo__WEBPACK_IMPORTED_MODULE_3__.currencyInfo.denominations.find(function (element) {
    return element.name === denom;
  });
}

function getParameterByName(param, url) {
  var name = param.replace(/[[\]]/g, '\\$&');
  var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)');
  var results = regex.exec(url);
  if (results == null || results[2] == null) return;
  return decodeURIComponent(results[2].replace(/\+/g, ' '));
}

var MoneroTools = /*#__PURE__*/function () {
  function MoneroTools(env) {
    _classCallCheck(this, MoneroTools);

    _defineProperty(this, "networkInfo", {
      defaultServer: _moneroInfo__WEBPACK_IMPORTED_MODULE_3__.MONERO_LWS_SERVER,
      nettype: 'MAINNET'
    });

    var io = env.io,
        log = env.log,
        nativeIo = env.nativeIo; // Grab the raw C++ API and wrap it in argument parsing:

    var cppModule = nativeIo['edge-currency-monero'];
    this.cppBridge = new (react_native_mymonero_core_src_CppBridge__WEBPACK_IMPORTED_MODULE_1___default())(cppModule);
    this.io = io;
    this.log = log;
  }

  _createClass(MoneroTools, [{
    key: "createPrivateKey",
    value: function () {
      var _createPrivateKey = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(walletType) {
        var result, privateKeys;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                if (!(walletType !== 'wallet:monero')) {
                  _context.next = 2;
                  break;
                }

                throw new Error('InvalidWalletType');

              case 2:
                _context.next = 4;
                return this.cppBridge.generateWallet('english', this.networkInfo.nettype);

              case 4:
                result = _context.sent;
                privateKeys = {
                  moneroKey: result.mnemonic,
                  moneroSpendKeyPrivate: result.privateSpendKey,
                  moneroSpendKeyPublic: result.publicSpendKey
                };
                return _context.abrupt("return", privateKeys);

              case 7:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function createPrivateKey(_x) {
        return _createPrivateKey.apply(this, arguments);
      }

      return createPrivateKey;
    }()
  }, {
    key: "derivePublicKey",
    value: function () {
      var _derivePublicKey = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(walletInfo) {
        var result, publicKeys;
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                if (!(walletInfo.type !== 'wallet:monero')) {
                  _context2.next = 2;
                  break;
                }

                throw new Error('InvalidWalletType');

              case 2:
                _context2.next = 4;
                return this.cppBridge.seedAndKeysFromMnemonic(walletInfo.keys.moneroKey, this.networkInfo.nettype);

              case 4:
                result = _context2.sent;
                publicKeys = {
                  moneroAddress: result.address,
                  moneroViewKeyPrivate: result.privateViewKey,
                  moneroViewKeyPublic: result.publicViewKey,
                  moneroSpendKeyPublic: result.publicSpendKey
                };
                return _context2.abrupt("return", publicKeys);

              case 7:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      function derivePublicKey(_x2) {
        return _derivePublicKey.apply(this, arguments);
      }

      return derivePublicKey;
    }()
  }, {
    key: "parseUri",
    value: function () {
      var _parseUri = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(uri) {
        var _getParameterByName, _getParameterByName2, _getParameterByName3;

        var parsedUri, address, nativeAmount, currencyCode, amountStr, denom, uniqueIdentifier, label, message, category, edgeParsedUri;
        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                parsedUri = (0,uri_js__WEBPACK_IMPORTED_MODULE_2__.parse)(uri);

                if (!(typeof parsedUri.scheme !== 'undefined' && parsedUri.scheme !== 'monero')) {
                  _context3.next = 3;
                  break;
                }

                throw new Error('InvalidUriError');

              case 3:
                if (!(typeof parsedUri.host !== 'undefined')) {
                  _context3.next = 7;
                  break;
                }

                address = parsedUri.host;
                _context3.next = 12;
                break;

              case 7:
                if (!(typeof parsedUri.path !== 'undefined')) {
                  _context3.next = 11;
                  break;
                }

                address = parsedUri.path;
                _context3.next = 12;
                break;

              case 11:
                throw new Error('InvalidUriError');

              case 12:
                address = address.replace('/', ''); // Remove any slashes

                _context3.prev = 13;
                _context3.next = 16;
                return this.cppBridge.decodeAddress(address, this.networkInfo.nettype);

              case 16:
                _context3.next = 21;
                break;

              case 18:
                _context3.prev = 18;
                _context3.t0 = _context3["catch"](13);
                throw new Error('InvalidPublicAddressError');

              case 21:
                // Prioritize the correct Monero URI format, while falling back to BIP21
                // formats.
                amountStr = (_getParameterByName = getParameterByName('tx_amount', uri)) !== null && _getParameterByName !== void 0 ? _getParameterByName : getParameterByName('amount', uri);

                if (!(amountStr != null)) {
                  _context3.next = 29;
                  break;
                }

                denom = getDenomInfo('XMR');

                if (!(denom == null)) {
                  _context3.next = 26;
                  break;
                }

                throw new Error('InternalErrorInvalidCurrencyCode');

              case 26:
                nativeAmount = (0,biggystring__WEBPACK_IMPORTED_MODULE_0__.mul)(amountStr, denom.multiplier);
                nativeAmount = (0,biggystring__WEBPACK_IMPORTED_MODULE_0__.toFixed)(nativeAmount, 0, 0);
                currencyCode = 'XMR';

              case 29:
                uniqueIdentifier = getParameterByName('tx_payment_id', uri);
                label = (_getParameterByName2 = getParameterByName('recipient_name', uri)) !== null && _getParameterByName2 !== void 0 ? _getParameterByName2 : getParameterByName('label', uri);
                message = (_getParameterByName3 = getParameterByName('tx_description', uri)) !== null && _getParameterByName3 !== void 0 ? _getParameterByName3 : getParameterByName('message', uri);
                category = getParameterByName('category', uri);
                edgeParsedUri = {
                  publicAddress: address
                };

                if (nativeAmount != null) {
                  edgeParsedUri.nativeAmount = nativeAmount;
                }

                if (currencyCode != null) {
                  edgeParsedUri.currencyCode = currencyCode;
                }

                if (uniqueIdentifier != null) {
                  edgeParsedUri.uniqueIdentifier = uniqueIdentifier;
                }

                if (label != null || message != null || category != null) {
                  edgeParsedUri.metadata = {};

                  if (label != null) {
                    edgeParsedUri.metadata.name = label;
                  }

                  if (message != null) {
                    edgeParsedUri.metadata.notes = message;
                  }

                  if (category != null) {
                    edgeParsedUri.metadata.category = category;
                  }
                }

                return _context3.abrupt("return", edgeParsedUri);

              case 39:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this, [[13, 18]]);
      }));

      function parseUri(_x3) {
        return _parseUri.apply(this, arguments);
      }

      return parseUri;
    }()
  }, {
    key: "encodeUri",
    value: function () {
      var _encodeUri = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(obj) {
        var queryString, currencyCode, nativeAmount, denom, amount, serializeObj, url;
        return regeneratorRuntime.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                if (!(obj.publicAddress == null)) {
                  _context4.next = 2;
                  break;
                }

                throw new Error('InvalidPublicAddressError');

              case 2:
                _context4.prev = 2;
                _context4.next = 5;
                return this.cppBridge.decodeAddress(obj.publicAddress, this.networkInfo.nettype);

              case 5:
                _context4.next = 10;
                break;

              case 7:
                _context4.prev = 7;
                _context4.t0 = _context4["catch"](2);
                throw new Error('InvalidPublicAddressError');

              case 10:
                if (!(obj.nativeAmount == null && obj.label == null && obj.message == null)) {
                  _context4.next = 14;
                  break;
                }

                return _context4.abrupt("return", obj.publicAddress);

              case 14:
                queryString = '';

                if (!(typeof obj.nativeAmount === 'string')) {
                  _context4.next = 23;
                  break;
                }

                currencyCode = 'XMR';
                nativeAmount = obj.nativeAmount;
                denom = getDenomInfo(currencyCode);

                if (!(denom == null)) {
                  _context4.next = 21;
                  break;
                }

                throw new Error('InternalErrorInvalidCurrencyCode');

              case 21:
                amount = (0,biggystring__WEBPACK_IMPORTED_MODULE_0__.div)(nativeAmount, denom.multiplier, 12);
                queryString += 'tx_amount=' + amount + '&';

              case 23:
                if (typeof obj.label === 'string') {
                  queryString += 'recipient_name=' + obj.label + '&';
                }

                if (typeof obj.message === 'string') {
                  queryString += 'tx_description=' + obj.message + '&';
                }

                queryString = queryString.substr(0, queryString.length - 1);
                serializeObj = {
                  scheme: 'monero',
                  path: obj.publicAddress,
                  query: queryString
                };
                url = (0,uri_js__WEBPACK_IMPORTED_MODULE_2__.serialize)(serializeObj);
                return _context4.abrupt("return", url);

              case 29:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this, [[2, 7]]);
      }));

      function encodeUri(_x4) {
        return _encodeUri.apply(this, arguments);
      }

      return encodeUri;
    }()
  }]);

  return MoneroTools;
}();

/***/ }),

/***/ "./src/MyMoneroApi.ts":
/*!****************************!*\
  !*** ./src/MyMoneroApi.ts ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MyMoneroApi: () => (/* binding */ MyMoneroApi)
/* harmony export */ });
/* harmony import */ var cleaners__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! cleaners */ "./node_modules/cleaners/lib/esm/cleaners.js");
/* harmony import */ var _mymonero_utils_ResponseParser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mymonero-utils/ResponseParser */ "./src/mymonero-utils/ResponseParser.js");
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

// @flow



var asNumberBoolean = function asNumberBoolean(raw) {
  if (typeof raw === 'number') return Boolean(raw);
  return (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asBoolean)(raw);
};

var asSpentOutput = (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asObject)({
  amount: cleaners__WEBPACK_IMPORTED_MODULE_0__.asString,
  // XMR possibly being spent
  key_image: cleaners__WEBPACK_IMPORTED_MODULE_0__.asString,
  // Bytes of the key image
  mixin: cleaners__WEBPACK_IMPORTED_MODULE_0__.asNumber,
  // Mixin of the spend
  out_index: cleaners__WEBPACK_IMPORTED_MODULE_0__.asNumber,
  // Index of source output
  tx_pub_key: cleaners__WEBPACK_IMPORTED_MODULE_0__.asString // Bytes of the tx public key

});
//
// Response Cleaners
//
var asLoginResponse = (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asObject)({
  generated_locally: (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asOptional)(asNumberBoolean),
  // Flag from initial account creation
  new_address: asNumberBoolean,
  // Whether account was just created
  start_height: (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asOptional)(cleaners__WEBPACK_IMPORTED_MODULE_0__.asNumber),
  // Account scanning start block
  view_key: (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asOptional)(cleaners__WEBPACK_IMPORTED_MODULE_0__.asString) // View key bytes

});
var asAddressInfoResponse = (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asObject)({
  blockchain_height: cleaners__WEBPACK_IMPORTED_MODULE_0__.asNumber,
  // Current blockchain height
  locked_funds: cleaners__WEBPACK_IMPORTED_MODULE_0__.asString,
  // Sum of unspendable XMR
  rates: (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asOptional)((0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asObject)(cleaners__WEBPACK_IMPORTED_MODULE_0__.asNumber)),
  // Rates
  scanned_block_height: cleaners__WEBPACK_IMPORTED_MODULE_0__.asNumber,
  // Current scan progress
  scanned_height: cleaners__WEBPACK_IMPORTED_MODULE_0__.asNumber,
  // Current tx scan progress
  spent_outputs: (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asOptional)((0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asArray)(asSpentOutput)),
  // Possible spend info
  start_height: cleaners__WEBPACK_IMPORTED_MODULE_0__.asNumber,
  // Start height of response
  total_received: cleaners__WEBPACK_IMPORTED_MODULE_0__.asString,
  // Sum of received XMR
  total_sent: cleaners__WEBPACK_IMPORTED_MODULE_0__.asString,
  // Sum of possibly spent XMR
  transaction_height: cleaners__WEBPACK_IMPORTED_MODULE_0__.asNumber // Total txes sent in Monero

});
var asGetAddressTxsResponse = (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asObject)({
  blockchain_height: cleaners__WEBPACK_IMPORTED_MODULE_0__.asNumber,
  // Current blockchain height
  scanned_block_height: cleaners__WEBPACK_IMPORTED_MODULE_0__.asNumber,
  // Current scan progress
  scanned_height: cleaners__WEBPACK_IMPORTED_MODULE_0__.asNumber,
  // Current tx scan progress
  start_height: cleaners__WEBPACK_IMPORTED_MODULE_0__.asNumber,
  // Start height of response
  total_received: cleaners__WEBPACK_IMPORTED_MODULE_0__.asString,
  // Sum of received outputs
  transaction_height: (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asOptional)(cleaners__WEBPACK_IMPORTED_MODULE_0__.asNumber),
  transactions: (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asOptional)((0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asArray)((0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asObject)({
    coinbase: asNumberBoolean,
    // True if tx is coinbase
    hash: cleaners__WEBPACK_IMPORTED_MODULE_0__.asString,
    // Bytes of tx hash
    height: (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asOptional)(cleaners__WEBPACK_IMPORTED_MODULE_0__.asNumber),
    // Block height
    id: cleaners__WEBPACK_IMPORTED_MODULE_0__.asNumber,
    // Index of tx in blockchain
    mempool: asNumberBoolean,
    // True if tx is in mempool
    mixin: cleaners__WEBPACK_IMPORTED_MODULE_0__.asNumber,
    // Mixin of the receive
    payment_id: (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asOptional)(cleaners__WEBPACK_IMPORTED_MODULE_0__.asString),
    // Bytes of tx payment id
    spent_outputs: (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asOptional)((0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asArray)(asSpentOutput)),
    // List of possible spends
    timestamp: (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asOptional)(cleaners__WEBPACK_IMPORTED_MODULE_0__.asString),
    // Timestamp of block
    total_received: cleaners__WEBPACK_IMPORTED_MODULE_0__.asString,
    // Total XMR received
    total_sent: cleaners__WEBPACK_IMPORTED_MODULE_0__.asString,
    // XMR possibly being spent
    unlock_time: cleaners__WEBPACK_IMPORTED_MODULE_0__.asNumber // Tx unlock time field

  })), [])
});
/**
 * Methods for talking to the Monero Lightwallet API.
 * See https://github.com/monero-project/meta/blob/master/api/lightwallet_rest.md
 */

var MyMoneroApi = /*#__PURE__*/function () {
  // Network options:
  // Dependency injection:
  // Maps from key identifiers (a bunch of concatenated stuff) to key images:
  function MyMoneroApi(cppBridge, options) {
    var _options$nettype;

    _classCallCheck(this, MyMoneroApi);

    this.apiKey = options.apiKey;
    this.apiUrl = options.apiServer;
    this.nettype = (_options$nettype = options.nettype) !== null && _options$nettype !== void 0 ? _options$nettype : 'MAINNET';
    this.fetch = options.fetch;
    this.cppBridge = cppBridge;
    this.keyImageCache = {};
  }

  _createClass(MyMoneroApi, [{
    key: "changeServer",
    value: function changeServer(apiUrl, apiKey) {
      this.apiKey = apiKey;
      this.apiUrl = apiUrl;
    }
    /**
     * Authenticates with the MyMonero light-wallet server.
     */

  }, {
    key: "login",
    value: function () {
      var _login = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(keys) {
        var address, privateViewKey, response;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                address = keys.address, privateViewKey = keys.privateViewKey;
                _context.next = 3;
                return this.fetchPostMyMonero('login', {
                  address: address,
                  api_key: this.apiKey,
                  create_account: true,
                  generated_locally: true,
                  view_key: privateViewKey
                });

              case 3:
                response = _context.sent;
                return _context.abrupt("return", asLoginResponse(response));

              case 5:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function login(_x) {
        return _login.apply(this, arguments);
      }

      return login;
    }()
  }, {
    key: "getTransactions",
    value: function () {
      var _getTransactions = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(keys) {
        var address, privateSpendKey, privateViewKey, publicSpendKey, response, parsed;
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                address = keys.address, privateSpendKey = keys.privateSpendKey, privateViewKey = keys.privateViewKey, publicSpendKey = keys.publicSpendKey;
                _context2.next = 3;
                return this.fetchPostMyMonero('get_address_txs', {
                  address: address,
                  api_key: this.apiKey,
                  view_key: privateViewKey
                });

              case 3:
                response = _context2.sent;
                _context2.next = 6;
                return _mymonero_utils_ResponseParser__WEBPACK_IMPORTED_MODULE_1__.Parsed_AddressTransactions__async(this.keyImageCache, asGetAddressTxsResponse(response), address, privateViewKey, publicSpendKey, privateSpendKey, this.cppBridge);

              case 6:
                parsed = _context2.sent;
                return _context2.abrupt("return", parsed.serialized_transactions);

              case 8:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      function getTransactions(_x2) {
        return _getTransactions.apply(this, arguments);
      }

      return getTransactions;
    }()
  }, {
    key: "getAddressInfo",
    value: function () {
      var _getAddressInfo = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(keys) {
        var address, privateSpendKey, privateViewKey, publicSpendKey, response, parsed;
        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                address = keys.address, privateSpendKey = keys.privateSpendKey, privateViewKey = keys.privateViewKey, publicSpendKey = keys.publicSpendKey;
                _context3.next = 3;
                return this.fetchPostMyMonero('get_address_info', {
                  address: address,
                  api_key: this.apiKey,
                  view_key: privateViewKey
                });

              case 3:
                response = _context3.sent;
                _context3.next = 6;
                return _mymonero_utils_ResponseParser__WEBPACK_IMPORTED_MODULE_1__.Parsed_AddressInfo__async(this.keyImageCache, asAddressInfoResponse(response), address, privateViewKey, publicSpendKey, privateSpendKey, this.cppBridge);

              case 6:
                parsed = _context3.sent;
                return _context3.abrupt("return", {
                  blockHeight: parsed.blockchain_height,
                  totalReceived: parsed.total_received_String,
                  lockedBalance: parsed.locked_balance_String,
                  totalSent: parsed.total_sent_String
                });

              case 8:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));

      function getAddressInfo(_x3) {
        return _getAddressInfo.apply(this, arguments);
      }

      return getAddressInfo;
    }()
  }, {
    key: "createTransaction",
    value: function () {
      var _createTransaction = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5(keys, opts) {
        var _this = this;

        var address, privateSpendKey, privateViewKey, publicSpendKey, _opts$isSweepTx, isSweepTx, paymentId, _opts$priority, priority, targets, unspentOuts, _i2, _unspentOuts$outputs2, out, randomOutsCb, destinations;

        return regeneratorRuntime.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                address = keys.address, privateSpendKey = keys.privateSpendKey, privateViewKey = keys.privateViewKey, publicSpendKey = keys.publicSpendKey;
                _opts$isSweepTx = opts.isSweepTx, isSweepTx = _opts$isSweepTx === void 0 ? false : _opts$isSweepTx, paymentId = opts.paymentId, _opts$priority = opts.priority, priority = _opts$priority === void 0 ? 1 : _opts$priority, targets = opts.targets; // Grab the UTXO set:

                _context5.next = 4;
                return this.fetchPostMyMonero('get_unspent_outs', {
                  address: address,
                  amount: '0',
                  api_key: this.apiKey,
                  dust_threshold: '2000000000',
                  mixin: 15,
                  use_dust: true,
                  view_key: privateViewKey
                });

              case 4:
                unspentOuts = _context5.sent;

                for (_i2 = 0, _unspentOuts$outputs2 = unspentOuts.outputs; _i2 < _unspentOuts$outputs2.length; _i2++) {
                  out = _unspentOuts$outputs2[_i2];
                  if (out.spend_key_images == null) out.spend_key_images = [];
                } // Grab some random outputs to mix in:


                randomOutsCb = /*#__PURE__*/function () {
                  var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(count) {
                    var amounts, i;
                    return regeneratorRuntime.wrap(function _callee4$(_context4) {
                      while (1) {
                        switch (_context4.prev = _context4.next) {
                          case 0:
                            amounts = [];

                            for (i = 0; i < count; ++i) {
                              amounts.push('0');
                            }

                            _context4.next = 4;
                            return _this.fetchPostMyMonero('get_random_outs', {
                              amounts: amounts,
                              api_key: _this.apiKey,
                              count: 16
                            });

                          case 4:
                            return _context4.abrupt("return", _context4.sent);

                          case 5:
                          case "end":
                            return _context4.stop();
                        }
                      }
                    }, _callee4);
                  }));

                  return function randomOutsCb(_x6) {
                    return _ref.apply(this, arguments);
                  };
                }();

                destinations = targets.map(function (t) {
                  return {
                    send_amount: t.amount,
                    to_address: t.targetAddress
                  };
                }); // Make the transaction:

                _context5.next = 10;
                return this.cppBridge.createTransaction({
                  destinations: destinations,
                  priority: priority,
                  address: address,
                  paymentId: paymentId,
                  privateViewKey: privateViewKey,
                  publicSpendKey: publicSpendKey,
                  privateSpendKey: privateSpendKey,
                  shouldSweep: isSweepTx,
                  nettype: this.nettype,
                  unspentOuts: unspentOuts,
                  randomOutsCb: randomOutsCb
                });

              case 10:
                return _context5.abrupt("return", _context5.sent);

              case 11:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, this);
      }));

      function createTransaction(_x4, _x5) {
        return _createTransaction.apply(this, arguments);
      }

      return createTransaction;
    }()
  }, {
    key: "broadcastTransaction",
    value: function () {
      var _broadcastTransaction = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee6(tx) {
        return regeneratorRuntime.wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                _context6.next = 2;
                return this.fetchPostMyMonero('submit_raw_tx', {
                  api_key: this.apiKey,
                  tx: tx
                });

              case 2:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6, this);
      }));

      function broadcastTransaction(_x7) {
        return _broadcastTransaction.apply(this, arguments);
      }

      return broadcastTransaction;
    }() // Private routines
    // ----------------

  }, {
    key: "fetchPostMyMonero",
    value: function () {
      var _fetchPostMyMonero = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee7(cmd, params) {
        var url, response;
        return regeneratorRuntime.wrap(function _callee7$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
                url = "".concat(this.apiUrl, "/").concat(cmd);
                _context7.next = 3;
                return this.fetch(url, {
                  body: JSON.stringify(params),
                  headers: {
                    'Content-Type': 'application/json',
                    Accept: 'application/json'
                  },
                  method: 'POST'
                });

              case 3:
                response = _context7.sent;

                if (response.ok) {
                  _context7.next = 6;
                  break;
                }

                throw new Error("The server returned error code ".concat(response.status, " for ").concat(url));

              case 6:
                _context7.next = 8;
                return response.json();

              case 8:
                return _context7.abrupt("return", _context7.sent);

              case 9:
              case "end":
                return _context7.stop();
            }
          }
        }, _callee7, this);
      }));

      function fetchPostMyMonero(_x8, _x9) {
        return _fetchPostMyMonero.apply(this, arguments);
      }

      return fetchPostMyMonero;
    }()
  }]);

  return MyMoneroApi;
}();

/***/ }),

/***/ "./src/moneroInfo.ts":
/*!***************************!*\
  !*** ./src/moneroInfo.ts ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MONERO_LWS_SERVER: () => (/* binding */ MONERO_LWS_SERVER),
/* harmony export */   currencyInfo: () => (/* binding */ currencyInfo)
/* harmony export */ });
var MONERO_LWS_SERVER = 'https://monerolws1.edge.app';
var defaultSettings = {
  enableCustomServers: false,
  moneroLightwalletServer: MONERO_LWS_SERVER,
  networkPrivacy: 'none'
};
var currencyInfo = {
  // Basic currency information:
  currencyCode: 'XMR',
  displayName: 'Monero',
  pluginId: 'monero',
  requiredConfirmations: 10,
  walletType: 'wallet:monero',
  defaultSettings: defaultSettings,
  addressExplorer: 'https://xmrchain.net/search?value=%s',
  transactionExplorer: 'https://blockchair.com/monero/transaction/%s?from=edgeapp',
  denominations: [// An array of Objects of the possible denominations for this currency
  {
    name: 'XMR',
    multiplier: '1000000000000',
    symbol: 'ɱ'
  }],
  metaTokens: [],
  unsafeMakeSpend: true,
  unsafeSyncNetwork: true,
  chainDisplayName: 'Monero',
  assetDisplayName: 'Monero'
};

/***/ }),

/***/ "./src/moneroPlugin.ts":
/*!*****************************!*\
  !*** ./src/moneroPlugin.ts ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   makeMoneroPlugin: () => (/* binding */ makeMoneroPlugin)
/* harmony export */ });
/* harmony import */ var _MoneroEngine__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./MoneroEngine */ "./src/MoneroEngine.ts");
/* harmony import */ var _moneroInfo__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./moneroInfo */ "./src/moneroInfo.ts");
/* harmony import */ var _MoneroTools__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./MoneroTools */ "./src/MoneroTools.ts");
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

/**
 * Created by paul on 8/8/17.
 */



function makeMoneroPlugin(env) {
  var tools = new _MoneroTools__WEBPACK_IMPORTED_MODULE_2__.MoneroTools(env);
  return {
    currencyInfo: _moneroInfo__WEBPACK_IMPORTED_MODULE_1__.currencyInfo,
    makeCurrencyEngine: function makeCurrencyEngine(walletInfo, opts) {
      return _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return (0,_MoneroEngine__WEBPACK_IMPORTED_MODULE_0__.makeCurrencyEngine)(env, tools, walletInfo, opts);

              case 2:
                return _context.abrupt("return", _context.sent);

              case 3:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    },
    makeCurrencyTools: function makeCurrencyTools() {
      return _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                return _context2.abrupt("return", tools);

              case 1:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }))();
    }
  };
}

/***/ }),

/***/ "./src/moneroTypes.ts":
/*!****************************!*\
  !*** ./src/moneroTypes.ts ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   asMoneroInitOptions: () => (/* binding */ asMoneroInitOptions),
/* harmony export */   asMoneroUserSettings: () => (/* binding */ asMoneroUserSettings),
/* harmony export */   asPrivateKeys: () => (/* binding */ asPrivateKeys),
/* harmony export */   asPublicKeys: () => (/* binding */ asPublicKeys),
/* harmony export */   asSafeWalletInfo: () => (/* binding */ asSafeWalletInfo),
/* harmony export */   asSeenTxCheckpoint: () => (/* binding */ asSeenTxCheckpoint),
/* harmony export */   makeSafeWalletInfo: () => (/* binding */ makeSafeWalletInfo),
/* harmony export */   wasSeenTxCheckpoint: () => (/* binding */ wasSeenTxCheckpoint)
/* harmony export */ });
/* harmony import */ var cleaners__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! cleaners */ "./node_modules/cleaners/lib/esm/cleaners.js");
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

/**
 * Created by paul on 8/26/17.
 */

var asMoneroInitOptions = (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asObject)({
  edgeApiKey: (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asOptional)(cleaners__WEBPACK_IMPORTED_MODULE_0__.asString, '')
});
var asMoneroUserSettings = (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asObject)({
  enableCustomServers: (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asMaybe)(cleaners__WEBPACK_IMPORTED_MODULE_0__.asBoolean, false),
  moneroLightwalletServer: (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asMaybe)(cleaners__WEBPACK_IMPORTED_MODULE_0__.asString),
  networkPrivacy: (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asOptional)((0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asValue)('none', 'nym'), 'none')
});
var asPrivateKeys = (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asObject)({
  moneroKey: cleaners__WEBPACK_IMPORTED_MODULE_0__.asString,
  moneroSpendKeyPrivate: cleaners__WEBPACK_IMPORTED_MODULE_0__.asString,
  moneroSpendKeyPublic: cleaners__WEBPACK_IMPORTED_MODULE_0__.asString
});
var asPublicKeys = (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asObject)({
  moneroAddress: cleaners__WEBPACK_IMPORTED_MODULE_0__.asString,
  moneroViewKeyPrivate: cleaners__WEBPACK_IMPORTED_MODULE_0__.asString,
  moneroViewKeyPublic: cleaners__WEBPACK_IMPORTED_MODULE_0__.asString,
  moneroSpendKeyPublic: cleaners__WEBPACK_IMPORTED_MODULE_0__.asString
});
var asSafeWalletInfo = (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asObject)({
  id: cleaners__WEBPACK_IMPORTED_MODULE_0__.asString,
  type: cleaners__WEBPACK_IMPORTED_MODULE_0__.asString,
  keys: asPublicKeys
});
var makeSafeWalletInfo = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(tools, walletInfo) {
    var safeWalletInfo, pubKeys;
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            // @ts-expect-error
            safeWalletInfo = {};

            if (!(typeof walletInfo.keys.moneroAddress !== 'string' || typeof walletInfo.keys.moneroViewKeyPrivate !== 'string' || typeof walletInfo.keys.moneroViewKeyPublic !== 'string' || typeof walletInfo.keys.moneroSpendKeyPublic !== 'string')) {
              _context.next = 6;
              break;
            }

            _context.next = 4;
            return tools.derivePublicKey(walletInfo);

          case 4:
            pubKeys = _context.sent;
            return _context.abrupt("return", {
              id: walletInfo.id,
              type: walletInfo.type,
              keys: {
                moneroAddress: pubKeys.moneroAddress,
                moneroViewKeyPrivate: pubKeys.moneroViewKeyPrivate,
                moneroViewKeyPublic: pubKeys.moneroViewKeyPublic,
                moneroSpendKeyPublic: pubKeys.moneroSpendKeyPublic
              }
            });

          case 6:
            return _context.abrupt("return", safeWalletInfo);

          case 7:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function makeSafeWalletInfo(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();
var asSeenTxCheckpoint = (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asCodec)(function (v) {
  return v == null ? undefined : parseInt((0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asString)(v));
}, function (v) {
  return v == null ? undefined : v.toString();
});
var wasSeenTxCheckpoint = (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.uncleaner)(asSeenTxCheckpoint);

/***/ }),

/***/ "./src/utils.ts":
/*!**********************!*\
  !*** ./src/utils.ts ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   cleanTxLogs: () => (/* binding */ cleanTxLogs),
/* harmony export */   normalizeAddress: () => (/* binding */ normalizeAddress)
/* harmony export */ });
/* harmony import */ var cleaners__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! cleaners */ "./node_modules/cleaners/lib/esm/cleaners.js");
/**
 * Created by paul on 8/26/17.
 */

function normalizeAddress(address) {
  return address.toLowerCase().replace('0x', '');
}
var asCleanTxLogs = (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asObject)({
  txid: cleaners__WEBPACK_IMPORTED_MODULE_0__.asString,
  spendTargets: (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asOptional)((0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asArray)((0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asObject)({
    currencyCode: cleaners__WEBPACK_IMPORTED_MODULE_0__.asString,
    nativeAmount: cleaners__WEBPACK_IMPORTED_MODULE_0__.asString,
    publicAddress: cleaners__WEBPACK_IMPORTED_MODULE_0__.asString,
    uniqueIdentifier: (0,cleaners__WEBPACK_IMPORTED_MODULE_0__.asOptional)(cleaners__WEBPACK_IMPORTED_MODULE_0__.asString)
  }))),
  signedTx: cleaners__WEBPACK_IMPORTED_MODULE_0__.asString
});
function cleanTxLogs(tx) {
  return JSON.stringify(asCleanTxLogs(tx));
}

/***/ }),

/***/ "./node_modules/base64-js/index.js":
/*!*****************************************!*\
  !*** ./node_modules/base64-js/index.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";


exports.byteLength = byteLength
exports.toByteArray = toByteArray
exports.fromByteArray = fromByteArray

var lookup = []
var revLookup = []
var Arr = typeof Uint8Array !== 'undefined' ? Uint8Array : Array

var code = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
for (var i = 0, len = code.length; i < len; ++i) {
  lookup[i] = code[i]
  revLookup[code.charCodeAt(i)] = i
}

// Support decoding URL-safe base64 strings, as Node.js does.
// See: https://en.wikipedia.org/wiki/Base64#URL_applications
revLookup['-'.charCodeAt(0)] = 62
revLookup['_'.charCodeAt(0)] = 63

function getLens (b64) {
  var len = b64.length

  if (len % 4 > 0) {
    throw new Error('Invalid string. Length must be a multiple of 4')
  }

  // Trim off extra bytes after placeholder bytes are found
  // See: https://github.com/beatgammit/base64-js/issues/42
  var validLen = b64.indexOf('=')
  if (validLen === -1) validLen = len

  var placeHoldersLen = validLen === len
    ? 0
    : 4 - (validLen % 4)

  return [validLen, placeHoldersLen]
}

// base64 is 4/3 + up to two characters of the original data
function byteLength (b64) {
  var lens = getLens(b64)
  var validLen = lens[0]
  var placeHoldersLen = lens[1]
  return ((validLen + placeHoldersLen) * 3 / 4) - placeHoldersLen
}

function _byteLength (b64, validLen, placeHoldersLen) {
  return ((validLen + placeHoldersLen) * 3 / 4) - placeHoldersLen
}

function toByteArray (b64) {
  var tmp
  var lens = getLens(b64)
  var validLen = lens[0]
  var placeHoldersLen = lens[1]

  var arr = new Arr(_byteLength(b64, validLen, placeHoldersLen))

  var curByte = 0

  // if there are placeholders, only get up to the last complete 4 chars
  var len = placeHoldersLen > 0
    ? validLen - 4
    : validLen

  for (var i = 0; i < len; i += 4) {
    tmp =
      (revLookup[b64.charCodeAt(i)] << 18) |
      (revLookup[b64.charCodeAt(i + 1)] << 12) |
      (revLookup[b64.charCodeAt(i + 2)] << 6) |
      revLookup[b64.charCodeAt(i + 3)]
    arr[curByte++] = (tmp >> 16) & 0xFF
    arr[curByte++] = (tmp >> 8) & 0xFF
    arr[curByte++] = tmp & 0xFF
  }

  if (placeHoldersLen === 2) {
    tmp =
      (revLookup[b64.charCodeAt(i)] << 2) |
      (revLookup[b64.charCodeAt(i + 1)] >> 4)
    arr[curByte++] = tmp & 0xFF
  }

  if (placeHoldersLen === 1) {
    tmp =
      (revLookup[b64.charCodeAt(i)] << 10) |
      (revLookup[b64.charCodeAt(i + 1)] << 4) |
      (revLookup[b64.charCodeAt(i + 2)] >> 2)
    arr[curByte++] = (tmp >> 8) & 0xFF
    arr[curByte++] = tmp & 0xFF
  }

  return arr
}

function tripletToBase64 (num) {
  return lookup[num >> 18 & 0x3F] +
    lookup[num >> 12 & 0x3F] +
    lookup[num >> 6 & 0x3F] +
    lookup[num & 0x3F]
}

function encodeChunk (uint8, start, end) {
  var tmp
  var output = []
  for (var i = start; i < end; i += 3) {
    tmp =
      ((uint8[i] << 16) & 0xFF0000) +
      ((uint8[i + 1] << 8) & 0xFF00) +
      (uint8[i + 2] & 0xFF)
    output.push(tripletToBase64(tmp))
  }
  return output.join('')
}

function fromByteArray (uint8) {
  var tmp
  var len = uint8.length
  var extraBytes = len % 3 // if we have 1 byte left, pad 2 bytes
  var parts = []
  var maxChunkLength = 16383 // must be multiple of 3

  // go through the array every three bytes, we'll deal with trailing stuff later
  for (var i = 0, len2 = len - extraBytes; i < len2; i += maxChunkLength) {
    parts.push(encodeChunk(
      uint8, i, (i + maxChunkLength) > len2 ? len2 : (i + maxChunkLength)
    ))
  }

  // pad the end with zeros, but make sure to not forget the extra bytes
  if (extraBytes === 1) {
    tmp = uint8[len - 1]
    parts.push(
      lookup[tmp >> 2] +
      lookup[(tmp << 4) & 0x3F] +
      '=='
    )
  } else if (extraBytes === 2) {
    tmp = (uint8[len - 2] << 8) + uint8[len - 1]
    parts.push(
      lookup[tmp >> 10] +
      lookup[(tmp >> 4) & 0x3F] +
      lookup[(tmp << 2) & 0x3F] +
      '='
    )
  }

  return parts.join('')
}


/***/ }),

/***/ "./node_modules/biggystring/lib/src/index.js":
/*!***************************************************!*\
  !*** ./node_modules/biggystring/lib/src/index.js ***!
  \***************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

/**
 * Created by paul on 7/25/17.
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.log10 = exports.toFixed = exports.toBns = exports.round = exports.ceil = exports.floor = exports.max = exports.abs = exports.min = exports.eq = exports.gte = exports.gt = exports.lte = exports.lt = exports.div = exports.sub = exports.mul = exports.add = void 0;
const bn_js_1 = __importDefault(__webpack_require__(/*! bn.js */ "./node_modules/bn.js/lib/bn.js"));
const SCI_NOTATION_REGEX = /^(-?\d*\.?\d*)e((?:\+|-)?\d+)$/;
// -----------------------------------------------------------------------------
// Public
// -----------------------------------------------------------------------------
function add(x1, y1, base = 10) {
    if (base !== 10 && base !== 16)
        throw new Error('Unsupported base');
    let { x, y, shift } = floatShifts(x1, y1);
    const xBase = isHex(x) ? 16 : 10;
    const yBase = isHex(y) ? 16 : 10;
    x = cropHex(x);
    y = cropHex(y);
    const xBN = new bn_js_1.default(x, xBase);
    const yBN = new bn_js_1.default(y, yBase);
    let out = xBN.add(yBN).toString(base);
    out = addDecimal(out, shift);
    return base === 10 ? out : out.replace(/^(-)?/, '$10x');
}
exports.add = add;
function mul(x1, y1, base = 10) {
    if (base !== 10 && base !== 16)
        throw new Error('Unsupported base');
    let { x, y, shift } = floatShifts(x1, y1);
    const xBase = isHex(x) ? 16 : 10;
    const yBase = isHex(y) ? 16 : 10;
    x = cropHex(x);
    y = cropHex(y);
    const xBN = new bn_js_1.default(x, xBase);
    const yBN = new bn_js_1.default(y, yBase);
    let out = xBN.mul(yBN).toString(base);
    out = addDecimal(out, shift * 2);
    return base === 10 ? out : out.replace(/^(-)?/, '$10x');
}
exports.mul = mul;
function sub(x1, y1, base = 10) {
    if (base !== 10 && base !== 16)
        throw new Error('Unsupported base');
    let { x, y, shift } = floatShifts(x1, y1);
    const xBase = isHex(x) ? 16 : 10;
    const yBase = isHex(y) ? 16 : 10;
    x = cropHex(x);
    y = cropHex(y);
    const xBN = new bn_js_1.default(x, xBase);
    const yBN = new bn_js_1.default(y, yBase);
    let out = xBN.sub(yBN).toString(base);
    out = addDecimal(out, shift);
    return base === 10 ? out : out.replace(/^(-)?/, '$10x');
}
exports.sub = sub;
function div(x1, y1, precision = 0, base = 10) {
    if (base !== 10 && precision > 0) {
        throw new Error('Cannot operate on floating point hex values');
    }
    if (base !== 10 && base !== 16)
        throw new Error('Unsupported base');
    let { x, y } = floatShifts(x1, y1, precision);
    const xBase = isHex(x) ? 16 : 10;
    const yBase = isHex(y) ? 16 : 10;
    x = cropHex(x);
    y = cropHex(y);
    const xBN = new bn_js_1.default(x, xBase);
    const yBN = new bn_js_1.default(y, yBase);
    let out = xBN.div(yBN).toString(base);
    out = addDecimal(out, precision);
    return base === 10 ? out : out.replace(/^(-)?/, '$10x');
}
exports.div = div;
function lt(x1, y1) {
    let { x, y } = floatShifts(x1, y1);
    const xBase = isHex(x) ? 16 : 10;
    const yBase = isHex(y) ? 16 : 10;
    x = cropHex(x);
    y = cropHex(y);
    const xBN = new bn_js_1.default(x, xBase);
    const yBN = new bn_js_1.default(y, yBase);
    return xBN.lt(yBN);
}
exports.lt = lt;
function lte(x1, y1) {
    let { x, y } = floatShifts(x1, y1);
    const xBase = isHex(x) ? 16 : 10;
    const yBase = isHex(y) ? 16 : 10;
    x = cropHex(x);
    y = cropHex(y);
    const xBN = new bn_js_1.default(x, xBase);
    const yBN = new bn_js_1.default(y, yBase);
    return xBN.lte(yBN);
}
exports.lte = lte;
function gt(x1, y1) {
    let { x, y } = floatShifts(x1, y1);
    const xBase = isHex(x) ? 16 : 10;
    const yBase = isHex(y) ? 16 : 10;
    x = cropHex(x);
    y = cropHex(y);
    const xBN = new bn_js_1.default(x, xBase);
    const yBN = new bn_js_1.default(y, yBase);
    return xBN.gt(yBN);
}
exports.gt = gt;
function gte(x1, y1) {
    let { x, y } = floatShifts(x1, y1);
    const xBase = isHex(x) ? 16 : 10;
    const yBase = isHex(y) ? 16 : 10;
    x = cropHex(x);
    y = cropHex(y);
    const xBN = new bn_js_1.default(x, xBase);
    const yBN = new bn_js_1.default(y, yBase);
    return xBN.gte(yBN);
}
exports.gte = gte;
function eq(x1, y1) {
    let { x, y } = floatShifts(x1, y1);
    const xBase = isHex(x) ? 16 : 10;
    const yBase = isHex(y) ? 16 : 10;
    x = cropHex(x);
    y = cropHex(y);
    const xBN = new bn_js_1.default(x, xBase);
    const yBN = new bn_js_1.default(y, yBase);
    return xBN.eq(yBN);
}
exports.eq = eq;
function min(x1, y1, base = 10) {
    let { x, y, shift } = floatShifts(x1, y1);
    const xBase = isHex(x) ? 16 : 10;
    const yBase = isHex(y) ? 16 : 10;
    x = cropHex(x);
    y = cropHex(y);
    const xBN = new bn_js_1.default(x, xBase);
    const yBN = new bn_js_1.default(y, yBase);
    let out;
    if (xBN.lte(yBN)) {
        out = xBN.toString(base);
    }
    else {
        out = yBN.toString(base);
    }
    out = addDecimal(out, shift);
    return base === 10 ? out : out.replace(/^(-)?/, '$10x');
}
exports.min = min;
function abs(x1, base = 10) {
    if (base !== 10 && base !== 16)
        throw new Error('Unsupported base');
    let { x, shift } = floatShifts(x1, '0');
    const xBase = isHex(x1) ? 16 : 10;
    x = cropHex(x);
    const xBN = new bn_js_1.default(x, xBase);
    let out = xBN.abs().toString(base);
    out = addDecimal(out, shift);
    return base === 10 ? out : out.replace(/^(-)?/, '$10x');
}
exports.abs = abs;
function max(x1, y1, base = 10) {
    let { x, y, shift } = floatShifts(x1, y1);
    const xBase = isHex(x) ? 16 : 10;
    const yBase = isHex(y) ? 16 : 10;
    x = cropHex(x);
    y = cropHex(y);
    const xBN = new bn_js_1.default(x, xBase);
    const yBN = new bn_js_1.default(y, yBase);
    let out;
    if (xBN.gte(yBN)) {
        out = xBN.toString(base);
    }
    else {
        out = yBN.toString(base);
    }
    out = addDecimal(out, shift);
    return base === 10 ? out : out.replace(/^(-)?/, '$10x');
}
exports.max = max;
exports.floor = (x1, precision) => precisionAdjust('floor', x1, precision);
exports.ceil = (x1, precision) => precisionAdjust('ceil', x1, precision);
exports.round = (x1, precision) => precisionAdjust('round', x1, precision);
function toBns(n) {
    let out = typeof n === 'number' ? n.toString() : n.replace(/^\s+|\s+$/g, '');
    if (out === '' || out === '.') {
        out = '0';
    }
    // Handle scientific notation
    const match = out.match(SCI_NOTATION_REGEX);
    if (match != null) {
        const base = match[1];
        const exponent = parseInt(match[2]);
        out = sciNotation(base, exponent);
    }
    validate(out);
    return out;
}
exports.toBns = toBns;
function toFixed(x1, minPrecision = 2, maxPrecision = 8) {
    let x = toBns(x1);
    let negative = false;
    let out = '';
    if (x.includes('-')) {
        negative = true;
        // Remove any leading '-' signs
        x = x.replace(/^-+/, '');
    }
    x = trimEnd(x);
    // Number of decimal places number has
    const decimalPos = x.indexOf('.');
    if (decimalPos === -1) {
        out = x + '.' + addZeros('', minPrecision);
    }
    else {
        const numDecimals = x.length - decimalPos - 1;
        if (numDecimals > maxPrecision) {
            out = x.substr(0, x.length - (numDecimals - maxPrecision));
        }
        else if (numDecimals < minPrecision) {
            out = x + addZeros('', minPrecision - numDecimals);
        }
        else {
            out = x;
        }
    }
    // Remove trailing "." if there is one
    out = out.replace(/\.+$/, '');
    if (negative && out !== '0') {
        out = '-' + out;
    }
    return out;
}
exports.toFixed = toFixed;
function log10(x) {
    if (!(x.match(/^[0-1]+$/g) !== null)) {
        throw new Error('InvalidLogInputValue: Must be a power of 10');
    }
    if (!x.startsWith('1')) {
        throw new Error('InvalidLogInputValue: Must not have leading zeros');
    }
    if ((x.match(/1/g) || []).length > 1) {
        throw new Error('InvalidLogInputValue: Must be power of 10.');
    }
    return (x.match(/0/g) || []).length;
}
exports.log10 = log10;
// -----------------------------------------------------------------------------
// Private
// -----------------------------------------------------------------------------
function addDecimal(x, shift) {
    if (shift === 0)
        return x;
    let isNegative = false;
    if (x.slice(0, 1) === '-') {
        isNegative = true;
        x = x.slice(1);
    }
    let out;
    if (shift > x.length) {
        out = '0.' + addZeros('', shift - x.length) + x;
    }
    else {
        out =
            x.substr(0, x.length - shift) + '.' + x.substr(x.length - shift, x.length);
    }
    out = trimEnd(out);
    if (isNegative) {
        out = `-${out}`;
    }
    return out;
}
function addZeros(val, numZeros) {
    let out = val;
    for (let n = 0; n < numZeros; n++) {
        out += '0';
    }
    return out;
}
function cropHex(x) {
    return x.replace('0x', '');
}
// Takes two floating point (base 10) numbers and finds the multiplier needed to make them both
// operable as a integer
function floatShifts(xStart, yStart, moreShift) {
    let x = toBns(xStart);
    let y = toBns(yStart);
    let xPos = x.indexOf('.');
    let yPos = y.indexOf('.');
    const xHex = isHex(x);
    const yHex = isHex(y);
    if (xPos !== -1) {
        // Remove trailing zeros
        x = trimEnd(x);
        xPos = x.indexOf('.');
    }
    if (yPos !== -1) {
        // Remove trailing zeros
        y = trimEnd(y);
        yPos = y.indexOf('.');
    }
    if (xPos !== -1 || yPos !== -1 || typeof moreShift === 'number') {
        if (xHex || yHex) {
            throw new Error('Cannot operate on base16 float values');
        }
        let xShift = 0;
        let yShift = 0;
        if (xPos !== -1) {
            xShift = x.length - xPos - 1;
        }
        if (yPos !== -1) {
            yShift = y.length - yPos - 1;
        }
        const shift = xShift > yShift ? xShift : yShift;
        let moreS = 0;
        if (typeof moreShift === 'number') {
            moreS = moreShift;
        }
        x = addZeros(x.replace('.', ''), shift + moreS - xShift);
        y = addZeros(y.replace('.', ''), shift - yShift);
        const out = { x, y, shift };
        return out;
    }
    else {
        // Both x and y are int and need no float conversion
        const out = {
            x,
            y,
            shift: 0,
        };
        return out;
    }
}
function isHex(x1) {
    const x = toBns(x1);
    if (x.startsWith('0x') ||
        x.startsWith('-0x') ||
        x.toLowerCase().includes('a') ||
        x.toLowerCase().includes('b') ||
        x.toLowerCase().includes('c') ||
        x.toLowerCase().includes('d') ||
        x.toLowerCase().includes('e') ||
        x.toLowerCase().includes('f')) {
        return true;
    }
    else {
        return false;
    }
}
function precisionAdjust(type, x1, precision = 0) {
    var _a, _b;
    let x = toBns(x1);
    let negative = false;
    let out = '';
    if (x.includes('-')) {
        negative = true;
        // Remove any leading '-' signs
        x = x.replace(/^-+/, '');
    }
    const [whole, decimal = ''] = x.split('.');
    // Number of decimal places number has
    const decimalPos = x.indexOf('.');
    const checkIndex = decimalPos !== -1 ? decimalPos - precision : x.length - precision;
    const combined = whole + decimal;
    if (type === 'round') {
        const checkValue = (_a = combined[checkIndex]) !== null && _a !== void 0 ? _a : '0';
        if (gte(checkValue, '5')) {
            type = 'ceil';
        }
        else {
            type = 'floor';
        }
    }
    // Zero out lower precision places
    const numZeros = Math.max(combined.length - checkIndex + 1, 0);
    const zeroString = new Array(numZeros).join('0');
    let outCombined = combined.substring(0, checkIndex) + zeroString;
    const bumpUp = gt(combined.substring(checkIndex), '0');
    if (type === 'ceil' && bumpUp) {
        const addValue = '1' + zeroString;
        // Leading zeros get removed after an `add`. Save the number of leading zeros
        // and add them back
        const leadingZeros = ((_b = outCombined.match(/^0+/)) !== null && _b !== void 0 ? _b : [''])[0].length;
        const leadingZerosString = new Array(leadingZeros).join('0');
        outCombined = leadingZerosString + add(outCombined, addValue);
    }
    const newDecimalPos = decimalPos + (outCombined.length - combined.length);
    // Add back the decimal
    if (decimalPos !== -1) {
        out =
            outCombined.substring(0, newDecimalPos) +
                '.' +
                outCombined.substring(newDecimalPos);
    }
    else {
        out = outCombined;
    }
    out = trimEnd(out);
    if (negative && out !== '0') {
        out = '-' + out;
    }
    return out;
}
function sciNotation(x1, exponent) {
    const magnitude = exponent >= 0
        ? '1' + '0'.repeat(Math.abs(exponent)) // 5.8e7 -> 58000000
        : `0.${'0'.repeat(Math.abs(exponent) - 1)}1`; // 5.8e-7 -> 0.00000058
    return mul(x1, magnitude);
}
// Remove starting and trailing zeros and decimal
function trimEnd(val) {
    // Remove starting zeros if there are any
    let out = val.replace(/^0+/, '');
    out = out.replace(/^\.+/, '0.');
    if (out.includes('.')) {
        // Remove trailing zeros
        out = out.replace(/0+$/, '');
        // Remove trailing "." if there is one
        out = out.replace(/\.+$/, '');
        if (out === '') {
            out = '0';
        }
    }
    if (out === '') {
        out = '0';
    }
    return out;
}
function validate(...args) {
    for (const arg of args) {
        if (arg.split('.').length - 1 > 1) {
            throw new Error(`Invalid number: more than one decimal point '${arg}'`);
        }
        if (arg.split('-').length - 1 > 1) {
            throw new Error(`Invalid number: more than one negative sign '${arg}'`);
        }
        if (!/^-?(?:0x[0-9A-Fa-f]+|(?:\d+(?:\.\d*)?|\.\d+))$/.test(arg)) {
            throw new Error(`Invalid number: non-number characters '${arg}'`);
        }
    }
}
//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/bn.js/lib/bn.js":
/*!**************************************!*\
  !*** ./node_modules/bn.js/lib/bn.js ***!
  \**************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

/* module decorator */ module = __webpack_require__.nmd(module);
(function (module, exports) {
  'use strict';

  // Utils
  function assert (val, msg) {
    if (!val) throw new Error(msg || 'Assertion failed');
  }

  // Could use `inherits` module, but don't want to move from single file
  // architecture yet.
  function inherits (ctor, superCtor) {
    ctor.super_ = superCtor;
    var TempCtor = function () {};
    TempCtor.prototype = superCtor.prototype;
    ctor.prototype = new TempCtor();
    ctor.prototype.constructor = ctor;
  }

  // BN

  function BN (number, base, endian) {
    if (BN.isBN(number)) {
      return number;
    }

    this.negative = 0;
    this.words = null;
    this.length = 0;

    // Reduction context
    this.red = null;

    if (number !== null) {
      if (base === 'le' || base === 'be') {
        endian = base;
        base = 10;
      }

      this._init(number || 0, base || 10, endian || 'be');
    }
  }
  if (typeof module === 'object') {
    module.exports = BN;
  } else {
    exports.BN = BN;
  }

  BN.BN = BN;
  BN.wordSize = 26;

  var Buffer;
  try {
    if (typeof window !== 'undefined' && typeof window.Buffer !== 'undefined') {
      Buffer = window.Buffer;
    } else {
      Buffer = (__webpack_require__(/*! buffer */ "./node_modules/buffer/index.js").Buffer);
    }
  } catch (e) {
  }

  BN.isBN = function isBN (num) {
    if (num instanceof BN) {
      return true;
    }

    return num !== null && typeof num === 'object' &&
      num.constructor.wordSize === BN.wordSize && Array.isArray(num.words);
  };

  BN.max = function max (left, right) {
    if (left.cmp(right) > 0) return left;
    return right;
  };

  BN.min = function min (left, right) {
    if (left.cmp(right) < 0) return left;
    return right;
  };

  BN.prototype._init = function init (number, base, endian) {
    if (typeof number === 'number') {
      return this._initNumber(number, base, endian);
    }

    if (typeof number === 'object') {
      return this._initArray(number, base, endian);
    }

    if (base === 'hex') {
      base = 16;
    }
    assert(base === (base | 0) && base >= 2 && base <= 36);

    number = number.toString().replace(/\s+/g, '');
    var start = 0;
    if (number[0] === '-') {
      start++;
      this.negative = 1;
    }

    if (start < number.length) {
      if (base === 16) {
        this._parseHex(number, start, endian);
      } else {
        this._parseBase(number, base, start);
        if (endian === 'le') {
          this._initArray(this.toArray(), base, endian);
        }
      }
    }
  };

  BN.prototype._initNumber = function _initNumber (number, base, endian) {
    if (number < 0) {
      this.negative = 1;
      number = -number;
    }
    if (number < 0x4000000) {
      this.words = [ number & 0x3ffffff ];
      this.length = 1;
    } else if (number < 0x10000000000000) {
      this.words = [
        number & 0x3ffffff,
        (number / 0x4000000) & 0x3ffffff
      ];
      this.length = 2;
    } else {
      assert(number < 0x20000000000000); // 2 ^ 53 (unsafe)
      this.words = [
        number & 0x3ffffff,
        (number / 0x4000000) & 0x3ffffff,
        1
      ];
      this.length = 3;
    }

    if (endian !== 'le') return;

    // Reverse the bytes
    this._initArray(this.toArray(), base, endian);
  };

  BN.prototype._initArray = function _initArray (number, base, endian) {
    // Perhaps a Uint8Array
    assert(typeof number.length === 'number');
    if (number.length <= 0) {
      this.words = [ 0 ];
      this.length = 1;
      return this;
    }

    this.length = Math.ceil(number.length / 3);
    this.words = new Array(this.length);
    for (var i = 0; i < this.length; i++) {
      this.words[i] = 0;
    }

    var j, w;
    var off = 0;
    if (endian === 'be') {
      for (i = number.length - 1, j = 0; i >= 0; i -= 3) {
        w = number[i] | (number[i - 1] << 8) | (number[i - 2] << 16);
        this.words[j] |= (w << off) & 0x3ffffff;
        this.words[j + 1] = (w >>> (26 - off)) & 0x3ffffff;
        off += 24;
        if (off >= 26) {
          off -= 26;
          j++;
        }
      }
    } else if (endian === 'le') {
      for (i = 0, j = 0; i < number.length; i += 3) {
        w = number[i] | (number[i + 1] << 8) | (number[i + 2] << 16);
        this.words[j] |= (w << off) & 0x3ffffff;
        this.words[j + 1] = (w >>> (26 - off)) & 0x3ffffff;
        off += 24;
        if (off >= 26) {
          off -= 26;
          j++;
        }
      }
    }
    return this.strip();
  };

  function parseHex4Bits (string, index) {
    var c = string.charCodeAt(index);
    // 'A' - 'F'
    if (c >= 65 && c <= 70) {
      return c - 55;
    // 'a' - 'f'
    } else if (c >= 97 && c <= 102) {
      return c - 87;
    // '0' - '9'
    } else {
      return (c - 48) & 0xf;
    }
  }

  function parseHexByte (string, lowerBound, index) {
    var r = parseHex4Bits(string, index);
    if (index - 1 >= lowerBound) {
      r |= parseHex4Bits(string, index - 1) << 4;
    }
    return r;
  }

  BN.prototype._parseHex = function _parseHex (number, start, endian) {
    // Create possibly bigger array to ensure that it fits the number
    this.length = Math.ceil((number.length - start) / 6);
    this.words = new Array(this.length);
    for (var i = 0; i < this.length; i++) {
      this.words[i] = 0;
    }

    // 24-bits chunks
    var off = 0;
    var j = 0;

    var w;
    if (endian === 'be') {
      for (i = number.length - 1; i >= start; i -= 2) {
        w = parseHexByte(number, start, i) << off;
        this.words[j] |= w & 0x3ffffff;
        if (off >= 18) {
          off -= 18;
          j += 1;
          this.words[j] |= w >>> 26;
        } else {
          off += 8;
        }
      }
    } else {
      var parseLength = number.length - start;
      for (i = parseLength % 2 === 0 ? start + 1 : start; i < number.length; i += 2) {
        w = parseHexByte(number, start, i) << off;
        this.words[j] |= w & 0x3ffffff;
        if (off >= 18) {
          off -= 18;
          j += 1;
          this.words[j] |= w >>> 26;
        } else {
          off += 8;
        }
      }
    }

    this.strip();
  };

  function parseBase (str, start, end, mul) {
    var r = 0;
    var len = Math.min(str.length, end);
    for (var i = start; i < len; i++) {
      var c = str.charCodeAt(i) - 48;

      r *= mul;

      // 'a'
      if (c >= 49) {
        r += c - 49 + 0xa;

      // 'A'
      } else if (c >= 17) {
        r += c - 17 + 0xa;

      // '0' - '9'
      } else {
        r += c;
      }
    }
    return r;
  }

  BN.prototype._parseBase = function _parseBase (number, base, start) {
    // Initialize as zero
    this.words = [ 0 ];
    this.length = 1;

    // Find length of limb in base
    for (var limbLen = 0, limbPow = 1; limbPow <= 0x3ffffff; limbPow *= base) {
      limbLen++;
    }
    limbLen--;
    limbPow = (limbPow / base) | 0;

    var total = number.length - start;
    var mod = total % limbLen;
    var end = Math.min(total, total - mod) + start;

    var word = 0;
    for (var i = start; i < end; i += limbLen) {
      word = parseBase(number, i, i + limbLen, base);

      this.imuln(limbPow);
      if (this.words[0] + word < 0x4000000) {
        this.words[0] += word;
      } else {
        this._iaddn(word);
      }
    }

    if (mod !== 0) {
      var pow = 1;
      word = parseBase(number, i, number.length, base);

      for (i = 0; i < mod; i++) {
        pow *= base;
      }

      this.imuln(pow);
      if (this.words[0] + word < 0x4000000) {
        this.words[0] += word;
      } else {
        this._iaddn(word);
      }
    }

    this.strip();
  };

  BN.prototype.copy = function copy (dest) {
    dest.words = new Array(this.length);
    for (var i = 0; i < this.length; i++) {
      dest.words[i] = this.words[i];
    }
    dest.length = this.length;
    dest.negative = this.negative;
    dest.red = this.red;
  };

  BN.prototype.clone = function clone () {
    var r = new BN(null);
    this.copy(r);
    return r;
  };

  BN.prototype._expand = function _expand (size) {
    while (this.length < size) {
      this.words[this.length++] = 0;
    }
    return this;
  };

  // Remove leading `0` from `this`
  BN.prototype.strip = function strip () {
    while (this.length > 1 && this.words[this.length - 1] === 0) {
      this.length--;
    }
    return this._normSign();
  };

  BN.prototype._normSign = function _normSign () {
    // -0 = 0
    if (this.length === 1 && this.words[0] === 0) {
      this.negative = 0;
    }
    return this;
  };

  BN.prototype.inspect = function inspect () {
    return (this.red ? '<BN-R: ' : '<BN: ') + this.toString(16) + '>';
  };

  /*

  var zeros = [];
  var groupSizes = [];
  var groupBases = [];

  var s = '';
  var i = -1;
  while (++i < BN.wordSize) {
    zeros[i] = s;
    s += '0';
  }
  groupSizes[0] = 0;
  groupSizes[1] = 0;
  groupBases[0] = 0;
  groupBases[1] = 0;
  var base = 2 - 1;
  while (++base < 36 + 1) {
    var groupSize = 0;
    var groupBase = 1;
    while (groupBase < (1 << BN.wordSize) / base) {
      groupBase *= base;
      groupSize += 1;
    }
    groupSizes[base] = groupSize;
    groupBases[base] = groupBase;
  }

  */

  var zeros = [
    '',
    '0',
    '00',
    '000',
    '0000',
    '00000',
    '000000',
    '0000000',
    '00000000',
    '000000000',
    '0000000000',
    '00000000000',
    '000000000000',
    '0000000000000',
    '00000000000000',
    '000000000000000',
    '0000000000000000',
    '00000000000000000',
    '000000000000000000',
    '0000000000000000000',
    '00000000000000000000',
    '000000000000000000000',
    '0000000000000000000000',
    '00000000000000000000000',
    '000000000000000000000000',
    '0000000000000000000000000'
  ];

  var groupSizes = [
    0, 0,
    25, 16, 12, 11, 10, 9, 8,
    8, 7, 7, 7, 7, 6, 6,
    6, 6, 6, 6, 6, 5, 5,
    5, 5, 5, 5, 5, 5, 5,
    5, 5, 5, 5, 5, 5, 5
  ];

  var groupBases = [
    0, 0,
    33554432, 43046721, 16777216, 48828125, 60466176, 40353607, 16777216,
    43046721, 10000000, 19487171, 35831808, 62748517, 7529536, 11390625,
    16777216, 24137569, 34012224, 47045881, 64000000, 4084101, 5153632,
    6436343, 7962624, 9765625, 11881376, 14348907, 17210368, 20511149,
    24300000, 28629151, 33554432, 39135393, 45435424, 52521875, 60466176
  ];

  BN.prototype.toString = function toString (base, padding) {
    base = base || 10;
    padding = padding | 0 || 1;

    var out;
    if (base === 16 || base === 'hex') {
      out = '';
      var off = 0;
      var carry = 0;
      for (var i = 0; i < this.length; i++) {
        var w = this.words[i];
        var word = (((w << off) | carry) & 0xffffff).toString(16);
        carry = (w >>> (24 - off)) & 0xffffff;
        if (carry !== 0 || i !== this.length - 1) {
          out = zeros[6 - word.length] + word + out;
        } else {
          out = word + out;
        }
        off += 2;
        if (off >= 26) {
          off -= 26;
          i--;
        }
      }
      if (carry !== 0) {
        out = carry.toString(16) + out;
      }
      while (out.length % padding !== 0) {
        out = '0' + out;
      }
      if (this.negative !== 0) {
        out = '-' + out;
      }
      return out;
    }

    if (base === (base | 0) && base >= 2 && base <= 36) {
      // var groupSize = Math.floor(BN.wordSize * Math.LN2 / Math.log(base));
      var groupSize = groupSizes[base];
      // var groupBase = Math.pow(base, groupSize);
      var groupBase = groupBases[base];
      out = '';
      var c = this.clone();
      c.negative = 0;
      while (!c.isZero()) {
        var r = c.modn(groupBase).toString(base);
        c = c.idivn(groupBase);

        if (!c.isZero()) {
          out = zeros[groupSize - r.length] + r + out;
        } else {
          out = r + out;
        }
      }
      if (this.isZero()) {
        out = '0' + out;
      }
      while (out.length % padding !== 0) {
        out = '0' + out;
      }
      if (this.negative !== 0) {
        out = '-' + out;
      }
      return out;
    }

    assert(false, 'Base should be between 2 and 36');
  };

  BN.prototype.toNumber = function toNumber () {
    var ret = this.words[0];
    if (this.length === 2) {
      ret += this.words[1] * 0x4000000;
    } else if (this.length === 3 && this.words[2] === 0x01) {
      // NOTE: at this stage it is known that the top bit is set
      ret += 0x10000000000000 + (this.words[1] * 0x4000000);
    } else if (this.length > 2) {
      assert(false, 'Number can only safely store up to 53 bits');
    }
    return (this.negative !== 0) ? -ret : ret;
  };

  BN.prototype.toJSON = function toJSON () {
    return this.toString(16);
  };

  BN.prototype.toBuffer = function toBuffer (endian, length) {
    assert(typeof Buffer !== 'undefined');
    return this.toArrayLike(Buffer, endian, length);
  };

  BN.prototype.toArray = function toArray (endian, length) {
    return this.toArrayLike(Array, endian, length);
  };

  BN.prototype.toArrayLike = function toArrayLike (ArrayType, endian, length) {
    var byteLength = this.byteLength();
    var reqLength = length || Math.max(1, byteLength);
    assert(byteLength <= reqLength, 'byte array longer than desired length');
    assert(reqLength > 0, 'Requested array length <= 0');

    this.strip();
    var littleEndian = endian === 'le';
    var res = new ArrayType(reqLength);

    var b, i;
    var q = this.clone();
    if (!littleEndian) {
      // Assume big-endian
      for (i = 0; i < reqLength - byteLength; i++) {
        res[i] = 0;
      }

      for (i = 0; !q.isZero(); i++) {
        b = q.andln(0xff);
        q.iushrn(8);

        res[reqLength - i - 1] = b;
      }
    } else {
      for (i = 0; !q.isZero(); i++) {
        b = q.andln(0xff);
        q.iushrn(8);

        res[i] = b;
      }

      for (; i < reqLength; i++) {
        res[i] = 0;
      }
    }

    return res;
  };

  if (Math.clz32) {
    BN.prototype._countBits = function _countBits (w) {
      return 32 - Math.clz32(w);
    };
  } else {
    BN.prototype._countBits = function _countBits (w) {
      var t = w;
      var r = 0;
      if (t >= 0x1000) {
        r += 13;
        t >>>= 13;
      }
      if (t >= 0x40) {
        r += 7;
        t >>>= 7;
      }
      if (t >= 0x8) {
        r += 4;
        t >>>= 4;
      }
      if (t >= 0x02) {
        r += 2;
        t >>>= 2;
      }
      return r + t;
    };
  }

  BN.prototype._zeroBits = function _zeroBits (w) {
    // Short-cut
    if (w === 0) return 26;

    var t = w;
    var r = 0;
    if ((t & 0x1fff) === 0) {
      r += 13;
      t >>>= 13;
    }
    if ((t & 0x7f) === 0) {
      r += 7;
      t >>>= 7;
    }
    if ((t & 0xf) === 0) {
      r += 4;
      t >>>= 4;
    }
    if ((t & 0x3) === 0) {
      r += 2;
      t >>>= 2;
    }
    if ((t & 0x1) === 0) {
      r++;
    }
    return r;
  };

  // Return number of used bits in a BN
  BN.prototype.bitLength = function bitLength () {
    var w = this.words[this.length - 1];
    var hi = this._countBits(w);
    return (this.length - 1) * 26 + hi;
  };

  function toBitArray (num) {
    var w = new Array(num.bitLength());

    for (var bit = 0; bit < w.length; bit++) {
      var off = (bit / 26) | 0;
      var wbit = bit % 26;

      w[bit] = (num.words[off] & (1 << wbit)) >>> wbit;
    }

    return w;
  }

  // Number of trailing zero bits
  BN.prototype.zeroBits = function zeroBits () {
    if (this.isZero()) return 0;

    var r = 0;
    for (var i = 0; i < this.length; i++) {
      var b = this._zeroBits(this.words[i]);
      r += b;
      if (b !== 26) break;
    }
    return r;
  };

  BN.prototype.byteLength = function byteLength () {
    return Math.ceil(this.bitLength() / 8);
  };

  BN.prototype.toTwos = function toTwos (width) {
    if (this.negative !== 0) {
      return this.abs().inotn(width).iaddn(1);
    }
    return this.clone();
  };

  BN.prototype.fromTwos = function fromTwos (width) {
    if (this.testn(width - 1)) {
      return this.notn(width).iaddn(1).ineg();
    }
    return this.clone();
  };

  BN.prototype.isNeg = function isNeg () {
    return this.negative !== 0;
  };

  // Return negative clone of `this`
  BN.prototype.neg = function neg () {
    return this.clone().ineg();
  };

  BN.prototype.ineg = function ineg () {
    if (!this.isZero()) {
      this.negative ^= 1;
    }

    return this;
  };

  // Or `num` with `this` in-place
  BN.prototype.iuor = function iuor (num) {
    while (this.length < num.length) {
      this.words[this.length++] = 0;
    }

    for (var i = 0; i < num.length; i++) {
      this.words[i] = this.words[i] | num.words[i];
    }

    return this.strip();
  };

  BN.prototype.ior = function ior (num) {
    assert((this.negative | num.negative) === 0);
    return this.iuor(num);
  };

  // Or `num` with `this`
  BN.prototype.or = function or (num) {
    if (this.length > num.length) return this.clone().ior(num);
    return num.clone().ior(this);
  };

  BN.prototype.uor = function uor (num) {
    if (this.length > num.length) return this.clone().iuor(num);
    return num.clone().iuor(this);
  };

  // And `num` with `this` in-place
  BN.prototype.iuand = function iuand (num) {
    // b = min-length(num, this)
    var b;
    if (this.length > num.length) {
      b = num;
    } else {
      b = this;
    }

    for (var i = 0; i < b.length; i++) {
      this.words[i] = this.words[i] & num.words[i];
    }

    this.length = b.length;

    return this.strip();
  };

  BN.prototype.iand = function iand (num) {
    assert((this.negative | num.negative) === 0);
    return this.iuand(num);
  };

  // And `num` with `this`
  BN.prototype.and = function and (num) {
    if (this.length > num.length) return this.clone().iand(num);
    return num.clone().iand(this);
  };

  BN.prototype.uand = function uand (num) {
    if (this.length > num.length) return this.clone().iuand(num);
    return num.clone().iuand(this);
  };

  // Xor `num` with `this` in-place
  BN.prototype.iuxor = function iuxor (num) {
    // a.length > b.length
    var a;
    var b;
    if (this.length > num.length) {
      a = this;
      b = num;
    } else {
      a = num;
      b = this;
    }

    for (var i = 0; i < b.length; i++) {
      this.words[i] = a.words[i] ^ b.words[i];
    }

    if (this !== a) {
      for (; i < a.length; i++) {
        this.words[i] = a.words[i];
      }
    }

    this.length = a.length;

    return this.strip();
  };

  BN.prototype.ixor = function ixor (num) {
    assert((this.negative | num.negative) === 0);
    return this.iuxor(num);
  };

  // Xor `num` with `this`
  BN.prototype.xor = function xor (num) {
    if (this.length > num.length) return this.clone().ixor(num);
    return num.clone().ixor(this);
  };

  BN.prototype.uxor = function uxor (num) {
    if (this.length > num.length) return this.clone().iuxor(num);
    return num.clone().iuxor(this);
  };

  // Not ``this`` with ``width`` bitwidth
  BN.prototype.inotn = function inotn (width) {
    assert(typeof width === 'number' && width >= 0);

    var bytesNeeded = Math.ceil(width / 26) | 0;
    var bitsLeft = width % 26;

    // Extend the buffer with leading zeroes
    this._expand(bytesNeeded);

    if (bitsLeft > 0) {
      bytesNeeded--;
    }

    // Handle complete words
    for (var i = 0; i < bytesNeeded; i++) {
      this.words[i] = ~this.words[i] & 0x3ffffff;
    }

    // Handle the residue
    if (bitsLeft > 0) {
      this.words[i] = ~this.words[i] & (0x3ffffff >> (26 - bitsLeft));
    }

    // And remove leading zeroes
    return this.strip();
  };

  BN.prototype.notn = function notn (width) {
    return this.clone().inotn(width);
  };

  // Set `bit` of `this`
  BN.prototype.setn = function setn (bit, val) {
    assert(typeof bit === 'number' && bit >= 0);

    var off = (bit / 26) | 0;
    var wbit = bit % 26;

    this._expand(off + 1);

    if (val) {
      this.words[off] = this.words[off] | (1 << wbit);
    } else {
      this.words[off] = this.words[off] & ~(1 << wbit);
    }

    return this.strip();
  };

  // Add `num` to `this` in-place
  BN.prototype.iadd = function iadd (num) {
    var r;

    // negative + positive
    if (this.negative !== 0 && num.negative === 0) {
      this.negative = 0;
      r = this.isub(num);
      this.negative ^= 1;
      return this._normSign();

    // positive + negative
    } else if (this.negative === 0 && num.negative !== 0) {
      num.negative = 0;
      r = this.isub(num);
      num.negative = 1;
      return r._normSign();
    }

    // a.length > b.length
    var a, b;
    if (this.length > num.length) {
      a = this;
      b = num;
    } else {
      a = num;
      b = this;
    }

    var carry = 0;
    for (var i = 0; i < b.length; i++) {
      r = (a.words[i] | 0) + (b.words[i] | 0) + carry;
      this.words[i] = r & 0x3ffffff;
      carry = r >>> 26;
    }
    for (; carry !== 0 && i < a.length; i++) {
      r = (a.words[i] | 0) + carry;
      this.words[i] = r & 0x3ffffff;
      carry = r >>> 26;
    }

    this.length = a.length;
    if (carry !== 0) {
      this.words[this.length] = carry;
      this.length++;
    // Copy the rest of the words
    } else if (a !== this) {
      for (; i < a.length; i++) {
        this.words[i] = a.words[i];
      }
    }

    return this;
  };

  // Add `num` to `this`
  BN.prototype.add = function add (num) {
    var res;
    if (num.negative !== 0 && this.negative === 0) {
      num.negative = 0;
      res = this.sub(num);
      num.negative ^= 1;
      return res;
    } else if (num.negative === 0 && this.negative !== 0) {
      this.negative = 0;
      res = num.sub(this);
      this.negative = 1;
      return res;
    }

    if (this.length > num.length) return this.clone().iadd(num);

    return num.clone().iadd(this);
  };

  // Subtract `num` from `this` in-place
  BN.prototype.isub = function isub (num) {
    // this - (-num) = this + num
    if (num.negative !== 0) {
      num.negative = 0;
      var r = this.iadd(num);
      num.negative = 1;
      return r._normSign();

    // -this - num = -(this + num)
    } else if (this.negative !== 0) {
      this.negative = 0;
      this.iadd(num);
      this.negative = 1;
      return this._normSign();
    }

    // At this point both numbers are positive
    var cmp = this.cmp(num);

    // Optimization - zeroify
    if (cmp === 0) {
      this.negative = 0;
      this.length = 1;
      this.words[0] = 0;
      return this;
    }

    // a > b
    var a, b;
    if (cmp > 0) {
      a = this;
      b = num;
    } else {
      a = num;
      b = this;
    }

    var carry = 0;
    for (var i = 0; i < b.length; i++) {
      r = (a.words[i] | 0) - (b.words[i] | 0) + carry;
      carry = r >> 26;
      this.words[i] = r & 0x3ffffff;
    }
    for (; carry !== 0 && i < a.length; i++) {
      r = (a.words[i] | 0) + carry;
      carry = r >> 26;
      this.words[i] = r & 0x3ffffff;
    }

    // Copy rest of the words
    if (carry === 0 && i < a.length && a !== this) {
      for (; i < a.length; i++) {
        this.words[i] = a.words[i];
      }
    }

    this.length = Math.max(this.length, i);

    if (a !== this) {
      this.negative = 1;
    }

    return this.strip();
  };

  // Subtract `num` from `this`
  BN.prototype.sub = function sub (num) {
    return this.clone().isub(num);
  };

  function smallMulTo (self, num, out) {
    out.negative = num.negative ^ self.negative;
    var len = (self.length + num.length) | 0;
    out.length = len;
    len = (len - 1) | 0;

    // Peel one iteration (compiler can't do it, because of code complexity)
    var a = self.words[0] | 0;
    var b = num.words[0] | 0;
    var r = a * b;

    var lo = r & 0x3ffffff;
    var carry = (r / 0x4000000) | 0;
    out.words[0] = lo;

    for (var k = 1; k < len; k++) {
      // Sum all words with the same `i + j = k` and accumulate `ncarry`,
      // note that ncarry could be >= 0x3ffffff
      var ncarry = carry >>> 26;
      var rword = carry & 0x3ffffff;
      var maxJ = Math.min(k, num.length - 1);
      for (var j = Math.max(0, k - self.length + 1); j <= maxJ; j++) {
        var i = (k - j) | 0;
        a = self.words[i] | 0;
        b = num.words[j] | 0;
        r = a * b + rword;
        ncarry += (r / 0x4000000) | 0;
        rword = r & 0x3ffffff;
      }
      out.words[k] = rword | 0;
      carry = ncarry | 0;
    }
    if (carry !== 0) {
      out.words[k] = carry | 0;
    } else {
      out.length--;
    }

    return out.strip();
  }

  // TODO(indutny): it may be reasonable to omit it for users who don't need
  // to work with 256-bit numbers, otherwise it gives 20% improvement for 256-bit
  // multiplication (like elliptic secp256k1).
  var comb10MulTo = function comb10MulTo (self, num, out) {
    var a = self.words;
    var b = num.words;
    var o = out.words;
    var c = 0;
    var lo;
    var mid;
    var hi;
    var a0 = a[0] | 0;
    var al0 = a0 & 0x1fff;
    var ah0 = a0 >>> 13;
    var a1 = a[1] | 0;
    var al1 = a1 & 0x1fff;
    var ah1 = a1 >>> 13;
    var a2 = a[2] | 0;
    var al2 = a2 & 0x1fff;
    var ah2 = a2 >>> 13;
    var a3 = a[3] | 0;
    var al3 = a3 & 0x1fff;
    var ah3 = a3 >>> 13;
    var a4 = a[4] | 0;
    var al4 = a4 & 0x1fff;
    var ah4 = a4 >>> 13;
    var a5 = a[5] | 0;
    var al5 = a5 & 0x1fff;
    var ah5 = a5 >>> 13;
    var a6 = a[6] | 0;
    var al6 = a6 & 0x1fff;
    var ah6 = a6 >>> 13;
    var a7 = a[7] | 0;
    var al7 = a7 & 0x1fff;
    var ah7 = a7 >>> 13;
    var a8 = a[8] | 0;
    var al8 = a8 & 0x1fff;
    var ah8 = a8 >>> 13;
    var a9 = a[9] | 0;
    var al9 = a9 & 0x1fff;
    var ah9 = a9 >>> 13;
    var b0 = b[0] | 0;
    var bl0 = b0 & 0x1fff;
    var bh0 = b0 >>> 13;
    var b1 = b[1] | 0;
    var bl1 = b1 & 0x1fff;
    var bh1 = b1 >>> 13;
    var b2 = b[2] | 0;
    var bl2 = b2 & 0x1fff;
    var bh2 = b2 >>> 13;
    var b3 = b[3] | 0;
    var bl3 = b3 & 0x1fff;
    var bh3 = b3 >>> 13;
    var b4 = b[4] | 0;
    var bl4 = b4 & 0x1fff;
    var bh4 = b4 >>> 13;
    var b5 = b[5] | 0;
    var bl5 = b5 & 0x1fff;
    var bh5 = b5 >>> 13;
    var b6 = b[6] | 0;
    var bl6 = b6 & 0x1fff;
    var bh6 = b6 >>> 13;
    var b7 = b[7] | 0;
    var bl7 = b7 & 0x1fff;
    var bh7 = b7 >>> 13;
    var b8 = b[8] | 0;
    var bl8 = b8 & 0x1fff;
    var bh8 = b8 >>> 13;
    var b9 = b[9] | 0;
    var bl9 = b9 & 0x1fff;
    var bh9 = b9 >>> 13;

    out.negative = self.negative ^ num.negative;
    out.length = 19;
    /* k = 0 */
    lo = Math.imul(al0, bl0);
    mid = Math.imul(al0, bh0);
    mid = (mid + Math.imul(ah0, bl0)) | 0;
    hi = Math.imul(ah0, bh0);
    var w0 = (((c + lo) | 0) + ((mid & 0x1fff) << 13)) | 0;
    c = (((hi + (mid >>> 13)) | 0) + (w0 >>> 26)) | 0;
    w0 &= 0x3ffffff;
    /* k = 1 */
    lo = Math.imul(al1, bl0);
    mid = Math.imul(al1, bh0);
    mid = (mid + Math.imul(ah1, bl0)) | 0;
    hi = Math.imul(ah1, bh0);
    lo = (lo + Math.imul(al0, bl1)) | 0;
    mid = (mid + Math.imul(al0, bh1)) | 0;
    mid = (mid + Math.imul(ah0, bl1)) | 0;
    hi = (hi + Math.imul(ah0, bh1)) | 0;
    var w1 = (((c + lo) | 0) + ((mid & 0x1fff) << 13)) | 0;
    c = (((hi + (mid >>> 13)) | 0) + (w1 >>> 26)) | 0;
    w1 &= 0x3ffffff;
    /* k = 2 */
    lo = Math.imul(al2, bl0);
    mid = Math.imul(al2, bh0);
    mid = (mid + Math.imul(ah2, bl0)) | 0;
    hi = Math.imul(ah2, bh0);
    lo = (lo + Math.imul(al1, bl1)) | 0;
    mid = (mid + Math.imul(al1, bh1)) | 0;
    mid = (mid + Math.imul(ah1, bl1)) | 0;
    hi = (hi + Math.imul(ah1, bh1)) | 0;
    lo = (lo + Math.imul(al0, bl2)) | 0;
    mid = (mid + Math.imul(al0, bh2)) | 0;
    mid = (mid + Math.imul(ah0, bl2)) | 0;
    hi = (hi + Math.imul(ah0, bh2)) | 0;
    var w2 = (((c + lo) | 0) + ((mid & 0x1fff) << 13)) | 0;
    c = (((hi + (mid >>> 13)) | 0) + (w2 >>> 26)) | 0;
    w2 &= 0x3ffffff;
    /* k = 3 */
    lo = Math.imul(al3, bl0);
    mid = Math.imul(al3, bh0);
    mid = (mid + Math.imul(ah3, bl0)) | 0;
    hi = Math.imul(ah3, bh0);
    lo = (lo + Math.imul(al2, bl1)) | 0;
    mid = (mid + Math.imul(al2, bh1)) | 0;
    mid = (mid + Math.imul(ah2, bl1)) | 0;
    hi = (hi + Math.imul(ah2, bh1)) | 0;
    lo = (lo + Math.imul(al1, bl2)) | 0;
    mid = (mid + Math.imul(al1, bh2)) | 0;
    mid = (mid + Math.imul(ah1, bl2)) | 0;
    hi = (hi + Math.imul(ah1, bh2)) | 0;
    lo = (lo + Math.imul(al0, bl3)) | 0;
    mid = (mid + Math.imul(al0, bh3)) | 0;
    mid = (mid + Math.imul(ah0, bl3)) | 0;
    hi = (hi + Math.imul(ah0, bh3)) | 0;
    var w3 = (((c + lo) | 0) + ((mid & 0x1fff) << 13)) | 0;
    c = (((hi + (mid >>> 13)) | 0) + (w3 >>> 26)) | 0;
    w3 &= 0x3ffffff;
    /* k = 4 */
    lo = Math.imul(al4, bl0);
    mid = Math.imul(al4, bh0);
    mid = (mid + Math.imul(ah4, bl0)) | 0;
    hi = Math.imul(ah4, bh0);
    lo = (lo + Math.imul(al3, bl1)) | 0;
    mid = (mid + Math.imul(al3, bh1)) | 0;
    mid = (mid + Math.imul(ah3, bl1)) | 0;
    hi = (hi + Math.imul(ah3, bh1)) | 0;
    lo = (lo + Math.imul(al2, bl2)) | 0;
    mid = (mid + Math.imul(al2, bh2)) | 0;
    mid = (mid + Math.imul(ah2, bl2)) | 0;
    hi = (hi + Math.imul(ah2, bh2)) | 0;
    lo = (lo + Math.imul(al1, bl3)) | 0;
    mid = (mid + Math.imul(al1, bh3)) | 0;
    mid = (mid + Math.imul(ah1, bl3)) | 0;
    hi = (hi + Math.imul(ah1, bh3)) | 0;
    lo = (lo + Math.imul(al0, bl4)) | 0;
    mid = (mid + Math.imul(al0, bh4)) | 0;
    mid = (mid + Math.imul(ah0, bl4)) | 0;
    hi = (hi + Math.imul(ah0, bh4)) | 0;
    var w4 = (((c + lo) | 0) + ((mid & 0x1fff) << 13)) | 0;
    c = (((hi + (mid >>> 13)) | 0) + (w4 >>> 26)) | 0;
    w4 &= 0x3ffffff;
    /* k = 5 */
    lo = Math.imul(al5, bl0);
    mid = Math.imul(al5, bh0);
    mid = (mid + Math.imul(ah5, bl0)) | 0;
    hi = Math.imul(ah5, bh0);
    lo = (lo + Math.imul(al4, bl1)) | 0;
    mid = (mid + Math.imul(al4, bh1)) | 0;
    mid = (mid + Math.imul(ah4, bl1)) | 0;
    hi = (hi + Math.imul(ah4, bh1)) | 0;
    lo = (lo + Math.imul(al3, bl2)) | 0;
    mid = (mid + Math.imul(al3, bh2)) | 0;
    mid = (mid + Math.imul(ah3, bl2)) | 0;
    hi = (hi + Math.imul(ah3, bh2)) | 0;
    lo = (lo + Math.imul(al2, bl3)) | 0;
    mid = (mid + Math.imul(al2, bh3)) | 0;
    mid = (mid + Math.imul(ah2, bl3)) | 0;
    hi = (hi + Math.imul(ah2, bh3)) | 0;
    lo = (lo + Math.imul(al1, bl4)) | 0;
    mid = (mid + Math.imul(al1, bh4)) | 0;
    mid = (mid + Math.imul(ah1, bl4)) | 0;
    hi = (hi + Math.imul(ah1, bh4)) | 0;
    lo = (lo + Math.imul(al0, bl5)) | 0;
    mid = (mid + Math.imul(al0, bh5)) | 0;
    mid = (mid + Math.imul(ah0, bl5)) | 0;
    hi = (hi + Math.imul(ah0, bh5)) | 0;
    var w5 = (((c + lo) | 0) + ((mid & 0x1fff) << 13)) | 0;
    c = (((hi + (mid >>> 13)) | 0) + (w5 >>> 26)) | 0;
    w5 &= 0x3ffffff;
    /* k = 6 */
    lo = Math.imul(al6, bl0);
    mid = Math.imul(al6, bh0);
    mid = (mid + Math.imul(ah6, bl0)) | 0;
    hi = Math.imul(ah6, bh0);
    lo = (lo + Math.imul(al5, bl1)) | 0;
    mid = (mid + Math.imul(al5, bh1)) | 0;
    mid = (mid + Math.imul(ah5, bl1)) | 0;
    hi = (hi + Math.imul(ah5, bh1)) | 0;
    lo = (lo + Math.imul(al4, bl2)) | 0;
    mid = (mid + Math.imul(al4, bh2)) | 0;
    mid = (mid + Math.imul(ah4, bl2)) | 0;
    hi = (hi + Math.imul(ah4, bh2)) | 0;
    lo = (lo + Math.imul(al3, bl3)) | 0;
    mid = (mid + Math.imul(al3, bh3)) | 0;
    mid = (mid + Math.imul(ah3, bl3)) | 0;
    hi = (hi + Math.imul(ah3, bh3)) | 0;
    lo = (lo + Math.imul(al2, bl4)) | 0;
    mid = (mid + Math.imul(al2, bh4)) | 0;
    mid = (mid + Math.imul(ah2, bl4)) | 0;
    hi = (hi + Math.imul(ah2, bh4)) | 0;
    lo = (lo + Math.imul(al1, bl5)) | 0;
    mid = (mid + Math.imul(al1, bh5)) | 0;
    mid = (mid + Math.imul(ah1, bl5)) | 0;
    hi = (hi + Math.imul(ah1, bh5)) | 0;
    lo = (lo + Math.imul(al0, bl6)) | 0;
    mid = (mid + Math.imul(al0, bh6)) | 0;
    mid = (mid + Math.imul(ah0, bl6)) | 0;
    hi = (hi + Math.imul(ah0, bh6)) | 0;
    var w6 = (((c + lo) | 0) + ((mid & 0x1fff) << 13)) | 0;
    c = (((hi + (mid >>> 13)) | 0) + (w6 >>> 26)) | 0;
    w6 &= 0x3ffffff;
    /* k = 7 */
    lo = Math.imul(al7, bl0);
    mid = Math.imul(al7, bh0);
    mid = (mid + Math.imul(ah7, bl0)) | 0;
    hi = Math.imul(ah7, bh0);
    lo = (lo + Math.imul(al6, bl1)) | 0;
    mid = (mid + Math.imul(al6, bh1)) | 0;
    mid = (mid + Math.imul(ah6, bl1)) | 0;
    hi = (hi + Math.imul(ah6, bh1)) | 0;
    lo = (lo + Math.imul(al5, bl2)) | 0;
    mid = (mid + Math.imul(al5, bh2)) | 0;
    mid = (mid + Math.imul(ah5, bl2)) | 0;
    hi = (hi + Math.imul(ah5, bh2)) | 0;
    lo = (lo + Math.imul(al4, bl3)) | 0;
    mid = (mid + Math.imul(al4, bh3)) | 0;
    mid = (mid + Math.imul(ah4, bl3)) | 0;
    hi = (hi + Math.imul(ah4, bh3)) | 0;
    lo = (lo + Math.imul(al3, bl4)) | 0;
    mid = (mid + Math.imul(al3, bh4)) | 0;
    mid = (mid + Math.imul(ah3, bl4)) | 0;
    hi = (hi + Math.imul(ah3, bh4)) | 0;
    lo = (lo + Math.imul(al2, bl5)) | 0;
    mid = (mid + Math.imul(al2, bh5)) | 0;
    mid = (mid + Math.imul(ah2, bl5)) | 0;
    hi = (hi + Math.imul(ah2, bh5)) | 0;
    lo = (lo + Math.imul(al1, bl6)) | 0;
    mid = (mid + Math.imul(al1, bh6)) | 0;
    mid = (mid + Math.imul(ah1, bl6)) | 0;
    hi = (hi + Math.imul(ah1, bh6)) | 0;
    lo = (lo + Math.imul(al0, bl7)) | 0;
    mid = (mid + Math.imul(al0, bh7)) | 0;
    mid = (mid + Math.imul(ah0, bl7)) | 0;
    hi = (hi + Math.imul(ah0, bh7)) | 0;
    var w7 = (((c + lo) | 0) + ((mid & 0x1fff) << 13)) | 0;
    c = (((hi + (mid >>> 13)) | 0) + (w7 >>> 26)) | 0;
    w7 &= 0x3ffffff;
    /* k = 8 */
    lo = Math.imul(al8, bl0);
    mid = Math.imul(al8, bh0);
    mid = (mid + Math.imul(ah8, bl0)) | 0;
    hi = Math.imul(ah8, bh0);
    lo = (lo + Math.imul(al7, bl1)) | 0;
    mid = (mid + Math.imul(al7, bh1)) | 0;
    mid = (mid + Math.imul(ah7, bl1)) | 0;
    hi = (hi + Math.imul(ah7, bh1)) | 0;
    lo = (lo + Math.imul(al6, bl2)) | 0;
    mid = (mid + Math.imul(al6, bh2)) | 0;
    mid = (mid + Math.imul(ah6, bl2)) | 0;
    hi = (hi + Math.imul(ah6, bh2)) | 0;
    lo = (lo + Math.imul(al5, bl3)) | 0;
    mid = (mid + Math.imul(al5, bh3)) | 0;
    mid = (mid + Math.imul(ah5, bl3)) | 0;
    hi = (hi + Math.imul(ah5, bh3)) | 0;
    lo = (lo + Math.imul(al4, bl4)) | 0;
    mid = (mid + Math.imul(al4, bh4)) | 0;
    mid = (mid + Math.imul(ah4, bl4)) | 0;
    hi = (hi + Math.imul(ah4, bh4)) | 0;
    lo = (lo + Math.imul(al3, bl5)) | 0;
    mid = (mid + Math.imul(al3, bh5)) | 0;
    mid = (mid + Math.imul(ah3, bl5)) | 0;
    hi = (hi + Math.imul(ah3, bh5)) | 0;
    lo = (lo + Math.imul(al2, bl6)) | 0;
    mid = (mid + Math.imul(al2, bh6)) | 0;
    mid = (mid + Math.imul(ah2, bl6)) | 0;
    hi = (hi + Math.imul(ah2, bh6)) | 0;
    lo = (lo + Math.imul(al1, bl7)) | 0;
    mid = (mid + Math.imul(al1, bh7)) | 0;
    mid = (mid + Math.imul(ah1, bl7)) | 0;
    hi = (hi + Math.imul(ah1, bh7)) | 0;
    lo = (lo + Math.imul(al0, bl8)) | 0;
    mid = (mid + Math.imul(al0, bh8)) | 0;
    mid = (mid + Math.imul(ah0, bl8)) | 0;
    hi = (hi + Math.imul(ah0, bh8)) | 0;
    var w8 = (((c + lo) | 0) + ((mid & 0x1fff) << 13)) | 0;
    c = (((hi + (mid >>> 13)) | 0) + (w8 >>> 26)) | 0;
    w8 &= 0x3ffffff;
    /* k = 9 */
    lo = Math.imul(al9, bl0);
    mid = Math.imul(al9, bh0);
    mid = (mid + Math.imul(ah9, bl0)) | 0;
    hi = Math.imul(ah9, bh0);
    lo = (lo + Math.imul(al8, bl1)) | 0;
    mid = (mid + Math.imul(al8, bh1)) | 0;
    mid = (mid + Math.imul(ah8, bl1)) | 0;
    hi = (hi + Math.imul(ah8, bh1)) | 0;
    lo = (lo + Math.imul(al7, bl2)) | 0;
    mid = (mid + Math.imul(al7, bh2)) | 0;
    mid = (mid + Math.imul(ah7, bl2)) | 0;
    hi = (hi + Math.imul(ah7, bh2)) | 0;
    lo = (lo + Math.imul(al6, bl3)) | 0;
    mid = (mid + Math.imul(al6, bh3)) | 0;
    mid = (mid + Math.imul(ah6, bl3)) | 0;
    hi = (hi + Math.imul(ah6, bh3)) | 0;
    lo = (lo + Math.imul(al5, bl4)) | 0;
    mid = (mid + Math.imul(al5, bh4)) | 0;
    mid = (mid + Math.imul(ah5, bl4)) | 0;
    hi = (hi + Math.imul(ah5, bh4)) | 0;
    lo = (lo + Math.imul(al4, bl5)) | 0;
    mid = (mid + Math.imul(al4, bh5)) | 0;
    mid = (mid + Math.imul(ah4, bl5)) | 0;
    hi = (hi + Math.imul(ah4, bh5)) | 0;
    lo = (lo + Math.imul(al3, bl6)) | 0;
    mid = (mid + Math.imul(al3, bh6)) | 0;
    mid = (mid + Math.imul(ah3, bl6)) | 0;
    hi = (hi + Math.imul(ah3, bh6)) | 0;
    lo = (lo + Math.imul(al2, bl7)) | 0;
    mid = (mid + Math.imul(al2, bh7)) | 0;
    mid = (mid + Math.imul(ah2, bl7)) | 0;
    hi = (hi + Math.imul(ah2, bh7)) | 0;
    lo = (lo + Math.imul(al1, bl8)) | 0;
    mid = (mid + Math.imul(al1, bh8)) | 0;
    mid = (mid + Math.imul(ah1, bl8)) | 0;
    hi = (hi + Math.imul(ah1, bh8)) | 0;
    lo = (lo + Math.imul(al0, bl9)) | 0;
    mid = (mid + Math.imul(al0, bh9)) | 0;
    mid = (mid + Math.imul(ah0, bl9)) | 0;
    hi = (hi + Math.imul(ah0, bh9)) | 0;
    var w9 = (((c + lo) | 0) + ((mid & 0x1fff) << 13)) | 0;
    c = (((hi + (mid >>> 13)) | 0) + (w9 >>> 26)) | 0;
    w9 &= 0x3ffffff;
    /* k = 10 */
    lo = Math.imul(al9, bl1);
    mid = Math.imul(al9, bh1);
    mid = (mid + Math.imul(ah9, bl1)) | 0;
    hi = Math.imul(ah9, bh1);
    lo = (lo + Math.imul(al8, bl2)) | 0;
    mid = (mid + Math.imul(al8, bh2)) | 0;
    mid = (mid + Math.imul(ah8, bl2)) | 0;
    hi = (hi + Math.imul(ah8, bh2)) | 0;
    lo = (lo + Math.imul(al7, bl3)) | 0;
    mid = (mid + Math.imul(al7, bh3)) | 0;
    mid = (mid + Math.imul(ah7, bl3)) | 0;
    hi = (hi + Math.imul(ah7, bh3)) | 0;
    lo = (lo + Math.imul(al6, bl4)) | 0;
    mid = (mid + Math.imul(al6, bh4)) | 0;
    mid = (mid + Math.imul(ah6, bl4)) | 0;
    hi = (hi + Math.imul(ah6, bh4)) | 0;
    lo = (lo + Math.imul(al5, bl5)) | 0;
    mid = (mid + Math.imul(al5, bh5)) | 0;
    mid = (mid + Math.imul(ah5, bl5)) | 0;
    hi = (hi + Math.imul(ah5, bh5)) | 0;
    lo = (lo + Math.imul(al4, bl6)) | 0;
    mid = (mid + Math.imul(al4, bh6)) | 0;
    mid = (mid + Math.imul(ah4, bl6)) | 0;
    hi = (hi + Math.imul(ah4, bh6)) | 0;
    lo = (lo + Math.imul(al3, bl7)) | 0;
    mid = (mid + Math.imul(al3, bh7)) | 0;
    mid = (mid + Math.imul(ah3, bl7)) | 0;
    hi = (hi + Math.imul(ah3, bh7)) | 0;
    lo = (lo + Math.imul(al2, bl8)) | 0;
    mid = (mid + Math.imul(al2, bh8)) | 0;
    mid = (mid + Math.imul(ah2, bl8)) | 0;
    hi = (hi + Math.imul(ah2, bh8)) | 0;
    lo = (lo + Math.imul(al1, bl9)) | 0;
    mid = (mid + Math.imul(al1, bh9)) | 0;
    mid = (mid + Math.imul(ah1, bl9)) | 0;
    hi = (hi + Math.imul(ah1, bh9)) | 0;
    var w10 = (((c + lo) | 0) + ((mid & 0x1fff) << 13)) | 0;
    c = (((hi + (mid >>> 13)) | 0) + (w10 >>> 26)) | 0;
    w10 &= 0x3ffffff;
    /* k = 11 */
    lo = Math.imul(al9, bl2);
    mid = Math.imul(al9, bh2);
    mid = (mid + Math.imul(ah9, bl2)) | 0;
    hi = Math.imul(ah9, bh2);
    lo = (lo + Math.imul(al8, bl3)) | 0;
    mid = (mid + Math.imul(al8, bh3)) | 0;
    mid = (mid + Math.imul(ah8, bl3)) | 0;
    hi = (hi + Math.imul(ah8, bh3)) | 0;
    lo = (lo + Math.imul(al7, bl4)) | 0;
    mid = (mid + Math.imul(al7, bh4)) | 0;
    mid = (mid + Math.imul(ah7, bl4)) | 0;
    hi = (hi + Math.imul(ah7, bh4)) | 0;
    lo = (lo + Math.imul(al6, bl5)) | 0;
    mid = (mid + Math.imul(al6, bh5)) | 0;
    mid = (mid + Math.imul(ah6, bl5)) | 0;
    hi = (hi + Math.imul(ah6, bh5)) | 0;
    lo = (lo + Math.imul(al5, bl6)) | 0;
    mid = (mid + Math.imul(al5, bh6)) | 0;
    mid = (mid + Math.imul(ah5, bl6)) | 0;
    hi = (hi + Math.imul(ah5, bh6)) | 0;
    lo = (lo + Math.imul(al4, bl7)) | 0;
    mid = (mid + Math.imul(al4, bh7)) | 0;
    mid = (mid + Math.imul(ah4, bl7)) | 0;
    hi = (hi + Math.imul(ah4, bh7)) | 0;
    lo = (lo + Math.imul(al3, bl8)) | 0;
    mid = (mid + Math.imul(al3, bh8)) | 0;
    mid = (mid + Math.imul(ah3, bl8)) | 0;
    hi = (hi + Math.imul(ah3, bh8)) | 0;
    lo = (lo + Math.imul(al2, bl9)) | 0;
    mid = (mid + Math.imul(al2, bh9)) | 0;
    mid = (mid + Math.imul(ah2, bl9)) | 0;
    hi = (hi + Math.imul(ah2, bh9)) | 0;
    var w11 = (((c + lo) | 0) + ((mid & 0x1fff) << 13)) | 0;
    c = (((hi + (mid >>> 13)) | 0) + (w11 >>> 26)) | 0;
    w11 &= 0x3ffffff;
    /* k = 12 */
    lo = Math.imul(al9, bl3);
    mid = Math.imul(al9, bh3);
    mid = (mid + Math.imul(ah9, bl3)) | 0;
    hi = Math.imul(ah9, bh3);
    lo = (lo + Math.imul(al8, bl4)) | 0;
    mid = (mid + Math.imul(al8, bh4)) | 0;
    mid = (mid + Math.imul(ah8, bl4)) | 0;
    hi = (hi + Math.imul(ah8, bh4)) | 0;
    lo = (lo + Math.imul(al7, bl5)) | 0;
    mid = (mid + Math.imul(al7, bh5)) | 0;
    mid = (mid + Math.imul(ah7, bl5)) | 0;
    hi = (hi + Math.imul(ah7, bh5)) | 0;
    lo = (lo + Math.imul(al6, bl6)) | 0;
    mid = (mid + Math.imul(al6, bh6)) | 0;
    mid = (mid + Math.imul(ah6, bl6)) | 0;
    hi = (hi + Math.imul(ah6, bh6)) | 0;
    lo = (lo + Math.imul(al5, bl7)) | 0;
    mid = (mid + Math.imul(al5, bh7)) | 0;
    mid = (mid + Math.imul(ah5, bl7)) | 0;
    hi = (hi + Math.imul(ah5, bh7)) | 0;
    lo = (lo + Math.imul(al4, bl8)) | 0;
    mid = (mid + Math.imul(al4, bh8)) | 0;
    mid = (mid + Math.imul(ah4, bl8)) | 0;
    hi = (hi + Math.imul(ah4, bh8)) | 0;
    lo = (lo + Math.imul(al3, bl9)) | 0;
    mid = (mid + Math.imul(al3, bh9)) | 0;
    mid = (mid + Math.imul(ah3, bl9)) | 0;
    hi = (hi + Math.imul(ah3, bh9)) | 0;
    var w12 = (((c + lo) | 0) + ((mid & 0x1fff) << 13)) | 0;
    c = (((hi + (mid >>> 13)) | 0) + (w12 >>> 26)) | 0;
    w12 &= 0x3ffffff;
    /* k = 13 */
    lo = Math.imul(al9, bl4);
    mid = Math.imul(al9, bh4);
    mid = (mid + Math.imul(ah9, bl4)) | 0;
    hi = Math.imul(ah9, bh4);
    lo = (lo + Math.imul(al8, bl5)) | 0;
    mid = (mid + Math.imul(al8, bh5)) | 0;
    mid = (mid + Math.imul(ah8, bl5)) | 0;
    hi = (hi + Math.imul(ah8, bh5)) | 0;
    lo = (lo + Math.imul(al7, bl6)) | 0;
    mid = (mid + Math.imul(al7, bh6)) | 0;
    mid = (mid + Math.imul(ah7, bl6)) | 0;
    hi = (hi + Math.imul(ah7, bh6)) | 0;
    lo = (lo + Math.imul(al6, bl7)) | 0;
    mid = (mid + Math.imul(al6, bh7)) | 0;
    mid = (mid + Math.imul(ah6, bl7)) | 0;
    hi = (hi + Math.imul(ah6, bh7)) | 0;
    lo = (lo + Math.imul(al5, bl8)) | 0;
    mid = (mid + Math.imul(al5, bh8)) | 0;
    mid = (mid + Math.imul(ah5, bl8)) | 0;
    hi = (hi + Math.imul(ah5, bh8)) | 0;
    lo = (lo + Math.imul(al4, bl9)) | 0;
    mid = (mid + Math.imul(al4, bh9)) | 0;
    mid = (mid + Math.imul(ah4, bl9)) | 0;
    hi = (hi + Math.imul(ah4, bh9)) | 0;
    var w13 = (((c + lo) | 0) + ((mid & 0x1fff) << 13)) | 0;
    c = (((hi + (mid >>> 13)) | 0) + (w13 >>> 26)) | 0;
    w13 &= 0x3ffffff;
    /* k = 14 */
    lo = Math.imul(al9, bl5);
    mid = Math.imul(al9, bh5);
    mid = (mid + Math.imul(ah9, bl5)) | 0;
    hi = Math.imul(ah9, bh5);
    lo = (lo + Math.imul(al8, bl6)) | 0;
    mid = (mid + Math.imul(al8, bh6)) | 0;
    mid = (mid + Math.imul(ah8, bl6)) | 0;
    hi = (hi + Math.imul(ah8, bh6)) | 0;
    lo = (lo + Math.imul(al7, bl7)) | 0;
    mid = (mid + Math.imul(al7, bh7)) | 0;
    mid = (mid + Math.imul(ah7, bl7)) | 0;
    hi = (hi + Math.imul(ah7, bh7)) | 0;
    lo = (lo + Math.imul(al6, bl8)) | 0;
    mid = (mid + Math.imul(al6, bh8)) | 0;
    mid = (mid + Math.imul(ah6, bl8)) | 0;
    hi = (hi + Math.imul(ah6, bh8)) | 0;
    lo = (lo + Math.imul(al5, bl9)) | 0;
    mid = (mid + Math.imul(al5, bh9)) | 0;
    mid = (mid + Math.imul(ah5, bl9)) | 0;
    hi = (hi + Math.imul(ah5, bh9)) | 0;
    var w14 = (((c + lo) | 0) + ((mid & 0x1fff) << 13)) | 0;
    c = (((hi + (mid >>> 13)) | 0) + (w14 >>> 26)) | 0;
    w14 &= 0x3ffffff;
    /* k = 15 */
    lo = Math.imul(al9, bl6);
    mid = Math.imul(al9, bh6);
    mid = (mid + Math.imul(ah9, bl6)) | 0;
    hi = Math.imul(ah9, bh6);
    lo = (lo + Math.imul(al8, bl7)) | 0;
    mid = (mid + Math.imul(al8, bh7)) | 0;
    mid = (mid + Math.imul(ah8, bl7)) | 0;
    hi = (hi + Math.imul(ah8, bh7)) | 0;
    lo = (lo + Math.imul(al7, bl8)) | 0;
    mid = (mid + Math.imul(al7, bh8)) | 0;
    mid = (mid + Math.imul(ah7, bl8)) | 0;
    hi = (hi + Math.imul(ah7, bh8)) | 0;
    lo = (lo + Math.imul(al6, bl9)) | 0;
    mid = (mid + Math.imul(al6, bh9)) | 0;
    mid = (mid + Math.imul(ah6, bl9)) | 0;
    hi = (hi + Math.imul(ah6, bh9)) | 0;
    var w15 = (((c + lo) | 0) + ((mid & 0x1fff) << 13)) | 0;
    c = (((hi + (mid >>> 13)) | 0) + (w15 >>> 26)) | 0;
    w15 &= 0x3ffffff;
    /* k = 16 */
    lo = Math.imul(al9, bl7);
    mid = Math.imul(al9, bh7);
    mid = (mid + Math.imul(ah9, bl7)) | 0;
    hi = Math.imul(ah9, bh7);
    lo = (lo + Math.imul(al8, bl8)) | 0;
    mid = (mid + Math.imul(al8, bh8)) | 0;
    mid = (mid + Math.imul(ah8, bl8)) | 0;
    hi = (hi + Math.imul(ah8, bh8)) | 0;
    lo = (lo + Math.imul(al7, bl9)) | 0;
    mid = (mid + Math.imul(al7, bh9)) | 0;
    mid = (mid + Math.imul(ah7, bl9)) | 0;
    hi = (hi + Math.imul(ah7, bh9)) | 0;
    var w16 = (((c + lo) | 0) + ((mid & 0x1fff) << 13)) | 0;
    c = (((hi + (mid >>> 13)) | 0) + (w16 >>> 26)) | 0;
    w16 &= 0x3ffffff;
    /* k = 17 */
    lo = Math.imul(al9, bl8);
    mid = Math.imul(al9, bh8);
    mid = (mid + Math.imul(ah9, bl8)) | 0;
    hi = Math.imul(ah9, bh8);
    lo = (lo + Math.imul(al8, bl9)) | 0;
    mid = (mid + Math.imul(al8, bh9)) | 0;
    mid = (mid + Math.imul(ah8, bl9)) | 0;
    hi = (hi + Math.imul(ah8, bh9)) | 0;
    var w17 = (((c + lo) | 0) + ((mid & 0x1fff) << 13)) | 0;
    c = (((hi + (mid >>> 13)) | 0) + (w17 >>> 26)) | 0;
    w17 &= 0x3ffffff;
    /* k = 18 */
    lo = Math.imul(al9, bl9);
    mid = Math.imul(al9, bh9);
    mid = (mid + Math.imul(ah9, bl9)) | 0;
    hi = Math.imul(ah9, bh9);
    var w18 = (((c + lo) | 0) + ((mid & 0x1fff) << 13)) | 0;
    c = (((hi + (mid >>> 13)) | 0) + (w18 >>> 26)) | 0;
    w18 &= 0x3ffffff;
    o[0] = w0;
    o[1] = w1;
    o[2] = w2;
    o[3] = w3;
    o[4] = w4;
    o[5] = w5;
    o[6] = w6;
    o[7] = w7;
    o[8] = w8;
    o[9] = w9;
    o[10] = w10;
    o[11] = w11;
    o[12] = w12;
    o[13] = w13;
    o[14] = w14;
    o[15] = w15;
    o[16] = w16;
    o[17] = w17;
    o[18] = w18;
    if (c !== 0) {
      o[19] = c;
      out.length++;
    }
    return out;
  };

  // Polyfill comb
  if (!Math.imul) {
    comb10MulTo = smallMulTo;
  }

  function bigMulTo (self, num, out) {
    out.negative = num.negative ^ self.negative;
    out.length = self.length + num.length;

    var carry = 0;
    var hncarry = 0;
    for (var k = 0; k < out.length - 1; k++) {
      // Sum all words with the same `i + j = k` and accumulate `ncarry`,
      // note that ncarry could be >= 0x3ffffff
      var ncarry = hncarry;
      hncarry = 0;
      var rword = carry & 0x3ffffff;
      var maxJ = Math.min(k, num.length - 1);
      for (var j = Math.max(0, k - self.length + 1); j <= maxJ; j++) {
        var i = k - j;
        var a = self.words[i] | 0;
        var b = num.words[j] | 0;
        var r = a * b;

        var lo = r & 0x3ffffff;
        ncarry = (ncarry + ((r / 0x4000000) | 0)) | 0;
        lo = (lo + rword) | 0;
        rword = lo & 0x3ffffff;
        ncarry = (ncarry + (lo >>> 26)) | 0;

        hncarry += ncarry >>> 26;
        ncarry &= 0x3ffffff;
      }
      out.words[k] = rword;
      carry = ncarry;
      ncarry = hncarry;
    }
    if (carry !== 0) {
      out.words[k] = carry;
    } else {
      out.length--;
    }

    return out.strip();
  }

  function jumboMulTo (self, num, out) {
    var fftm = new FFTM();
    return fftm.mulp(self, num, out);
  }

  BN.prototype.mulTo = function mulTo (num, out) {
    var res;
    var len = this.length + num.length;
    if (this.length === 10 && num.length === 10) {
      res = comb10MulTo(this, num, out);
    } else if (len < 63) {
      res = smallMulTo(this, num, out);
    } else if (len < 1024) {
      res = bigMulTo(this, num, out);
    } else {
      res = jumboMulTo(this, num, out);
    }

    return res;
  };

  // Cooley-Tukey algorithm for FFT
  // slightly revisited to rely on looping instead of recursion

  function FFTM (x, y) {
    this.x = x;
    this.y = y;
  }

  FFTM.prototype.makeRBT = function makeRBT (N) {
    var t = new Array(N);
    var l = BN.prototype._countBits(N) - 1;
    for (var i = 0; i < N; i++) {
      t[i] = this.revBin(i, l, N);
    }

    return t;
  };

  // Returns binary-reversed representation of `x`
  FFTM.prototype.revBin = function revBin (x, l, N) {
    if (x === 0 || x === N - 1) return x;

    var rb = 0;
    for (var i = 0; i < l; i++) {
      rb |= (x & 1) << (l - i - 1);
      x >>= 1;
    }

    return rb;
  };

  // Performs "tweedling" phase, therefore 'emulating'
  // behaviour of the recursive algorithm
  FFTM.prototype.permute = function permute (rbt, rws, iws, rtws, itws, N) {
    for (var i = 0; i < N; i++) {
      rtws[i] = rws[rbt[i]];
      itws[i] = iws[rbt[i]];
    }
  };

  FFTM.prototype.transform = function transform (rws, iws, rtws, itws, N, rbt) {
    this.permute(rbt, rws, iws, rtws, itws, N);

    for (var s = 1; s < N; s <<= 1) {
      var l = s << 1;

      var rtwdf = Math.cos(2 * Math.PI / l);
      var itwdf = Math.sin(2 * Math.PI / l);

      for (var p = 0; p < N; p += l) {
        var rtwdf_ = rtwdf;
        var itwdf_ = itwdf;

        for (var j = 0; j < s; j++) {
          var re = rtws[p + j];
          var ie = itws[p + j];

          var ro = rtws[p + j + s];
          var io = itws[p + j + s];

          var rx = rtwdf_ * ro - itwdf_ * io;

          io = rtwdf_ * io + itwdf_ * ro;
          ro = rx;

          rtws[p + j] = re + ro;
          itws[p + j] = ie + io;

          rtws[p + j + s] = re - ro;
          itws[p + j + s] = ie - io;

          /* jshint maxdepth : false */
          if (j !== l) {
            rx = rtwdf * rtwdf_ - itwdf * itwdf_;

            itwdf_ = rtwdf * itwdf_ + itwdf * rtwdf_;
            rtwdf_ = rx;
          }
        }
      }
    }
  };

  FFTM.prototype.guessLen13b = function guessLen13b (n, m) {
    var N = Math.max(m, n) | 1;
    var odd = N & 1;
    var i = 0;
    for (N = N / 2 | 0; N; N = N >>> 1) {
      i++;
    }

    return 1 << i + 1 + odd;
  };

  FFTM.prototype.conjugate = function conjugate (rws, iws, N) {
    if (N <= 1) return;

    for (var i = 0; i < N / 2; i++) {
      var t = rws[i];

      rws[i] = rws[N - i - 1];
      rws[N - i - 1] = t;

      t = iws[i];

      iws[i] = -iws[N - i - 1];
      iws[N - i - 1] = -t;
    }
  };

  FFTM.prototype.normalize13b = function normalize13b (ws, N) {
    var carry = 0;
    for (var i = 0; i < N / 2; i++) {
      var w = Math.round(ws[2 * i + 1] / N) * 0x2000 +
        Math.round(ws[2 * i] / N) +
        carry;

      ws[i] = w & 0x3ffffff;

      if (w < 0x4000000) {
        carry = 0;
      } else {
        carry = w / 0x4000000 | 0;
      }
    }

    return ws;
  };

  FFTM.prototype.convert13b = function convert13b (ws, len, rws, N) {
    var carry = 0;
    for (var i = 0; i < len; i++) {
      carry = carry + (ws[i] | 0);

      rws[2 * i] = carry & 0x1fff; carry = carry >>> 13;
      rws[2 * i + 1] = carry & 0x1fff; carry = carry >>> 13;
    }

    // Pad with zeroes
    for (i = 2 * len; i < N; ++i) {
      rws[i] = 0;
    }

    assert(carry === 0);
    assert((carry & ~0x1fff) === 0);
  };

  FFTM.prototype.stub = function stub (N) {
    var ph = new Array(N);
    for (var i = 0; i < N; i++) {
      ph[i] = 0;
    }

    return ph;
  };

  FFTM.prototype.mulp = function mulp (x, y, out) {
    var N = 2 * this.guessLen13b(x.length, y.length);

    var rbt = this.makeRBT(N);

    var _ = this.stub(N);

    var rws = new Array(N);
    var rwst = new Array(N);
    var iwst = new Array(N);

    var nrws = new Array(N);
    var nrwst = new Array(N);
    var niwst = new Array(N);

    var rmws = out.words;
    rmws.length = N;

    this.convert13b(x.words, x.length, rws, N);
    this.convert13b(y.words, y.length, nrws, N);

    this.transform(rws, _, rwst, iwst, N, rbt);
    this.transform(nrws, _, nrwst, niwst, N, rbt);

    for (var i = 0; i < N; i++) {
      var rx = rwst[i] * nrwst[i] - iwst[i] * niwst[i];
      iwst[i] = rwst[i] * niwst[i] + iwst[i] * nrwst[i];
      rwst[i] = rx;
    }

    this.conjugate(rwst, iwst, N);
    this.transform(rwst, iwst, rmws, _, N, rbt);
    this.conjugate(rmws, _, N);
    this.normalize13b(rmws, N);

    out.negative = x.negative ^ y.negative;
    out.length = x.length + y.length;
    return out.strip();
  };

  // Multiply `this` by `num`
  BN.prototype.mul = function mul (num) {
    var out = new BN(null);
    out.words = new Array(this.length + num.length);
    return this.mulTo(num, out);
  };

  // Multiply employing FFT
  BN.prototype.mulf = function mulf (num) {
    var out = new BN(null);
    out.words = new Array(this.length + num.length);
    return jumboMulTo(this, num, out);
  };

  // In-place Multiplication
  BN.prototype.imul = function imul (num) {
    return this.clone().mulTo(num, this);
  };

  BN.prototype.imuln = function imuln (num) {
    assert(typeof num === 'number');
    assert(num < 0x4000000);

    // Carry
    var carry = 0;
    for (var i = 0; i < this.length; i++) {
      var w = (this.words[i] | 0) * num;
      var lo = (w & 0x3ffffff) + (carry & 0x3ffffff);
      carry >>= 26;
      carry += (w / 0x4000000) | 0;
      // NOTE: lo is 27bit maximum
      carry += lo >>> 26;
      this.words[i] = lo & 0x3ffffff;
    }

    if (carry !== 0) {
      this.words[i] = carry;
      this.length++;
    }

    return this;
  };

  BN.prototype.muln = function muln (num) {
    return this.clone().imuln(num);
  };

  // `this` * `this`
  BN.prototype.sqr = function sqr () {
    return this.mul(this);
  };

  // `this` * `this` in-place
  BN.prototype.isqr = function isqr () {
    return this.imul(this.clone());
  };

  // Math.pow(`this`, `num`)
  BN.prototype.pow = function pow (num) {
    var w = toBitArray(num);
    if (w.length === 0) return new BN(1);

    // Skip leading zeroes
    var res = this;
    for (var i = 0; i < w.length; i++, res = res.sqr()) {
      if (w[i] !== 0) break;
    }

    if (++i < w.length) {
      for (var q = res.sqr(); i < w.length; i++, q = q.sqr()) {
        if (w[i] === 0) continue;

        res = res.mul(q);
      }
    }

    return res;
  };

  // Shift-left in-place
  BN.prototype.iushln = function iushln (bits) {
    assert(typeof bits === 'number' && bits >= 0);
    var r = bits % 26;
    var s = (bits - r) / 26;
    var carryMask = (0x3ffffff >>> (26 - r)) << (26 - r);
    var i;

    if (r !== 0) {
      var carry = 0;

      for (i = 0; i < this.length; i++) {
        var newCarry = this.words[i] & carryMask;
        var c = ((this.words[i] | 0) - newCarry) << r;
        this.words[i] = c | carry;
        carry = newCarry >>> (26 - r);
      }

      if (carry) {
        this.words[i] = carry;
        this.length++;
      }
    }

    if (s !== 0) {
      for (i = this.length - 1; i >= 0; i--) {
        this.words[i + s] = this.words[i];
      }

      for (i = 0; i < s; i++) {
        this.words[i] = 0;
      }

      this.length += s;
    }

    return this.strip();
  };

  BN.prototype.ishln = function ishln (bits) {
    // TODO(indutny): implement me
    assert(this.negative === 0);
    return this.iushln(bits);
  };

  // Shift-right in-place
  // NOTE: `hint` is a lowest bit before trailing zeroes
  // NOTE: if `extended` is present - it will be filled with destroyed bits
  BN.prototype.iushrn = function iushrn (bits, hint, extended) {
    assert(typeof bits === 'number' && bits >= 0);
    var h;
    if (hint) {
      h = (hint - (hint % 26)) / 26;
    } else {
      h = 0;
    }

    var r = bits % 26;
    var s = Math.min((bits - r) / 26, this.length);
    var mask = 0x3ffffff ^ ((0x3ffffff >>> r) << r);
    var maskedWords = extended;

    h -= s;
    h = Math.max(0, h);

    // Extended mode, copy masked part
    if (maskedWords) {
      for (var i = 0; i < s; i++) {
        maskedWords.words[i] = this.words[i];
      }
      maskedWords.length = s;
    }

    if (s === 0) {
      // No-op, we should not move anything at all
    } else if (this.length > s) {
      this.length -= s;
      for (i = 0; i < this.length; i++) {
        this.words[i] = this.words[i + s];
      }
    } else {
      this.words[0] = 0;
      this.length = 1;
    }

    var carry = 0;
    for (i = this.length - 1; i >= 0 && (carry !== 0 || i >= h); i--) {
      var word = this.words[i] | 0;
      this.words[i] = (carry << (26 - r)) | (word >>> r);
      carry = word & mask;
    }

    // Push carried bits as a mask
    if (maskedWords && carry !== 0) {
      maskedWords.words[maskedWords.length++] = carry;
    }

    if (this.length === 0) {
      this.words[0] = 0;
      this.length = 1;
    }

    return this.strip();
  };

  BN.prototype.ishrn = function ishrn (bits, hint, extended) {
    // TODO(indutny): implement me
    assert(this.negative === 0);
    return this.iushrn(bits, hint, extended);
  };

  // Shift-left
  BN.prototype.shln = function shln (bits) {
    return this.clone().ishln(bits);
  };

  BN.prototype.ushln = function ushln (bits) {
    return this.clone().iushln(bits);
  };

  // Shift-right
  BN.prototype.shrn = function shrn (bits) {
    return this.clone().ishrn(bits);
  };

  BN.prototype.ushrn = function ushrn (bits) {
    return this.clone().iushrn(bits);
  };

  // Test if n bit is set
  BN.prototype.testn = function testn (bit) {
    assert(typeof bit === 'number' && bit >= 0);
    var r = bit % 26;
    var s = (bit - r) / 26;
    var q = 1 << r;

    // Fast case: bit is much higher than all existing words
    if (this.length <= s) return false;

    // Check bit and return
    var w = this.words[s];

    return !!(w & q);
  };

  // Return only lowers bits of number (in-place)
  BN.prototype.imaskn = function imaskn (bits) {
    assert(typeof bits === 'number' && bits >= 0);
    var r = bits % 26;
    var s = (bits - r) / 26;

    assert(this.negative === 0, 'imaskn works only with positive numbers');

    if (this.length <= s) {
      return this;
    }

    if (r !== 0) {
      s++;
    }
    this.length = Math.min(s, this.length);

    if (r !== 0) {
      var mask = 0x3ffffff ^ ((0x3ffffff >>> r) << r);
      this.words[this.length - 1] &= mask;
    }

    return this.strip();
  };

  // Return only lowers bits of number
  BN.prototype.maskn = function maskn (bits) {
    return this.clone().imaskn(bits);
  };

  // Add plain number `num` to `this`
  BN.prototype.iaddn = function iaddn (num) {
    assert(typeof num === 'number');
    assert(num < 0x4000000);
    if (num < 0) return this.isubn(-num);

    // Possible sign change
    if (this.negative !== 0) {
      if (this.length === 1 && (this.words[0] | 0) < num) {
        this.words[0] = num - (this.words[0] | 0);
        this.negative = 0;
        return this;
      }

      this.negative = 0;
      this.isubn(num);
      this.negative = 1;
      return this;
    }

    // Add without checks
    return this._iaddn(num);
  };

  BN.prototype._iaddn = function _iaddn (num) {
    this.words[0] += num;

    // Carry
    for (var i = 0; i < this.length && this.words[i] >= 0x4000000; i++) {
      this.words[i] -= 0x4000000;
      if (i === this.length - 1) {
        this.words[i + 1] = 1;
      } else {
        this.words[i + 1]++;
      }
    }
    this.length = Math.max(this.length, i + 1);

    return this;
  };

  // Subtract plain number `num` from `this`
  BN.prototype.isubn = function isubn (num) {
    assert(typeof num === 'number');
    assert(num < 0x4000000);
    if (num < 0) return this.iaddn(-num);

    if (this.negative !== 0) {
      this.negative = 0;
      this.iaddn(num);
      this.negative = 1;
      return this;
    }

    this.words[0] -= num;

    if (this.length === 1 && this.words[0] < 0) {
      this.words[0] = -this.words[0];
      this.negative = 1;
    } else {
      // Carry
      for (var i = 0; i < this.length && this.words[i] < 0; i++) {
        this.words[i] += 0x4000000;
        this.words[i + 1] -= 1;
      }
    }

    return this.strip();
  };

  BN.prototype.addn = function addn (num) {
    return this.clone().iaddn(num);
  };

  BN.prototype.subn = function subn (num) {
    return this.clone().isubn(num);
  };

  BN.prototype.iabs = function iabs () {
    this.negative = 0;

    return this;
  };

  BN.prototype.abs = function abs () {
    return this.clone().iabs();
  };

  BN.prototype._ishlnsubmul = function _ishlnsubmul (num, mul, shift) {
    var len = num.length + shift;
    var i;

    this._expand(len);

    var w;
    var carry = 0;
    for (i = 0; i < num.length; i++) {
      w = (this.words[i + shift] | 0) + carry;
      var right = (num.words[i] | 0) * mul;
      w -= right & 0x3ffffff;
      carry = (w >> 26) - ((right / 0x4000000) | 0);
      this.words[i + shift] = w & 0x3ffffff;
    }
    for (; i < this.length - shift; i++) {
      w = (this.words[i + shift] | 0) + carry;
      carry = w >> 26;
      this.words[i + shift] = w & 0x3ffffff;
    }

    if (carry === 0) return this.strip();

    // Subtraction overflow
    assert(carry === -1);
    carry = 0;
    for (i = 0; i < this.length; i++) {
      w = -(this.words[i] | 0) + carry;
      carry = w >> 26;
      this.words[i] = w & 0x3ffffff;
    }
    this.negative = 1;

    return this.strip();
  };

  BN.prototype._wordDiv = function _wordDiv (num, mode) {
    var shift = this.length - num.length;

    var a = this.clone();
    var b = num;

    // Normalize
    var bhi = b.words[b.length - 1] | 0;
    var bhiBits = this._countBits(bhi);
    shift = 26 - bhiBits;
    if (shift !== 0) {
      b = b.ushln(shift);
      a.iushln(shift);
      bhi = b.words[b.length - 1] | 0;
    }

    // Initialize quotient
    var m = a.length - b.length;
    var q;

    if (mode !== 'mod') {
      q = new BN(null);
      q.length = m + 1;
      q.words = new Array(q.length);
      for (var i = 0; i < q.length; i++) {
        q.words[i] = 0;
      }
    }

    var diff = a.clone()._ishlnsubmul(b, 1, m);
    if (diff.negative === 0) {
      a = diff;
      if (q) {
        q.words[m] = 1;
      }
    }

    for (var j = m - 1; j >= 0; j--) {
      var qj = (a.words[b.length + j] | 0) * 0x4000000 +
        (a.words[b.length + j - 1] | 0);

      // NOTE: (qj / bhi) is (0x3ffffff * 0x4000000 + 0x3ffffff) / 0x2000000 max
      // (0x7ffffff)
      qj = Math.min((qj / bhi) | 0, 0x3ffffff);

      a._ishlnsubmul(b, qj, j);
      while (a.negative !== 0) {
        qj--;
        a.negative = 0;
        a._ishlnsubmul(b, 1, j);
        if (!a.isZero()) {
          a.negative ^= 1;
        }
      }
      if (q) {
        q.words[j] = qj;
      }
    }
    if (q) {
      q.strip();
    }
    a.strip();

    // Denormalize
    if (mode !== 'div' && shift !== 0) {
      a.iushrn(shift);
    }

    return {
      div: q || null,
      mod: a
    };
  };

  // NOTE: 1) `mode` can be set to `mod` to request mod only,
  //       to `div` to request div only, or be absent to
  //       request both div & mod
  //       2) `positive` is true if unsigned mod is requested
  BN.prototype.divmod = function divmod (num, mode, positive) {
    assert(!num.isZero());

    if (this.isZero()) {
      return {
        div: new BN(0),
        mod: new BN(0)
      };
    }

    var div, mod, res;
    if (this.negative !== 0 && num.negative === 0) {
      res = this.neg().divmod(num, mode);

      if (mode !== 'mod') {
        div = res.div.neg();
      }

      if (mode !== 'div') {
        mod = res.mod.neg();
        if (positive && mod.negative !== 0) {
          mod.iadd(num);
        }
      }

      return {
        div: div,
        mod: mod
      };
    }

    if (this.negative === 0 && num.negative !== 0) {
      res = this.divmod(num.neg(), mode);

      if (mode !== 'mod') {
        div = res.div.neg();
      }

      return {
        div: div,
        mod: res.mod
      };
    }

    if ((this.negative & num.negative) !== 0) {
      res = this.neg().divmod(num.neg(), mode);

      if (mode !== 'div') {
        mod = res.mod.neg();
        if (positive && mod.negative !== 0) {
          mod.isub(num);
        }
      }

      return {
        div: res.div,
        mod: mod
      };
    }

    // Both numbers are positive at this point

    // Strip both numbers to approximate shift value
    if (num.length > this.length || this.cmp(num) < 0) {
      return {
        div: new BN(0),
        mod: this
      };
    }

    // Very short reduction
    if (num.length === 1) {
      if (mode === 'div') {
        return {
          div: this.divn(num.words[0]),
          mod: null
        };
      }

      if (mode === 'mod') {
        return {
          div: null,
          mod: new BN(this.modn(num.words[0]))
        };
      }

      return {
        div: this.divn(num.words[0]),
        mod: new BN(this.modn(num.words[0]))
      };
    }

    return this._wordDiv(num, mode);
  };

  // Find `this` / `num`
  BN.prototype.div = function div (num) {
    return this.divmod(num, 'div', false).div;
  };

  // Find `this` % `num`
  BN.prototype.mod = function mod (num) {
    return this.divmod(num, 'mod', false).mod;
  };

  BN.prototype.umod = function umod (num) {
    return this.divmod(num, 'mod', true).mod;
  };

  // Find Round(`this` / `num`)
  BN.prototype.divRound = function divRound (num) {
    var dm = this.divmod(num);

    // Fast case - exact division
    if (dm.mod.isZero()) return dm.div;

    var mod = dm.div.negative !== 0 ? dm.mod.isub(num) : dm.mod;

    var half = num.ushrn(1);
    var r2 = num.andln(1);
    var cmp = mod.cmp(half);

    // Round down
    if (cmp < 0 || r2 === 1 && cmp === 0) return dm.div;

    // Round up
    return dm.div.negative !== 0 ? dm.div.isubn(1) : dm.div.iaddn(1);
  };

  BN.prototype.modn = function modn (num) {
    assert(num <= 0x3ffffff);
    var p = (1 << 26) % num;

    var acc = 0;
    for (var i = this.length - 1; i >= 0; i--) {
      acc = (p * acc + (this.words[i] | 0)) % num;
    }

    return acc;
  };

  // In-place division by number
  BN.prototype.idivn = function idivn (num) {
    assert(num <= 0x3ffffff);

    var carry = 0;
    for (var i = this.length - 1; i >= 0; i--) {
      var w = (this.words[i] | 0) + carry * 0x4000000;
      this.words[i] = (w / num) | 0;
      carry = w % num;
    }

    return this.strip();
  };

  BN.prototype.divn = function divn (num) {
    return this.clone().idivn(num);
  };

  BN.prototype.egcd = function egcd (p) {
    assert(p.negative === 0);
    assert(!p.isZero());

    var x = this;
    var y = p.clone();

    if (x.negative !== 0) {
      x = x.umod(p);
    } else {
      x = x.clone();
    }

    // A * x + B * y = x
    var A = new BN(1);
    var B = new BN(0);

    // C * x + D * y = y
    var C = new BN(0);
    var D = new BN(1);

    var g = 0;

    while (x.isEven() && y.isEven()) {
      x.iushrn(1);
      y.iushrn(1);
      ++g;
    }

    var yp = y.clone();
    var xp = x.clone();

    while (!x.isZero()) {
      for (var i = 0, im = 1; (x.words[0] & im) === 0 && i < 26; ++i, im <<= 1);
      if (i > 0) {
        x.iushrn(i);
        while (i-- > 0) {
          if (A.isOdd() || B.isOdd()) {
            A.iadd(yp);
            B.isub(xp);
          }

          A.iushrn(1);
          B.iushrn(1);
        }
      }

      for (var j = 0, jm = 1; (y.words[0] & jm) === 0 && j < 26; ++j, jm <<= 1);
      if (j > 0) {
        y.iushrn(j);
        while (j-- > 0) {
          if (C.isOdd() || D.isOdd()) {
            C.iadd(yp);
            D.isub(xp);
          }

          C.iushrn(1);
          D.iushrn(1);
        }
      }

      if (x.cmp(y) >= 0) {
        x.isub(y);
        A.isub(C);
        B.isub(D);
      } else {
        y.isub(x);
        C.isub(A);
        D.isub(B);
      }
    }

    return {
      a: C,
      b: D,
      gcd: y.iushln(g)
    };
  };

  // This is reduced incarnation of the binary EEA
  // above, designated to invert members of the
  // _prime_ fields F(p) at a maximal speed
  BN.prototype._invmp = function _invmp (p) {
    assert(p.negative === 0);
    assert(!p.isZero());

    var a = this;
    var b = p.clone();

    if (a.negative !== 0) {
      a = a.umod(p);
    } else {
      a = a.clone();
    }

    var x1 = new BN(1);
    var x2 = new BN(0);

    var delta = b.clone();

    while (a.cmpn(1) > 0 && b.cmpn(1) > 0) {
      for (var i = 0, im = 1; (a.words[0] & im) === 0 && i < 26; ++i, im <<= 1);
      if (i > 0) {
        a.iushrn(i);
        while (i-- > 0) {
          if (x1.isOdd()) {
            x1.iadd(delta);
          }

          x1.iushrn(1);
        }
      }

      for (var j = 0, jm = 1; (b.words[0] & jm) === 0 && j < 26; ++j, jm <<= 1);
      if (j > 0) {
        b.iushrn(j);
        while (j-- > 0) {
          if (x2.isOdd()) {
            x2.iadd(delta);
          }

          x2.iushrn(1);
        }
      }

      if (a.cmp(b) >= 0) {
        a.isub(b);
        x1.isub(x2);
      } else {
        b.isub(a);
        x2.isub(x1);
      }
    }

    var res;
    if (a.cmpn(1) === 0) {
      res = x1;
    } else {
      res = x2;
    }

    if (res.cmpn(0) < 0) {
      res.iadd(p);
    }

    return res;
  };

  BN.prototype.gcd = function gcd (num) {
    if (this.isZero()) return num.abs();
    if (num.isZero()) return this.abs();

    var a = this.clone();
    var b = num.clone();
    a.negative = 0;
    b.negative = 0;

    // Remove common factor of two
    for (var shift = 0; a.isEven() && b.isEven(); shift++) {
      a.iushrn(1);
      b.iushrn(1);
    }

    do {
      while (a.isEven()) {
        a.iushrn(1);
      }
      while (b.isEven()) {
        b.iushrn(1);
      }

      var r = a.cmp(b);
      if (r < 0) {
        // Swap `a` and `b` to make `a` always bigger than `b`
        var t = a;
        a = b;
        b = t;
      } else if (r === 0 || b.cmpn(1) === 0) {
        break;
      }

      a.isub(b);
    } while (true);

    return b.iushln(shift);
  };

  // Invert number in the field F(num)
  BN.prototype.invm = function invm (num) {
    return this.egcd(num).a.umod(num);
  };

  BN.prototype.isEven = function isEven () {
    return (this.words[0] & 1) === 0;
  };

  BN.prototype.isOdd = function isOdd () {
    return (this.words[0] & 1) === 1;
  };

  // And first word and num
  BN.prototype.andln = function andln (num) {
    return this.words[0] & num;
  };

  // Increment at the bit position in-line
  BN.prototype.bincn = function bincn (bit) {
    assert(typeof bit === 'number');
    var r = bit % 26;
    var s = (bit - r) / 26;
    var q = 1 << r;

    // Fast case: bit is much higher than all existing words
    if (this.length <= s) {
      this._expand(s + 1);
      this.words[s] |= q;
      return this;
    }

    // Add bit and propagate, if needed
    var carry = q;
    for (var i = s; carry !== 0 && i < this.length; i++) {
      var w = this.words[i] | 0;
      w += carry;
      carry = w >>> 26;
      w &= 0x3ffffff;
      this.words[i] = w;
    }
    if (carry !== 0) {
      this.words[i] = carry;
      this.length++;
    }
    return this;
  };

  BN.prototype.isZero = function isZero () {
    return this.length === 1 && this.words[0] === 0;
  };

  BN.prototype.cmpn = function cmpn (num) {
    var negative = num < 0;

    if (this.negative !== 0 && !negative) return -1;
    if (this.negative === 0 && negative) return 1;

    this.strip();

    var res;
    if (this.length > 1) {
      res = 1;
    } else {
      if (negative) {
        num = -num;
      }

      assert(num <= 0x3ffffff, 'Number is too big');

      var w = this.words[0] | 0;
      res = w === num ? 0 : w < num ? -1 : 1;
    }
    if (this.negative !== 0) return -res | 0;
    return res;
  };

  // Compare two numbers and return:
  // 1 - if `this` > `num`
  // 0 - if `this` == `num`
  // -1 - if `this` < `num`
  BN.prototype.cmp = function cmp (num) {
    if (this.negative !== 0 && num.negative === 0) return -1;
    if (this.negative === 0 && num.negative !== 0) return 1;

    var res = this.ucmp(num);
    if (this.negative !== 0) return -res | 0;
    return res;
  };

  // Unsigned comparison
  BN.prototype.ucmp = function ucmp (num) {
    // At this point both numbers have the same sign
    if (this.length > num.length) return 1;
    if (this.length < num.length) return -1;

    var res = 0;
    for (var i = this.length - 1; i >= 0; i--) {
      var a = this.words[i] | 0;
      var b = num.words[i] | 0;

      if (a === b) continue;
      if (a < b) {
        res = -1;
      } else if (a > b) {
        res = 1;
      }
      break;
    }
    return res;
  };

  BN.prototype.gtn = function gtn (num) {
    return this.cmpn(num) === 1;
  };

  BN.prototype.gt = function gt (num) {
    return this.cmp(num) === 1;
  };

  BN.prototype.gten = function gten (num) {
    return this.cmpn(num) >= 0;
  };

  BN.prototype.gte = function gte (num) {
    return this.cmp(num) >= 0;
  };

  BN.prototype.ltn = function ltn (num) {
    return this.cmpn(num) === -1;
  };

  BN.prototype.lt = function lt (num) {
    return this.cmp(num) === -1;
  };

  BN.prototype.lten = function lten (num) {
    return this.cmpn(num) <= 0;
  };

  BN.prototype.lte = function lte (num) {
    return this.cmp(num) <= 0;
  };

  BN.prototype.eqn = function eqn (num) {
    return this.cmpn(num) === 0;
  };

  BN.prototype.eq = function eq (num) {
    return this.cmp(num) === 0;
  };

  //
  // A reduce context, could be using montgomery or something better, depending
  // on the `m` itself.
  //
  BN.red = function red (num) {
    return new Red(num);
  };

  BN.prototype.toRed = function toRed (ctx) {
    assert(!this.red, 'Already a number in reduction context');
    assert(this.negative === 0, 'red works only with positives');
    return ctx.convertTo(this)._forceRed(ctx);
  };

  BN.prototype.fromRed = function fromRed () {
    assert(this.red, 'fromRed works only with numbers in reduction context');
    return this.red.convertFrom(this);
  };

  BN.prototype._forceRed = function _forceRed (ctx) {
    this.red = ctx;
    return this;
  };

  BN.prototype.forceRed = function forceRed (ctx) {
    assert(!this.red, 'Already a number in reduction context');
    return this._forceRed(ctx);
  };

  BN.prototype.redAdd = function redAdd (num) {
    assert(this.red, 'redAdd works only with red numbers');
    return this.red.add(this, num);
  };

  BN.prototype.redIAdd = function redIAdd (num) {
    assert(this.red, 'redIAdd works only with red numbers');
    return this.red.iadd(this, num);
  };

  BN.prototype.redSub = function redSub (num) {
    assert(this.red, 'redSub works only with red numbers');
    return this.red.sub(this, num);
  };

  BN.prototype.redISub = function redISub (num) {
    assert(this.red, 'redISub works only with red numbers');
    return this.red.isub(this, num);
  };

  BN.prototype.redShl = function redShl (num) {
    assert(this.red, 'redShl works only with red numbers');
    return this.red.shl(this, num);
  };

  BN.prototype.redMul = function redMul (num) {
    assert(this.red, 'redMul works only with red numbers');
    this.red._verify2(this, num);
    return this.red.mul(this, num);
  };

  BN.prototype.redIMul = function redIMul (num) {
    assert(this.red, 'redMul works only with red numbers');
    this.red._verify2(this, num);
    return this.red.imul(this, num);
  };

  BN.prototype.redSqr = function redSqr () {
    assert(this.red, 'redSqr works only with red numbers');
    this.red._verify1(this);
    return this.red.sqr(this);
  };

  BN.prototype.redISqr = function redISqr () {
    assert(this.red, 'redISqr works only with red numbers');
    this.red._verify1(this);
    return this.red.isqr(this);
  };

  // Square root over p
  BN.prototype.redSqrt = function redSqrt () {
    assert(this.red, 'redSqrt works only with red numbers');
    this.red._verify1(this);
    return this.red.sqrt(this);
  };

  BN.prototype.redInvm = function redInvm () {
    assert(this.red, 'redInvm works only with red numbers');
    this.red._verify1(this);
    return this.red.invm(this);
  };

  // Return negative clone of `this` % `red modulo`
  BN.prototype.redNeg = function redNeg () {
    assert(this.red, 'redNeg works only with red numbers');
    this.red._verify1(this);
    return this.red.neg(this);
  };

  BN.prototype.redPow = function redPow (num) {
    assert(this.red && !num.red, 'redPow(normalNum)');
    this.red._verify1(this);
    return this.red.pow(this, num);
  };

  // Prime numbers with efficient reduction
  var primes = {
    k256: null,
    p224: null,
    p192: null,
    p25519: null
  };

  // Pseudo-Mersenne prime
  function MPrime (name, p) {
    // P = 2 ^ N - K
    this.name = name;
    this.p = new BN(p, 16);
    this.n = this.p.bitLength();
    this.k = new BN(1).iushln(this.n).isub(this.p);

    this.tmp = this._tmp();
  }

  MPrime.prototype._tmp = function _tmp () {
    var tmp = new BN(null);
    tmp.words = new Array(Math.ceil(this.n / 13));
    return tmp;
  };

  MPrime.prototype.ireduce = function ireduce (num) {
    // Assumes that `num` is less than `P^2`
    // num = HI * (2 ^ N - K) + HI * K + LO = HI * K + LO (mod P)
    var r = num;
    var rlen;

    do {
      this.split(r, this.tmp);
      r = this.imulK(r);
      r = r.iadd(this.tmp);
      rlen = r.bitLength();
    } while (rlen > this.n);

    var cmp = rlen < this.n ? -1 : r.ucmp(this.p);
    if (cmp === 0) {
      r.words[0] = 0;
      r.length = 1;
    } else if (cmp > 0) {
      r.isub(this.p);
    } else {
      if (r.strip !== undefined) {
        // r is BN v4 instance
        r.strip();
      } else {
        // r is BN v5 instance
        r._strip();
      }
    }

    return r;
  };

  MPrime.prototype.split = function split (input, out) {
    input.iushrn(this.n, 0, out);
  };

  MPrime.prototype.imulK = function imulK (num) {
    return num.imul(this.k);
  };

  function K256 () {
    MPrime.call(
      this,
      'k256',
      'ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff fffffffe fffffc2f');
  }
  inherits(K256, MPrime);

  K256.prototype.split = function split (input, output) {
    // 256 = 9 * 26 + 22
    var mask = 0x3fffff;

    var outLen = Math.min(input.length, 9);
    for (var i = 0; i < outLen; i++) {
      output.words[i] = input.words[i];
    }
    output.length = outLen;

    if (input.length <= 9) {
      input.words[0] = 0;
      input.length = 1;
      return;
    }

    // Shift by 9 limbs
    var prev = input.words[9];
    output.words[output.length++] = prev & mask;

    for (i = 10; i < input.length; i++) {
      var next = input.words[i] | 0;
      input.words[i - 10] = ((next & mask) << 4) | (prev >>> 22);
      prev = next;
    }
    prev >>>= 22;
    input.words[i - 10] = prev;
    if (prev === 0 && input.length > 10) {
      input.length -= 10;
    } else {
      input.length -= 9;
    }
  };

  K256.prototype.imulK = function imulK (num) {
    // K = 0x1000003d1 = [ 0x40, 0x3d1 ]
    num.words[num.length] = 0;
    num.words[num.length + 1] = 0;
    num.length += 2;

    // bounded at: 0x40 * 0x3ffffff + 0x3d0 = 0x100000390
    var lo = 0;
    for (var i = 0; i < num.length; i++) {
      var w = num.words[i] | 0;
      lo += w * 0x3d1;
      num.words[i] = lo & 0x3ffffff;
      lo = w * 0x40 + ((lo / 0x4000000) | 0);
    }

    // Fast length reduction
    if (num.words[num.length - 1] === 0) {
      num.length--;
      if (num.words[num.length - 1] === 0) {
        num.length--;
      }
    }
    return num;
  };

  function P224 () {
    MPrime.call(
      this,
      'p224',
      'ffffffff ffffffff ffffffff ffffffff 00000000 00000000 00000001');
  }
  inherits(P224, MPrime);

  function P192 () {
    MPrime.call(
      this,
      'p192',
      'ffffffff ffffffff ffffffff fffffffe ffffffff ffffffff');
  }
  inherits(P192, MPrime);

  function P25519 () {
    // 2 ^ 255 - 19
    MPrime.call(
      this,
      '25519',
      '7fffffffffffffff ffffffffffffffff ffffffffffffffff ffffffffffffffed');
  }
  inherits(P25519, MPrime);

  P25519.prototype.imulK = function imulK (num) {
    // K = 0x13
    var carry = 0;
    for (var i = 0; i < num.length; i++) {
      var hi = (num.words[i] | 0) * 0x13 + carry;
      var lo = hi & 0x3ffffff;
      hi >>>= 26;

      num.words[i] = lo;
      carry = hi;
    }
    if (carry !== 0) {
      num.words[num.length++] = carry;
    }
    return num;
  };

  // Exported mostly for testing purposes, use plain name instead
  BN._prime = function prime (name) {
    // Cached version of prime
    if (primes[name]) return primes[name];

    var prime;
    if (name === 'k256') {
      prime = new K256();
    } else if (name === 'p224') {
      prime = new P224();
    } else if (name === 'p192') {
      prime = new P192();
    } else if (name === 'p25519') {
      prime = new P25519();
    } else {
      throw new Error('Unknown prime ' + name);
    }
    primes[name] = prime;

    return prime;
  };

  //
  // Base reduction engine
  //
  function Red (m) {
    if (typeof m === 'string') {
      var prime = BN._prime(m);
      this.m = prime.p;
      this.prime = prime;
    } else {
      assert(m.gtn(1), 'modulus must be greater than 1');
      this.m = m;
      this.prime = null;
    }
  }

  Red.prototype._verify1 = function _verify1 (a) {
    assert(a.negative === 0, 'red works only with positives');
    assert(a.red, 'red works only with red numbers');
  };

  Red.prototype._verify2 = function _verify2 (a, b) {
    assert((a.negative | b.negative) === 0, 'red works only with positives');
    assert(a.red && a.red === b.red,
      'red works only with red numbers');
  };

  Red.prototype.imod = function imod (a) {
    if (this.prime) return this.prime.ireduce(a)._forceRed(this);
    return a.umod(this.m)._forceRed(this);
  };

  Red.prototype.neg = function neg (a) {
    if (a.isZero()) {
      return a.clone();
    }

    return this.m.sub(a)._forceRed(this);
  };

  Red.prototype.add = function add (a, b) {
    this._verify2(a, b);

    var res = a.add(b);
    if (res.cmp(this.m) >= 0) {
      res.isub(this.m);
    }
    return res._forceRed(this);
  };

  Red.prototype.iadd = function iadd (a, b) {
    this._verify2(a, b);

    var res = a.iadd(b);
    if (res.cmp(this.m) >= 0) {
      res.isub(this.m);
    }
    return res;
  };

  Red.prototype.sub = function sub (a, b) {
    this._verify2(a, b);

    var res = a.sub(b);
    if (res.cmpn(0) < 0) {
      res.iadd(this.m);
    }
    return res._forceRed(this);
  };

  Red.prototype.isub = function isub (a, b) {
    this._verify2(a, b);

    var res = a.isub(b);
    if (res.cmpn(0) < 0) {
      res.iadd(this.m);
    }
    return res;
  };

  Red.prototype.shl = function shl (a, num) {
    this._verify1(a);
    return this.imod(a.ushln(num));
  };

  Red.prototype.imul = function imul (a, b) {
    this._verify2(a, b);
    return this.imod(a.imul(b));
  };

  Red.prototype.mul = function mul (a, b) {
    this._verify2(a, b);
    return this.imod(a.mul(b));
  };

  Red.prototype.isqr = function isqr (a) {
    return this.imul(a, a.clone());
  };

  Red.prototype.sqr = function sqr (a) {
    return this.mul(a, a);
  };

  Red.prototype.sqrt = function sqrt (a) {
    if (a.isZero()) return a.clone();

    var mod3 = this.m.andln(3);
    assert(mod3 % 2 === 1);

    // Fast case
    if (mod3 === 3) {
      var pow = this.m.add(new BN(1)).iushrn(2);
      return this.pow(a, pow);
    }

    // Tonelli-Shanks algorithm (Totally unoptimized and slow)
    //
    // Find Q and S, that Q * 2 ^ S = (P - 1)
    var q = this.m.subn(1);
    var s = 0;
    while (!q.isZero() && q.andln(1) === 0) {
      s++;
      q.iushrn(1);
    }
    assert(!q.isZero());

    var one = new BN(1).toRed(this);
    var nOne = one.redNeg();

    // Find quadratic non-residue
    // NOTE: Max is such because of generalized Riemann hypothesis.
    var lpow = this.m.subn(1).iushrn(1);
    var z = this.m.bitLength();
    z = new BN(2 * z * z).toRed(this);

    while (this.pow(z, lpow).cmp(nOne) !== 0) {
      z.redIAdd(nOne);
    }

    var c = this.pow(z, q);
    var r = this.pow(a, q.addn(1).iushrn(1));
    var t = this.pow(a, q);
    var m = s;
    while (t.cmp(one) !== 0) {
      var tmp = t;
      for (var i = 0; tmp.cmp(one) !== 0; i++) {
        tmp = tmp.redSqr();
      }
      assert(i < m);
      var b = this.pow(c, new BN(1).iushln(m - i - 1));

      r = r.redMul(b);
      c = b.redSqr();
      t = t.redMul(c);
      m = i;
    }

    return r;
  };

  Red.prototype.invm = function invm (a) {
    var inv = a._invmp(this.m);
    if (inv.negative !== 0) {
      inv.negative = 0;
      return this.imod(inv).redNeg();
    } else {
      return this.imod(inv);
    }
  };

  Red.prototype.pow = function pow (a, num) {
    if (num.isZero()) return new BN(1).toRed(this);
    if (num.cmpn(1) === 0) return a.clone();

    var windowSize = 4;
    var wnd = new Array(1 << windowSize);
    wnd[0] = new BN(1).toRed(this);
    wnd[1] = a;
    for (var i = 2; i < wnd.length; i++) {
      wnd[i] = this.mul(wnd[i - 1], a);
    }

    var res = wnd[0];
    var current = 0;
    var currentLen = 0;
    var start = num.bitLength() % 26;
    if (start === 0) {
      start = 26;
    }

    for (i = num.length - 1; i >= 0; i--) {
      var word = num.words[i];
      for (var j = start - 1; j >= 0; j--) {
        var bit = (word >> j) & 1;
        if (res !== wnd[0]) {
          res = this.sqr(res);
        }

        if (bit === 0 && current === 0) {
          currentLen = 0;
          continue;
        }

        current <<= 1;
        current |= bit;
        currentLen++;
        if (currentLen !== windowSize && (i !== 0 || j !== 0)) continue;

        res = this.mul(res, wnd[current]);
        currentLen = 0;
        current = 0;
      }
      start = 26;
    }

    return res;
  };

  Red.prototype.convertTo = function convertTo (num) {
    var r = num.umod(this.m);

    return r === num ? r.clone() : r;
  };

  Red.prototype.convertFrom = function convertFrom (num) {
    var res = num.clone();
    res.red = null;
    return res;
  };

  //
  // Montgomery method engine
  //

  BN.mont = function mont (num) {
    return new Mont(num);
  };

  function Mont (m) {
    Red.call(this, m);

    this.shift = this.m.bitLength();
    if (this.shift % 26 !== 0) {
      this.shift += 26 - (this.shift % 26);
    }

    this.r = new BN(1).iushln(this.shift);
    this.r2 = this.imod(this.r.sqr());
    this.rinv = this.r._invmp(this.m);

    this.minv = this.rinv.mul(this.r).isubn(1).div(this.m);
    this.minv = this.minv.umod(this.r);
    this.minv = this.r.sub(this.minv);
  }
  inherits(Mont, Red);

  Mont.prototype.convertTo = function convertTo (num) {
    return this.imod(num.ushln(this.shift));
  };

  Mont.prototype.convertFrom = function convertFrom (num) {
    var r = this.imod(num.mul(this.rinv));
    r.red = null;
    return r;
  };

  Mont.prototype.imul = function imul (a, b) {
    if (a.isZero() || b.isZero()) {
      a.words[0] = 0;
      a.length = 1;
      return a;
    }

    var t = a.imul(b);
    var c = t.maskn(this.shift).mul(this.minv).imaskn(this.shift).mul(this.m);
    var u = t.isub(c).iushrn(this.shift);
    var res = u;

    if (u.cmp(this.m) >= 0) {
      res = u.isub(this.m);
    } else if (u.cmpn(0) < 0) {
      res = u.iadd(this.m);
    }

    return res._forceRed(this);
  };

  Mont.prototype.mul = function mul (a, b) {
    if (a.isZero() || b.isZero()) return new BN(0)._forceRed(this);

    var t = a.mul(b);
    var c = t.maskn(this.shift).mul(this.minv).imaskn(this.shift).mul(this.m);
    var u = t.isub(c).iushrn(this.shift);
    var res = u;
    if (u.cmp(this.m) >= 0) {
      res = u.isub(this.m);
    } else if (u.cmpn(0) < 0) {
      res = u.iadd(this.m);
    }

    return res._forceRed(this);
  };

  Mont.prototype.invm = function invm (a) {
    // (AR)^-1 * R^2 = (A^-1 * R^-1) * R^2 = A^-1 * R
    var res = this.imod(a._invmp(this.m).mul(this.r2));
    return res._forceRed(this);
  };
})( false || module, this);


/***/ }),

/***/ "./node_modules/buffer/index.js":
/*!**************************************!*\
  !*** ./node_modules/buffer/index.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/*!
 * The buffer module from node.js, for the browser.
 *
 * @author   Feross Aboukhadijeh <https://feross.org>
 * @license  MIT
 */
/* eslint-disable no-proto */



var base64 = __webpack_require__(/*! base64-js */ "./node_modules/base64-js/index.js")
var ieee754 = __webpack_require__(/*! ieee754 */ "./node_modules/ieee754/index.js")

exports.Buffer = Buffer
exports.SlowBuffer = SlowBuffer
exports.INSPECT_MAX_BYTES = 50

var K_MAX_LENGTH = 0x7fffffff
exports.kMaxLength = K_MAX_LENGTH

/**
 * If `Buffer.TYPED_ARRAY_SUPPORT`:
 *   === true    Use Uint8Array implementation (fastest)
 *   === false   Print warning and recommend using `buffer` v4.x which has an Object
 *               implementation (most compatible, even IE6)
 *
 * Browsers that support typed arrays are IE 10+, Firefox 4+, Chrome 7+, Safari 5.1+,
 * Opera 11.6+, iOS 4.2+.
 *
 * We report that the browser does not support typed arrays if the are not subclassable
 * using __proto__. Firefox 4-29 lacks support for adding new properties to `Uint8Array`
 * (See: https://bugzilla.mozilla.org/show_bug.cgi?id=695438). IE 10 lacks support
 * for __proto__ and has a buggy typed array implementation.
 */
Buffer.TYPED_ARRAY_SUPPORT = typedArraySupport()

if (!Buffer.TYPED_ARRAY_SUPPORT && typeof console !== 'undefined' &&
    typeof console.error === 'function') {
  console.error(
    'This browser lacks typed array (Uint8Array) support which is required by ' +
    '`buffer` v5.x. Use `buffer` v4.x if you require old browser support.'
  )
}

function typedArraySupport () {
  // Can typed array instances can be augmented?
  try {
    var arr = new Uint8Array(1)
    arr.__proto__ = { __proto__: Uint8Array.prototype, foo: function () { return 42 } }
    return arr.foo() === 42
  } catch (e) {
    return false
  }
}

Object.defineProperty(Buffer.prototype, 'parent', {
  enumerable: true,
  get: function () {
    if (!Buffer.isBuffer(this)) return undefined
    return this.buffer
  }
})

Object.defineProperty(Buffer.prototype, 'offset', {
  enumerable: true,
  get: function () {
    if (!Buffer.isBuffer(this)) return undefined
    return this.byteOffset
  }
})

function createBuffer (length) {
  if (length > K_MAX_LENGTH) {
    throw new RangeError('The value "' + length + '" is invalid for option "size"')
  }
  // Return an augmented `Uint8Array` instance
  var buf = new Uint8Array(length)
  buf.__proto__ = Buffer.prototype
  return buf
}

/**
 * The Buffer constructor returns instances of `Uint8Array` that have their
 * prototype changed to `Buffer.prototype`. Furthermore, `Buffer` is a subclass of
 * `Uint8Array`, so the returned instances will have all the node `Buffer` methods
 * and the `Uint8Array` methods. Square bracket notation works as expected -- it
 * returns a single octet.
 *
 * The `Uint8Array` prototype remains unmodified.
 */

function Buffer (arg, encodingOrOffset, length) {
  // Common case.
  if (typeof arg === 'number') {
    if (typeof encodingOrOffset === 'string') {
      throw new TypeError(
        'The "string" argument must be of type string. Received type number'
      )
    }
    return allocUnsafe(arg)
  }
  return from(arg, encodingOrOffset, length)
}

// Fix subarray() in ES2016. See: https://github.com/feross/buffer/pull/97
if (typeof Symbol !== 'undefined' && Symbol.species != null &&
    Buffer[Symbol.species] === Buffer) {
  Object.defineProperty(Buffer, Symbol.species, {
    value: null,
    configurable: true,
    enumerable: false,
    writable: false
  })
}

Buffer.poolSize = 8192 // not used by this implementation

function from (value, encodingOrOffset, length) {
  if (typeof value === 'string') {
    return fromString(value, encodingOrOffset)
  }

  if (ArrayBuffer.isView(value)) {
    return fromArrayLike(value)
  }

  if (value == null) {
    throw TypeError(
      'The first argument must be one of type string, Buffer, ArrayBuffer, Array, ' +
      'or Array-like Object. Received type ' + (typeof value)
    )
  }

  if (isInstance(value, ArrayBuffer) ||
      (value && isInstance(value.buffer, ArrayBuffer))) {
    return fromArrayBuffer(value, encodingOrOffset, length)
  }

  if (typeof value === 'number') {
    throw new TypeError(
      'The "value" argument must not be of type number. Received type number'
    )
  }

  var valueOf = value.valueOf && value.valueOf()
  if (valueOf != null && valueOf !== value) {
    return Buffer.from(valueOf, encodingOrOffset, length)
  }

  var b = fromObject(value)
  if (b) return b

  if (typeof Symbol !== 'undefined' && Symbol.toPrimitive != null &&
      typeof value[Symbol.toPrimitive] === 'function') {
    return Buffer.from(
      value[Symbol.toPrimitive]('string'), encodingOrOffset, length
    )
  }

  throw new TypeError(
    'The first argument must be one of type string, Buffer, ArrayBuffer, Array, ' +
    'or Array-like Object. Received type ' + (typeof value)
  )
}

/**
 * Functionally equivalent to Buffer(arg, encoding) but throws a TypeError
 * if value is a number.
 * Buffer.from(str[, encoding])
 * Buffer.from(array)
 * Buffer.from(buffer)
 * Buffer.from(arrayBuffer[, byteOffset[, length]])
 **/
Buffer.from = function (value, encodingOrOffset, length) {
  return from(value, encodingOrOffset, length)
}

// Note: Change prototype *after* Buffer.from is defined to workaround Chrome bug:
// https://github.com/feross/buffer/pull/148
Buffer.prototype.__proto__ = Uint8Array.prototype
Buffer.__proto__ = Uint8Array

function assertSize (size) {
  if (typeof size !== 'number') {
    throw new TypeError('"size" argument must be of type number')
  } else if (size < 0) {
    throw new RangeError('The value "' + size + '" is invalid for option "size"')
  }
}

function alloc (size, fill, encoding) {
  assertSize(size)
  if (size <= 0) {
    return createBuffer(size)
  }
  if (fill !== undefined) {
    // Only pay attention to encoding if it's a string. This
    // prevents accidentally sending in a number that would
    // be interpretted as a start offset.
    return typeof encoding === 'string'
      ? createBuffer(size).fill(fill, encoding)
      : createBuffer(size).fill(fill)
  }
  return createBuffer(size)
}

/**
 * Creates a new filled Buffer instance.
 * alloc(size[, fill[, encoding]])
 **/
Buffer.alloc = function (size, fill, encoding) {
  return alloc(size, fill, encoding)
}

function allocUnsafe (size) {
  assertSize(size)
  return createBuffer(size < 0 ? 0 : checked(size) | 0)
}

/**
 * Equivalent to Buffer(num), by default creates a non-zero-filled Buffer instance.
 * */
Buffer.allocUnsafe = function (size) {
  return allocUnsafe(size)
}
/**
 * Equivalent to SlowBuffer(num), by default creates a non-zero-filled Buffer instance.
 */
Buffer.allocUnsafeSlow = function (size) {
  return allocUnsafe(size)
}

function fromString (string, encoding) {
  if (typeof encoding !== 'string' || encoding === '') {
    encoding = 'utf8'
  }

  if (!Buffer.isEncoding(encoding)) {
    throw new TypeError('Unknown encoding: ' + encoding)
  }

  var length = byteLength(string, encoding) | 0
  var buf = createBuffer(length)

  var actual = buf.write(string, encoding)

  if (actual !== length) {
    // Writing a hex string, for example, that contains invalid characters will
    // cause everything after the first invalid character to be ignored. (e.g.
    // 'abxxcd' will be treated as 'ab')
    buf = buf.slice(0, actual)
  }

  return buf
}

function fromArrayLike (array) {
  var length = array.length < 0 ? 0 : checked(array.length) | 0
  var buf = createBuffer(length)
  for (var i = 0; i < length; i += 1) {
    buf[i] = array[i] & 255
  }
  return buf
}

function fromArrayBuffer (array, byteOffset, length) {
  if (byteOffset < 0 || array.byteLength < byteOffset) {
    throw new RangeError('"offset" is outside of buffer bounds')
  }

  if (array.byteLength < byteOffset + (length || 0)) {
    throw new RangeError('"length" is outside of buffer bounds')
  }

  var buf
  if (byteOffset === undefined && length === undefined) {
    buf = new Uint8Array(array)
  } else if (length === undefined) {
    buf = new Uint8Array(array, byteOffset)
  } else {
    buf = new Uint8Array(array, byteOffset, length)
  }

  // Return an augmented `Uint8Array` instance
  buf.__proto__ = Buffer.prototype
  return buf
}

function fromObject (obj) {
  if (Buffer.isBuffer(obj)) {
    var len = checked(obj.length) | 0
    var buf = createBuffer(len)

    if (buf.length === 0) {
      return buf
    }

    obj.copy(buf, 0, 0, len)
    return buf
  }

  if (obj.length !== undefined) {
    if (typeof obj.length !== 'number' || numberIsNaN(obj.length)) {
      return createBuffer(0)
    }
    return fromArrayLike(obj)
  }

  if (obj.type === 'Buffer' && Array.isArray(obj.data)) {
    return fromArrayLike(obj.data)
  }
}

function checked (length) {
  // Note: cannot use `length < K_MAX_LENGTH` here because that fails when
  // length is NaN (which is otherwise coerced to zero.)
  if (length >= K_MAX_LENGTH) {
    throw new RangeError('Attempt to allocate Buffer larger than maximum ' +
                         'size: 0x' + K_MAX_LENGTH.toString(16) + ' bytes')
  }
  return length | 0
}

function SlowBuffer (length) {
  if (+length != length) { // eslint-disable-line eqeqeq
    length = 0
  }
  return Buffer.alloc(+length)
}

Buffer.isBuffer = function isBuffer (b) {
  return b != null && b._isBuffer === true &&
    b !== Buffer.prototype // so Buffer.isBuffer(Buffer.prototype) will be false
}

Buffer.compare = function compare (a, b) {
  if (isInstance(a, Uint8Array)) a = Buffer.from(a, a.offset, a.byteLength)
  if (isInstance(b, Uint8Array)) b = Buffer.from(b, b.offset, b.byteLength)
  if (!Buffer.isBuffer(a) || !Buffer.isBuffer(b)) {
    throw new TypeError(
      'The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array'
    )
  }

  if (a === b) return 0

  var x = a.length
  var y = b.length

  for (var i = 0, len = Math.min(x, y); i < len; ++i) {
    if (a[i] !== b[i]) {
      x = a[i]
      y = b[i]
      break
    }
  }

  if (x < y) return -1
  if (y < x) return 1
  return 0
}

Buffer.isEncoding = function isEncoding (encoding) {
  switch (String(encoding).toLowerCase()) {
    case 'hex':
    case 'utf8':
    case 'utf-8':
    case 'ascii':
    case 'latin1':
    case 'binary':
    case 'base64':
    case 'ucs2':
    case 'ucs-2':
    case 'utf16le':
    case 'utf-16le':
      return true
    default:
      return false
  }
}

Buffer.concat = function concat (list, length) {
  if (!Array.isArray(list)) {
    throw new TypeError('"list" argument must be an Array of Buffers')
  }

  if (list.length === 0) {
    return Buffer.alloc(0)
  }

  var i
  if (length === undefined) {
    length = 0
    for (i = 0; i < list.length; ++i) {
      length += list[i].length
    }
  }

  var buffer = Buffer.allocUnsafe(length)
  var pos = 0
  for (i = 0; i < list.length; ++i) {
    var buf = list[i]
    if (isInstance(buf, Uint8Array)) {
      buf = Buffer.from(buf)
    }
    if (!Buffer.isBuffer(buf)) {
      throw new TypeError('"list" argument must be an Array of Buffers')
    }
    buf.copy(buffer, pos)
    pos += buf.length
  }
  return buffer
}

function byteLength (string, encoding) {
  if (Buffer.isBuffer(string)) {
    return string.length
  }
  if (ArrayBuffer.isView(string) || isInstance(string, ArrayBuffer)) {
    return string.byteLength
  }
  if (typeof string !== 'string') {
    throw new TypeError(
      'The "string" argument must be one of type string, Buffer, or ArrayBuffer. ' +
      'Received type ' + typeof string
    )
  }

  var len = string.length
  var mustMatch = (arguments.length > 2 && arguments[2] === true)
  if (!mustMatch && len === 0) return 0

  // Use a for loop to avoid recursion
  var loweredCase = false
  for (;;) {
    switch (encoding) {
      case 'ascii':
      case 'latin1':
      case 'binary':
        return len
      case 'utf8':
      case 'utf-8':
        return utf8ToBytes(string).length
      case 'ucs2':
      case 'ucs-2':
      case 'utf16le':
      case 'utf-16le':
        return len * 2
      case 'hex':
        return len >>> 1
      case 'base64':
        return base64ToBytes(string).length
      default:
        if (loweredCase) {
          return mustMatch ? -1 : utf8ToBytes(string).length // assume utf8
        }
        encoding = ('' + encoding).toLowerCase()
        loweredCase = true
    }
  }
}
Buffer.byteLength = byteLength

function slowToString (encoding, start, end) {
  var loweredCase = false

  // No need to verify that "this.length <= MAX_UINT32" since it's a read-only
  // property of a typed array.

  // This behaves neither like String nor Uint8Array in that we set start/end
  // to their upper/lower bounds if the value passed is out of range.
  // undefined is handled specially as per ECMA-262 6th Edition,
  // Section 13.3.3.7 Runtime Semantics: KeyedBindingInitialization.
  if (start === undefined || start < 0) {
    start = 0
  }
  // Return early if start > this.length. Done here to prevent potential uint32
  // coercion fail below.
  if (start > this.length) {
    return ''
  }

  if (end === undefined || end > this.length) {
    end = this.length
  }

  if (end <= 0) {
    return ''
  }

  // Force coersion to uint32. This will also coerce falsey/NaN values to 0.
  end >>>= 0
  start >>>= 0

  if (end <= start) {
    return ''
  }

  if (!encoding) encoding = 'utf8'

  while (true) {
    switch (encoding) {
      case 'hex':
        return hexSlice(this, start, end)

      case 'utf8':
      case 'utf-8':
        return utf8Slice(this, start, end)

      case 'ascii':
        return asciiSlice(this, start, end)

      case 'latin1':
      case 'binary':
        return latin1Slice(this, start, end)

      case 'base64':
        return base64Slice(this, start, end)

      case 'ucs2':
      case 'ucs-2':
      case 'utf16le':
      case 'utf-16le':
        return utf16leSlice(this, start, end)

      default:
        if (loweredCase) throw new TypeError('Unknown encoding: ' + encoding)
        encoding = (encoding + '').toLowerCase()
        loweredCase = true
    }
  }
}

// This property is used by `Buffer.isBuffer` (and the `is-buffer` npm package)
// to detect a Buffer instance. It's not possible to use `instanceof Buffer`
// reliably in a browserify context because there could be multiple different
// copies of the 'buffer' package in use. This method works even for Buffer
// instances that were created from another copy of the `buffer` package.
// See: https://github.com/feross/buffer/issues/154
Buffer.prototype._isBuffer = true

function swap (b, n, m) {
  var i = b[n]
  b[n] = b[m]
  b[m] = i
}

Buffer.prototype.swap16 = function swap16 () {
  var len = this.length
  if (len % 2 !== 0) {
    throw new RangeError('Buffer size must be a multiple of 16-bits')
  }
  for (var i = 0; i < len; i += 2) {
    swap(this, i, i + 1)
  }
  return this
}

Buffer.prototype.swap32 = function swap32 () {
  var len = this.length
  if (len % 4 !== 0) {
    throw new RangeError('Buffer size must be a multiple of 32-bits')
  }
  for (var i = 0; i < len; i += 4) {
    swap(this, i, i + 3)
    swap(this, i + 1, i + 2)
  }
  return this
}

Buffer.prototype.swap64 = function swap64 () {
  var len = this.length
  if (len % 8 !== 0) {
    throw new RangeError('Buffer size must be a multiple of 64-bits')
  }
  for (var i = 0; i < len; i += 8) {
    swap(this, i, i + 7)
    swap(this, i + 1, i + 6)
    swap(this, i + 2, i + 5)
    swap(this, i + 3, i + 4)
  }
  return this
}

Buffer.prototype.toString = function toString () {
  var length = this.length
  if (length === 0) return ''
  if (arguments.length === 0) return utf8Slice(this, 0, length)
  return slowToString.apply(this, arguments)
}

Buffer.prototype.toLocaleString = Buffer.prototype.toString

Buffer.prototype.equals = function equals (b) {
  if (!Buffer.isBuffer(b)) throw new TypeError('Argument must be a Buffer')
  if (this === b) return true
  return Buffer.compare(this, b) === 0
}

Buffer.prototype.inspect = function inspect () {
  var str = ''
  var max = exports.INSPECT_MAX_BYTES
  str = this.toString('hex', 0, max).replace(/(.{2})/g, '$1 ').trim()
  if (this.length > max) str += ' ... '
  return '<Buffer ' + str + '>'
}

Buffer.prototype.compare = function compare (target, start, end, thisStart, thisEnd) {
  if (isInstance(target, Uint8Array)) {
    target = Buffer.from(target, target.offset, target.byteLength)
  }
  if (!Buffer.isBuffer(target)) {
    throw new TypeError(
      'The "target" argument must be one of type Buffer or Uint8Array. ' +
      'Received type ' + (typeof target)
    )
  }

  if (start === undefined) {
    start = 0
  }
  if (end === undefined) {
    end = target ? target.length : 0
  }
  if (thisStart === undefined) {
    thisStart = 0
  }
  if (thisEnd === undefined) {
    thisEnd = this.length
  }

  if (start < 0 || end > target.length || thisStart < 0 || thisEnd > this.length) {
    throw new RangeError('out of range index')
  }

  if (thisStart >= thisEnd && start >= end) {
    return 0
  }
  if (thisStart >= thisEnd) {
    return -1
  }
  if (start >= end) {
    return 1
  }

  start >>>= 0
  end >>>= 0
  thisStart >>>= 0
  thisEnd >>>= 0

  if (this === target) return 0

  var x = thisEnd - thisStart
  var y = end - start
  var len = Math.min(x, y)

  var thisCopy = this.slice(thisStart, thisEnd)
  var targetCopy = target.slice(start, end)

  for (var i = 0; i < len; ++i) {
    if (thisCopy[i] !== targetCopy[i]) {
      x = thisCopy[i]
      y = targetCopy[i]
      break
    }
  }

  if (x < y) return -1
  if (y < x) return 1
  return 0
}

// Finds either the first index of `val` in `buffer` at offset >= `byteOffset`,
// OR the last index of `val` in `buffer` at offset <= `byteOffset`.
//
// Arguments:
// - buffer - a Buffer to search
// - val - a string, Buffer, or number
// - byteOffset - an index into `buffer`; will be clamped to an int32
// - encoding - an optional encoding, relevant is val is a string
// - dir - true for indexOf, false for lastIndexOf
function bidirectionalIndexOf (buffer, val, byteOffset, encoding, dir) {
  // Empty buffer means no match
  if (buffer.length === 0) return -1

  // Normalize byteOffset
  if (typeof byteOffset === 'string') {
    encoding = byteOffset
    byteOffset = 0
  } else if (byteOffset > 0x7fffffff) {
    byteOffset = 0x7fffffff
  } else if (byteOffset < -0x80000000) {
    byteOffset = -0x80000000
  }
  byteOffset = +byteOffset // Coerce to Number.
  if (numberIsNaN(byteOffset)) {
    // byteOffset: it it's undefined, null, NaN, "foo", etc, search whole buffer
    byteOffset = dir ? 0 : (buffer.length - 1)
  }

  // Normalize byteOffset: negative offsets start from the end of the buffer
  if (byteOffset < 0) byteOffset = buffer.length + byteOffset
  if (byteOffset >= buffer.length) {
    if (dir) return -1
    else byteOffset = buffer.length - 1
  } else if (byteOffset < 0) {
    if (dir) byteOffset = 0
    else return -1
  }

  // Normalize val
  if (typeof val === 'string') {
    val = Buffer.from(val, encoding)
  }

  // Finally, search either indexOf (if dir is true) or lastIndexOf
  if (Buffer.isBuffer(val)) {
    // Special case: looking for empty string/buffer always fails
    if (val.length === 0) {
      return -1
    }
    return arrayIndexOf(buffer, val, byteOffset, encoding, dir)
  } else if (typeof val === 'number') {
    val = val & 0xFF // Search for a byte value [0-255]
    if (typeof Uint8Array.prototype.indexOf === 'function') {
      if (dir) {
        return Uint8Array.prototype.indexOf.call(buffer, val, byteOffset)
      } else {
        return Uint8Array.prototype.lastIndexOf.call(buffer, val, byteOffset)
      }
    }
    return arrayIndexOf(buffer, [ val ], byteOffset, encoding, dir)
  }

  throw new TypeError('val must be string, number or Buffer')
}

function arrayIndexOf (arr, val, byteOffset, encoding, dir) {
  var indexSize = 1
  var arrLength = arr.length
  var valLength = val.length

  if (encoding !== undefined) {
    encoding = String(encoding).toLowerCase()
    if (encoding === 'ucs2' || encoding === 'ucs-2' ||
        encoding === 'utf16le' || encoding === 'utf-16le') {
      if (arr.length < 2 || val.length < 2) {
        return -1
      }
      indexSize = 2
      arrLength /= 2
      valLength /= 2
      byteOffset /= 2
    }
  }

  function read (buf, i) {
    if (indexSize === 1) {
      return buf[i]
    } else {
      return buf.readUInt16BE(i * indexSize)
    }
  }

  var i
  if (dir) {
    var foundIndex = -1
    for (i = byteOffset; i < arrLength; i++) {
      if (read(arr, i) === read(val, foundIndex === -1 ? 0 : i - foundIndex)) {
        if (foundIndex === -1) foundIndex = i
        if (i - foundIndex + 1 === valLength) return foundIndex * indexSize
      } else {
        if (foundIndex !== -1) i -= i - foundIndex
        foundIndex = -1
      }
    }
  } else {
    if (byteOffset + valLength > arrLength) byteOffset = arrLength - valLength
    for (i = byteOffset; i >= 0; i--) {
      var found = true
      for (var j = 0; j < valLength; j++) {
        if (read(arr, i + j) !== read(val, j)) {
          found = false
          break
        }
      }
      if (found) return i
    }
  }

  return -1
}

Buffer.prototype.includes = function includes (val, byteOffset, encoding) {
  return this.indexOf(val, byteOffset, encoding) !== -1
}

Buffer.prototype.indexOf = function indexOf (val, byteOffset, encoding) {
  return bidirectionalIndexOf(this, val, byteOffset, encoding, true)
}

Buffer.prototype.lastIndexOf = function lastIndexOf (val, byteOffset, encoding) {
  return bidirectionalIndexOf(this, val, byteOffset, encoding, false)
}

function hexWrite (buf, string, offset, length) {
  offset = Number(offset) || 0
  var remaining = buf.length - offset
  if (!length) {
    length = remaining
  } else {
    length = Number(length)
    if (length > remaining) {
      length = remaining
    }
  }

  var strLen = string.length

  if (length > strLen / 2) {
    length = strLen / 2
  }
  for (var i = 0; i < length; ++i) {
    var parsed = parseInt(string.substr(i * 2, 2), 16)
    if (numberIsNaN(parsed)) return i
    buf[offset + i] = parsed
  }
  return i
}

function utf8Write (buf, string, offset, length) {
  return blitBuffer(utf8ToBytes(string, buf.length - offset), buf, offset, length)
}

function asciiWrite (buf, string, offset, length) {
  return blitBuffer(asciiToBytes(string), buf, offset, length)
}

function latin1Write (buf, string, offset, length) {
  return asciiWrite(buf, string, offset, length)
}

function base64Write (buf, string, offset, length) {
  return blitBuffer(base64ToBytes(string), buf, offset, length)
}

function ucs2Write (buf, string, offset, length) {
  return blitBuffer(utf16leToBytes(string, buf.length - offset), buf, offset, length)
}

Buffer.prototype.write = function write (string, offset, length, encoding) {
  // Buffer#write(string)
  if (offset === undefined) {
    encoding = 'utf8'
    length = this.length
    offset = 0
  // Buffer#write(string, encoding)
  } else if (length === undefined && typeof offset === 'string') {
    encoding = offset
    length = this.length
    offset = 0
  // Buffer#write(string, offset[, length][, encoding])
  } else if (isFinite(offset)) {
    offset = offset >>> 0
    if (isFinite(length)) {
      length = length >>> 0
      if (encoding === undefined) encoding = 'utf8'
    } else {
      encoding = length
      length = undefined
    }
  } else {
    throw new Error(
      'Buffer.write(string, encoding, offset[, length]) is no longer supported'
    )
  }

  var remaining = this.length - offset
  if (length === undefined || length > remaining) length = remaining

  if ((string.length > 0 && (length < 0 || offset < 0)) || offset > this.length) {
    throw new RangeError('Attempt to write outside buffer bounds')
  }

  if (!encoding) encoding = 'utf8'

  var loweredCase = false
  for (;;) {
    switch (encoding) {
      case 'hex':
        return hexWrite(this, string, offset, length)

      case 'utf8':
      case 'utf-8':
        return utf8Write(this, string, offset, length)

      case 'ascii':
        return asciiWrite(this, string, offset, length)

      case 'latin1':
      case 'binary':
        return latin1Write(this, string, offset, length)

      case 'base64':
        // Warning: maxLength not taken into account in base64Write
        return base64Write(this, string, offset, length)

      case 'ucs2':
      case 'ucs-2':
      case 'utf16le':
      case 'utf-16le':
        return ucs2Write(this, string, offset, length)

      default:
        if (loweredCase) throw new TypeError('Unknown encoding: ' + encoding)
        encoding = ('' + encoding).toLowerCase()
        loweredCase = true
    }
  }
}

Buffer.prototype.toJSON = function toJSON () {
  return {
    type: 'Buffer',
    data: Array.prototype.slice.call(this._arr || this, 0)
  }
}

function base64Slice (buf, start, end) {
  if (start === 0 && end === buf.length) {
    return base64.fromByteArray(buf)
  } else {
    return base64.fromByteArray(buf.slice(start, end))
  }
}

function utf8Slice (buf, start, end) {
  end = Math.min(buf.length, end)
  var res = []

  var i = start
  while (i < end) {
    var firstByte = buf[i]
    var codePoint = null
    var bytesPerSequence = (firstByte > 0xEF) ? 4
      : (firstByte > 0xDF) ? 3
        : (firstByte > 0xBF) ? 2
          : 1

    if (i + bytesPerSequence <= end) {
      var secondByte, thirdByte, fourthByte, tempCodePoint

      switch (bytesPerSequence) {
        case 1:
          if (firstByte < 0x80) {
            codePoint = firstByte
          }
          break
        case 2:
          secondByte = buf[i + 1]
          if ((secondByte & 0xC0) === 0x80) {
            tempCodePoint = (firstByte & 0x1F) << 0x6 | (secondByte & 0x3F)
            if (tempCodePoint > 0x7F) {
              codePoint = tempCodePoint
            }
          }
          break
        case 3:
          secondByte = buf[i + 1]
          thirdByte = buf[i + 2]
          if ((secondByte & 0xC0) === 0x80 && (thirdByte & 0xC0) === 0x80) {
            tempCodePoint = (firstByte & 0xF) << 0xC | (secondByte & 0x3F) << 0x6 | (thirdByte & 0x3F)
            if (tempCodePoint > 0x7FF && (tempCodePoint < 0xD800 || tempCodePoint > 0xDFFF)) {
              codePoint = tempCodePoint
            }
          }
          break
        case 4:
          secondByte = buf[i + 1]
          thirdByte = buf[i + 2]
          fourthByte = buf[i + 3]
          if ((secondByte & 0xC0) === 0x80 && (thirdByte & 0xC0) === 0x80 && (fourthByte & 0xC0) === 0x80) {
            tempCodePoint = (firstByte & 0xF) << 0x12 | (secondByte & 0x3F) << 0xC | (thirdByte & 0x3F) << 0x6 | (fourthByte & 0x3F)
            if (tempCodePoint > 0xFFFF && tempCodePoint < 0x110000) {
              codePoint = tempCodePoint
            }
          }
      }
    }

    if (codePoint === null) {
      // we did not generate a valid codePoint so insert a
      // replacement char (U+FFFD) and advance only 1 byte
      codePoint = 0xFFFD
      bytesPerSequence = 1
    } else if (codePoint > 0xFFFF) {
      // encode to utf16 (surrogate pair dance)
      codePoint -= 0x10000
      res.push(codePoint >>> 10 & 0x3FF | 0xD800)
      codePoint = 0xDC00 | codePoint & 0x3FF
    }

    res.push(codePoint)
    i += bytesPerSequence
  }

  return decodeCodePointsArray(res)
}

// Based on http://stackoverflow.com/a/22747272/680742, the browser with
// the lowest limit is Chrome, with 0x10000 args.
// We go 1 magnitude less, for safety
var MAX_ARGUMENTS_LENGTH = 0x1000

function decodeCodePointsArray (codePoints) {
  var len = codePoints.length
  if (len <= MAX_ARGUMENTS_LENGTH) {
    return String.fromCharCode.apply(String, codePoints) // avoid extra slice()
  }

  // Decode in chunks to avoid "call stack size exceeded".
  var res = ''
  var i = 0
  while (i < len) {
    res += String.fromCharCode.apply(
      String,
      codePoints.slice(i, i += MAX_ARGUMENTS_LENGTH)
    )
  }
  return res
}

function asciiSlice (buf, start, end) {
  var ret = ''
  end = Math.min(buf.length, end)

  for (var i = start; i < end; ++i) {
    ret += String.fromCharCode(buf[i] & 0x7F)
  }
  return ret
}

function latin1Slice (buf, start, end) {
  var ret = ''
  end = Math.min(buf.length, end)

  for (var i = start; i < end; ++i) {
    ret += String.fromCharCode(buf[i])
  }
  return ret
}

function hexSlice (buf, start, end) {
  var len = buf.length

  if (!start || start < 0) start = 0
  if (!end || end < 0 || end > len) end = len

  var out = ''
  for (var i = start; i < end; ++i) {
    out += toHex(buf[i])
  }
  return out
}

function utf16leSlice (buf, start, end) {
  var bytes = buf.slice(start, end)
  var res = ''
  for (var i = 0; i < bytes.length; i += 2) {
    res += String.fromCharCode(bytes[i] + (bytes[i + 1] * 256))
  }
  return res
}

Buffer.prototype.slice = function slice (start, end) {
  var len = this.length
  start = ~~start
  end = end === undefined ? len : ~~end

  if (start < 0) {
    start += len
    if (start < 0) start = 0
  } else if (start > len) {
    start = len
  }

  if (end < 0) {
    end += len
    if (end < 0) end = 0
  } else if (end > len) {
    end = len
  }

  if (end < start) end = start

  var newBuf = this.subarray(start, end)
  // Return an augmented `Uint8Array` instance
  newBuf.__proto__ = Buffer.prototype
  return newBuf
}

/*
 * Need to make sure that buffer isn't trying to write out of bounds.
 */
function checkOffset (offset, ext, length) {
  if ((offset % 1) !== 0 || offset < 0) throw new RangeError('offset is not uint')
  if (offset + ext > length) throw new RangeError('Trying to access beyond buffer length')
}

Buffer.prototype.readUIntLE = function readUIntLE (offset, byteLength, noAssert) {
  offset = offset >>> 0
  byteLength = byteLength >>> 0
  if (!noAssert) checkOffset(offset, byteLength, this.length)

  var val = this[offset]
  var mul = 1
  var i = 0
  while (++i < byteLength && (mul *= 0x100)) {
    val += this[offset + i] * mul
  }

  return val
}

Buffer.prototype.readUIntBE = function readUIntBE (offset, byteLength, noAssert) {
  offset = offset >>> 0
  byteLength = byteLength >>> 0
  if (!noAssert) {
    checkOffset(offset, byteLength, this.length)
  }

  var val = this[offset + --byteLength]
  var mul = 1
  while (byteLength > 0 && (mul *= 0x100)) {
    val += this[offset + --byteLength] * mul
  }

  return val
}

Buffer.prototype.readUInt8 = function readUInt8 (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 1, this.length)
  return this[offset]
}

Buffer.prototype.readUInt16LE = function readUInt16LE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 2, this.length)
  return this[offset] | (this[offset + 1] << 8)
}

Buffer.prototype.readUInt16BE = function readUInt16BE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 2, this.length)
  return (this[offset] << 8) | this[offset + 1]
}

Buffer.prototype.readUInt32LE = function readUInt32LE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 4, this.length)

  return ((this[offset]) |
      (this[offset + 1] << 8) |
      (this[offset + 2] << 16)) +
      (this[offset + 3] * 0x1000000)
}

Buffer.prototype.readUInt32BE = function readUInt32BE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 4, this.length)

  return (this[offset] * 0x1000000) +
    ((this[offset + 1] << 16) |
    (this[offset + 2] << 8) |
    this[offset + 3])
}

Buffer.prototype.readIntLE = function readIntLE (offset, byteLength, noAssert) {
  offset = offset >>> 0
  byteLength = byteLength >>> 0
  if (!noAssert) checkOffset(offset, byteLength, this.length)

  var val = this[offset]
  var mul = 1
  var i = 0
  while (++i < byteLength && (mul *= 0x100)) {
    val += this[offset + i] * mul
  }
  mul *= 0x80

  if (val >= mul) val -= Math.pow(2, 8 * byteLength)

  return val
}

Buffer.prototype.readIntBE = function readIntBE (offset, byteLength, noAssert) {
  offset = offset >>> 0
  byteLength = byteLength >>> 0
  if (!noAssert) checkOffset(offset, byteLength, this.length)

  var i = byteLength
  var mul = 1
  var val = this[offset + --i]
  while (i > 0 && (mul *= 0x100)) {
    val += this[offset + --i] * mul
  }
  mul *= 0x80

  if (val >= mul) val -= Math.pow(2, 8 * byteLength)

  return val
}

Buffer.prototype.readInt8 = function readInt8 (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 1, this.length)
  if (!(this[offset] & 0x80)) return (this[offset])
  return ((0xff - this[offset] + 1) * -1)
}

Buffer.prototype.readInt16LE = function readInt16LE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 2, this.length)
  var val = this[offset] | (this[offset + 1] << 8)
  return (val & 0x8000) ? val | 0xFFFF0000 : val
}

Buffer.prototype.readInt16BE = function readInt16BE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 2, this.length)
  var val = this[offset + 1] | (this[offset] << 8)
  return (val & 0x8000) ? val | 0xFFFF0000 : val
}

Buffer.prototype.readInt32LE = function readInt32LE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 4, this.length)

  return (this[offset]) |
    (this[offset + 1] << 8) |
    (this[offset + 2] << 16) |
    (this[offset + 3] << 24)
}

Buffer.prototype.readInt32BE = function readInt32BE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 4, this.length)

  return (this[offset] << 24) |
    (this[offset + 1] << 16) |
    (this[offset + 2] << 8) |
    (this[offset + 3])
}

Buffer.prototype.readFloatLE = function readFloatLE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 4, this.length)
  return ieee754.read(this, offset, true, 23, 4)
}

Buffer.prototype.readFloatBE = function readFloatBE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 4, this.length)
  return ieee754.read(this, offset, false, 23, 4)
}

Buffer.prototype.readDoubleLE = function readDoubleLE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 8, this.length)
  return ieee754.read(this, offset, true, 52, 8)
}

Buffer.prototype.readDoubleBE = function readDoubleBE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 8, this.length)
  return ieee754.read(this, offset, false, 52, 8)
}

function checkInt (buf, value, offset, ext, max, min) {
  if (!Buffer.isBuffer(buf)) throw new TypeError('"buffer" argument must be a Buffer instance')
  if (value > max || value < min) throw new RangeError('"value" argument is out of bounds')
  if (offset + ext > buf.length) throw new RangeError('Index out of range')
}

Buffer.prototype.writeUIntLE = function writeUIntLE (value, offset, byteLength, noAssert) {
  value = +value
  offset = offset >>> 0
  byteLength = byteLength >>> 0
  if (!noAssert) {
    var maxBytes = Math.pow(2, 8 * byteLength) - 1
    checkInt(this, value, offset, byteLength, maxBytes, 0)
  }

  var mul = 1
  var i = 0
  this[offset] = value & 0xFF
  while (++i < byteLength && (mul *= 0x100)) {
    this[offset + i] = (value / mul) & 0xFF
  }

  return offset + byteLength
}

Buffer.prototype.writeUIntBE = function writeUIntBE (value, offset, byteLength, noAssert) {
  value = +value
  offset = offset >>> 0
  byteLength = byteLength >>> 0
  if (!noAssert) {
    var maxBytes = Math.pow(2, 8 * byteLength) - 1
    checkInt(this, value, offset, byteLength, maxBytes, 0)
  }

  var i = byteLength - 1
  var mul = 1
  this[offset + i] = value & 0xFF
  while (--i >= 0 && (mul *= 0x100)) {
    this[offset + i] = (value / mul) & 0xFF
  }

  return offset + byteLength
}

Buffer.prototype.writeUInt8 = function writeUInt8 (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 1, 0xff, 0)
  this[offset] = (value & 0xff)
  return offset + 1
}

Buffer.prototype.writeUInt16LE = function writeUInt16LE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 2, 0xffff, 0)
  this[offset] = (value & 0xff)
  this[offset + 1] = (value >>> 8)
  return offset + 2
}

Buffer.prototype.writeUInt16BE = function writeUInt16BE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 2, 0xffff, 0)
  this[offset] = (value >>> 8)
  this[offset + 1] = (value & 0xff)
  return offset + 2
}

Buffer.prototype.writeUInt32LE = function writeUInt32LE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 4, 0xffffffff, 0)
  this[offset + 3] = (value >>> 24)
  this[offset + 2] = (value >>> 16)
  this[offset + 1] = (value >>> 8)
  this[offset] = (value & 0xff)
  return offset + 4
}

Buffer.prototype.writeUInt32BE = function writeUInt32BE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 4, 0xffffffff, 0)
  this[offset] = (value >>> 24)
  this[offset + 1] = (value >>> 16)
  this[offset + 2] = (value >>> 8)
  this[offset + 3] = (value & 0xff)
  return offset + 4
}

Buffer.prototype.writeIntLE = function writeIntLE (value, offset, byteLength, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) {
    var limit = Math.pow(2, (8 * byteLength) - 1)

    checkInt(this, value, offset, byteLength, limit - 1, -limit)
  }

  var i = 0
  var mul = 1
  var sub = 0
  this[offset] = value & 0xFF
  while (++i < byteLength && (mul *= 0x100)) {
    if (value < 0 && sub === 0 && this[offset + i - 1] !== 0) {
      sub = 1
    }
    this[offset + i] = ((value / mul) >> 0) - sub & 0xFF
  }

  return offset + byteLength
}

Buffer.prototype.writeIntBE = function writeIntBE (value, offset, byteLength, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) {
    var limit = Math.pow(2, (8 * byteLength) - 1)

    checkInt(this, value, offset, byteLength, limit - 1, -limit)
  }

  var i = byteLength - 1
  var mul = 1
  var sub = 0
  this[offset + i] = value & 0xFF
  while (--i >= 0 && (mul *= 0x100)) {
    if (value < 0 && sub === 0 && this[offset + i + 1] !== 0) {
      sub = 1
    }
    this[offset + i] = ((value / mul) >> 0) - sub & 0xFF
  }

  return offset + byteLength
}

Buffer.prototype.writeInt8 = function writeInt8 (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 1, 0x7f, -0x80)
  if (value < 0) value = 0xff + value + 1
  this[offset] = (value & 0xff)
  return offset + 1
}

Buffer.prototype.writeInt16LE = function writeInt16LE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 2, 0x7fff, -0x8000)
  this[offset] = (value & 0xff)
  this[offset + 1] = (value >>> 8)
  return offset + 2
}

Buffer.prototype.writeInt16BE = function writeInt16BE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 2, 0x7fff, -0x8000)
  this[offset] = (value >>> 8)
  this[offset + 1] = (value & 0xff)
  return offset + 2
}

Buffer.prototype.writeInt32LE = function writeInt32LE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 4, 0x7fffffff, -0x80000000)
  this[offset] = (value & 0xff)
  this[offset + 1] = (value >>> 8)
  this[offset + 2] = (value >>> 16)
  this[offset + 3] = (value >>> 24)
  return offset + 4
}

Buffer.prototype.writeInt32BE = function writeInt32BE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 4, 0x7fffffff, -0x80000000)
  if (value < 0) value = 0xffffffff + value + 1
  this[offset] = (value >>> 24)
  this[offset + 1] = (value >>> 16)
  this[offset + 2] = (value >>> 8)
  this[offset + 3] = (value & 0xff)
  return offset + 4
}

function checkIEEE754 (buf, value, offset, ext, max, min) {
  if (offset + ext > buf.length) throw new RangeError('Index out of range')
  if (offset < 0) throw new RangeError('Index out of range')
}

function writeFloat (buf, value, offset, littleEndian, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) {
    checkIEEE754(buf, value, offset, 4, 3.4028234663852886e+38, -3.4028234663852886e+38)
  }
  ieee754.write(buf, value, offset, littleEndian, 23, 4)
  return offset + 4
}

Buffer.prototype.writeFloatLE = function writeFloatLE (value, offset, noAssert) {
  return writeFloat(this, value, offset, true, noAssert)
}

Buffer.prototype.writeFloatBE = function writeFloatBE (value, offset, noAssert) {
  return writeFloat(this, value, offset, false, noAssert)
}

function writeDouble (buf, value, offset, littleEndian, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) {
    checkIEEE754(buf, value, offset, 8, 1.7976931348623157E+308, -1.7976931348623157E+308)
  }
  ieee754.write(buf, value, offset, littleEndian, 52, 8)
  return offset + 8
}

Buffer.prototype.writeDoubleLE = function writeDoubleLE (value, offset, noAssert) {
  return writeDouble(this, value, offset, true, noAssert)
}

Buffer.prototype.writeDoubleBE = function writeDoubleBE (value, offset, noAssert) {
  return writeDouble(this, value, offset, false, noAssert)
}

// copy(targetBuffer, targetStart=0, sourceStart=0, sourceEnd=buffer.length)
Buffer.prototype.copy = function copy (target, targetStart, start, end) {
  if (!Buffer.isBuffer(target)) throw new TypeError('argument should be a Buffer')
  if (!start) start = 0
  if (!end && end !== 0) end = this.length
  if (targetStart >= target.length) targetStart = target.length
  if (!targetStart) targetStart = 0
  if (end > 0 && end < start) end = start

  // Copy 0 bytes; we're done
  if (end === start) return 0
  if (target.length === 0 || this.length === 0) return 0

  // Fatal error conditions
  if (targetStart < 0) {
    throw new RangeError('targetStart out of bounds')
  }
  if (start < 0 || start >= this.length) throw new RangeError('Index out of range')
  if (end < 0) throw new RangeError('sourceEnd out of bounds')

  // Are we oob?
  if (end > this.length) end = this.length
  if (target.length - targetStart < end - start) {
    end = target.length - targetStart + start
  }

  var len = end - start

  if (this === target && typeof Uint8Array.prototype.copyWithin === 'function') {
    // Use built-in when available, missing from IE11
    this.copyWithin(targetStart, start, end)
  } else if (this === target && start < targetStart && targetStart < end) {
    // descending copy from end
    for (var i = len - 1; i >= 0; --i) {
      target[i + targetStart] = this[i + start]
    }
  } else {
    Uint8Array.prototype.set.call(
      target,
      this.subarray(start, end),
      targetStart
    )
  }

  return len
}

// Usage:
//    buffer.fill(number[, offset[, end]])
//    buffer.fill(buffer[, offset[, end]])
//    buffer.fill(string[, offset[, end]][, encoding])
Buffer.prototype.fill = function fill (val, start, end, encoding) {
  // Handle string cases:
  if (typeof val === 'string') {
    if (typeof start === 'string') {
      encoding = start
      start = 0
      end = this.length
    } else if (typeof end === 'string') {
      encoding = end
      end = this.length
    }
    if (encoding !== undefined && typeof encoding !== 'string') {
      throw new TypeError('encoding must be a string')
    }
    if (typeof encoding === 'string' && !Buffer.isEncoding(encoding)) {
      throw new TypeError('Unknown encoding: ' + encoding)
    }
    if (val.length === 1) {
      var code = val.charCodeAt(0)
      if ((encoding === 'utf8' && code < 128) ||
          encoding === 'latin1') {
        // Fast path: If `val` fits into a single byte, use that numeric value.
        val = code
      }
    }
  } else if (typeof val === 'number') {
    val = val & 255
  }

  // Invalid ranges are not set to a default, so can range check early.
  if (start < 0 || this.length < start || this.length < end) {
    throw new RangeError('Out of range index')
  }

  if (end <= start) {
    return this
  }

  start = start >>> 0
  end = end === undefined ? this.length : end >>> 0

  if (!val) val = 0

  var i
  if (typeof val === 'number') {
    for (i = start; i < end; ++i) {
      this[i] = val
    }
  } else {
    var bytes = Buffer.isBuffer(val)
      ? val
      : Buffer.from(val, encoding)
    var len = bytes.length
    if (len === 0) {
      throw new TypeError('The value "' + val +
        '" is invalid for argument "value"')
    }
    for (i = 0; i < end - start; ++i) {
      this[i + start] = bytes[i % len]
    }
  }

  return this
}

// HELPER FUNCTIONS
// ================

var INVALID_BASE64_RE = /[^+/0-9A-Za-z-_]/g

function base64clean (str) {
  // Node takes equal signs as end of the Base64 encoding
  str = str.split('=')[0]
  // Node strips out invalid characters like \n and \t from the string, base64-js does not
  str = str.trim().replace(INVALID_BASE64_RE, '')
  // Node converts strings with length < 2 to ''
  if (str.length < 2) return ''
  // Node allows for non-padded base64 strings (missing trailing ===), base64-js does not
  while (str.length % 4 !== 0) {
    str = str + '='
  }
  return str
}

function toHex (n) {
  if (n < 16) return '0' + n.toString(16)
  return n.toString(16)
}

function utf8ToBytes (string, units) {
  units = units || Infinity
  var codePoint
  var length = string.length
  var leadSurrogate = null
  var bytes = []

  for (var i = 0; i < length; ++i) {
    codePoint = string.charCodeAt(i)

    // is surrogate component
    if (codePoint > 0xD7FF && codePoint < 0xE000) {
      // last char was a lead
      if (!leadSurrogate) {
        // no lead yet
        if (codePoint > 0xDBFF) {
          // unexpected trail
          if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
          continue
        } else if (i + 1 === length) {
          // unpaired lead
          if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
          continue
        }

        // valid lead
        leadSurrogate = codePoint

        continue
      }

      // 2 leads in a row
      if (codePoint < 0xDC00) {
        if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
        leadSurrogate = codePoint
        continue
      }

      // valid surrogate pair
      codePoint = (leadSurrogate - 0xD800 << 10 | codePoint - 0xDC00) + 0x10000
    } else if (leadSurrogate) {
      // valid bmp char, but last char was a lead
      if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
    }

    leadSurrogate = null

    // encode utf8
    if (codePoint < 0x80) {
      if ((units -= 1) < 0) break
      bytes.push(codePoint)
    } else if (codePoint < 0x800) {
      if ((units -= 2) < 0) break
      bytes.push(
        codePoint >> 0x6 | 0xC0,
        codePoint & 0x3F | 0x80
      )
    } else if (codePoint < 0x10000) {
      if ((units -= 3) < 0) break
      bytes.push(
        codePoint >> 0xC | 0xE0,
        codePoint >> 0x6 & 0x3F | 0x80,
        codePoint & 0x3F | 0x80
      )
    } else if (codePoint < 0x110000) {
      if ((units -= 4) < 0) break
      bytes.push(
        codePoint >> 0x12 | 0xF0,
        codePoint >> 0xC & 0x3F | 0x80,
        codePoint >> 0x6 & 0x3F | 0x80,
        codePoint & 0x3F | 0x80
      )
    } else {
      throw new Error('Invalid code point')
    }
  }

  return bytes
}

function asciiToBytes (str) {
  var byteArray = []
  for (var i = 0; i < str.length; ++i) {
    // Node's code seems to be doing this and not & 0x7F..
    byteArray.push(str.charCodeAt(i) & 0xFF)
  }
  return byteArray
}

function utf16leToBytes (str, units) {
  var c, hi, lo
  var byteArray = []
  for (var i = 0; i < str.length; ++i) {
    if ((units -= 2) < 0) break

    c = str.charCodeAt(i)
    hi = c >> 8
    lo = c % 256
    byteArray.push(lo)
    byteArray.push(hi)
  }

  return byteArray
}

function base64ToBytes (str) {
  return base64.toByteArray(base64clean(str))
}

function blitBuffer (src, dst, offset, length) {
  for (var i = 0; i < length; ++i) {
    if ((i + offset >= dst.length) || (i >= src.length)) break
    dst[i + offset] = src[i]
  }
  return i
}

// ArrayBuffer or Uint8Array objects from other contexts (i.e. iframes) do not pass
// the `instanceof` check but they should be treated as of that type.
// See: https://github.com/feross/buffer/issues/166
function isInstance (obj, type) {
  return obj instanceof type ||
    (obj != null && obj.constructor != null && obj.constructor.name != null &&
      obj.constructor.name === type.name)
}
function numberIsNaN (obj) {
  // For IE11 support
  return obj !== obj // eslint-disable-line no-self-compare
}


/***/ }),

/***/ "./node_modules/cleaners/lib/cjs/cleaners.js":
/*!***************************************************!*\
  !*** ./node_modules/cleaners/lib/cjs/cleaners.js ***!
  \***************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({ value: true }));

/**
 * Given a JS value, produce a descriptive string.
 */
function showValue(value) {
  switch (typeof value) {
    case 'function':
    case 'object':
      if (value == null) return 'null';
      if (Array.isArray(value)) return 'array';
      return typeof value;

    case 'string':
      return JSON.stringify(value);

    default:
      return String(value);
  }
}

function asOptional(cleaner, fallback) {
  return function asOptional(raw) {
    return raw != null ? cleaner(raw) : typeof fallback === 'function' ? fallback() : fallback;
  };
}

function asValue() {
  for (var _len = arguments.length, values = new Array(_len), _key = 0; _key < _len; _key++) {
    values[_key] = arguments[_key];
  }

  return function asValue(raw) {
    for (var i = 0; i < values.length; ++i) {
      if (raw === values[i]) return raw;
    } // Create a fancy error message:


    var message = 'Expected ';
    if (values.length !== 1) message += 'one of: ';

    for (var _i = 0; _i < values.length; ++_i) {
      if (_i > 0) message += ' | ';
      message += JSON.stringify(values[_i]);
    }

    message += ', got ' + showValue(raw);
    throw new TypeError(message);
  };
}

function asBoolean(raw) {
  if (typeof raw !== 'boolean') {
    throw new TypeError('Expected a boolean, got ' + showValue(raw));
  }

  return raw;
}
function asNumber(raw) {
  if (typeof raw !== 'number') {
    throw new TypeError('Expected a number, got ' + showValue(raw));
  }

  return raw;
}
function asString(raw) {
  if (typeof raw !== 'string') {
    throw new TypeError('Expected a string, got ' + showValue(raw));
  }

  return raw;
}
var asNull = asValue(null);
var asUndefined = asValue(undefined);
function asUnknown(raw) {
  return raw;
} // Deprecated:

var asNone = asOptional(asNull);

/**
 * Adds location information to an error message.
 *
 * Errors can occur inside deeply-nested cleaners,
 * such as "TypeError: Expected a string at .array[0].some.property".
 * To build this information, each cleaner along the path
 * should add its own location information as the stack unwinds.
 *
 * If the error has a `insertStepAt` property, that is the character offset
 * where the next step will go in the error message. Otherwise,
 * the next step just goes on the end of the string with the word "at".
 */
function locateError(error, step, offset) {
  if (error instanceof Error) {
    if (error.insertStepAt == null) {
      error.message += ' at ';
      error.insertStepAt = error.message.length;
    }

    error.message = error.message.slice(0, error.insertStepAt) + step + error.message.slice(error.insertStepAt);
    error.insertStepAt += offset;
  }

  return error;
}

function asArray(cleaner) {
  return function asArray(raw) {
    if (!Array.isArray(raw)) {
      throw new TypeError('Expected an array, got ' + showValue(raw));
    }

    var out = [];

    for (var i = 0; i < raw.length; ++i) {
      try {
        out[i] = cleaner(raw[i]);
      } catch (error) {
        throw locateError(error, '[' + i + ']', 0);
      }
    }

    return out;
  };
}

function asObject(shape) {
  // The key-value version:
  if (typeof shape === 'function') {
    return function asObject(raw) {
      if (typeof raw !== 'object' || raw == null) {
        throw new TypeError('Expected an object, got ' + showValue(raw));
      }

      var out = {};
      var keys = Object.keys(raw);

      for (var i = 0; i < keys.length; ++i) {
        var key = keys[i];
        if (key === '__proto__') continue;

        try {
          out[key] = shape(raw[key]);
        } catch (error) {
          throw locateError(error, '[' + JSON.stringify(key) + ']', 0);
        }
      }

      return out;
    };
  } // The shape-aware version:


  var keys = Object.keys(shape);

  function bindObjectShape(keepRest) {
    return function asObject(raw) {
      if (typeof raw !== 'object' || raw == null) {
        throw new TypeError('Expected an object, got ' + showValue(raw));
      }

      var i;
      var out = {};

      if (keepRest) {
        var toCopy = Object.keys(raw);

        for (i = 0; i < toCopy.length; ++i) {
          var key = toCopy[i];
          if (key === '__proto__') continue;
          out[key] = raw[key];
        }
      }

      for (i = 0; i < keys.length; ++i) {
        var _key = keys[i];

        try {
          out[_key] = shape[_key](raw[_key]);
        } catch (error) {
          throw locateError(error, '.' + _key, 0);
        }
      }

      return out;
    };
  }

  var out = bindObjectShape(false);
  out.shape = shape;
  out.withRest = bindObjectShape(true);
  return out;
} // Deprecated:

var asMap = asObject;

function asTuple() {
  for (var _len = arguments.length, shape = new Array(_len), _key = 0; _key < _len; _key++) {
    shape[_key] = arguments[_key];
  }

  function asTuple(raw) {
    if (!Array.isArray(raw)) {
      throw new TypeError('Expected an array, got ' + showValue(raw));
    }

    var out = [];

    for (var i = 0; i < shape.length; ++i) {
      try {
        out[i] = shape[i](raw[i]);
      } catch (error) {
        throw locateError(error, "[" + i + "]");
      }
    }

    return out;
  }

  return asTuple;
}

function asEither() {
  for (var _len = arguments.length, shape = new Array(_len), _key = 0; _key < _len; _key++) {
    shape[_key] = arguments[_key];
  }

  return function asEither(raw) {
    for (var i = 0; i < shape.length; i++) {
      try {
        return shape[i](raw);
      } catch (error) {
        if (i + 1 >= shape.length) throw error;
      }
    }
  };
}

function asMaybe(cleaner, fallback) {
  return function asMaybe(raw) {
    try {
      return cleaner(raw);
    } catch (e) {
      return typeof fallback === 'function' ? fallback() : fallback;
    }
  };
}

function asCodec(cleaner, uncleaner) {
  return function asCodec(raw) {
    return global[uncleaning] > 0 ? uncleaner(raw) : cleaner(raw);
  };
}
function uncleaner(cleaner) {
  return function uncleaner(raw) {
    // We need to set a flag to indicate that we are un-cleaning.
    // The flag needs to be in a global location,
    // since multiple cleaner implementations should agree
    // which mode we are in.
    if (global[uncleaning] == null) {
      Object.defineProperty(global, uncleaning, {
        value: 0,
        writable: true
      });
    }

    try {
      ++global[uncleaning];
      return cleaner(raw);
    } finally {
      --global[uncleaning];
    }
  };
} // If we cannot find the standardized "globalThis" object,
// fall back on using the "JSON" constructor, which is also well-known.

var global = typeof globalThis === 'object' && globalThis != null ? globalThis : JSON;
/* istanbul ignore next */

var uncleaning = typeof Symbol === 'function' ? Symbol["for"]('uncleaning') : 'uncleaning';

var asDate = asCodec(function asDate(raw) {
  if (typeof raw !== 'string' && !(raw instanceof Date)) {
    throw new TypeError('Expected a date string, got ' + showValue(raw));
  }

  var out = new Date(raw);

  if (out.toJSON() == null) {
    throw new TypeError('Invalid date format, got ' + showValue(raw));
  }

  return out;
}, function wasDate(clean) {
  return clean.toISOString();
});

function asJSON(cleaner) {
  return asCodec(function asJSON(raw) {
    var value = JSON.parse(asString(raw));

    try {
      return cleaner(value);
    } catch (error) {
      throw locateError(error, 'JSON.parse()', 11);
    }
  }, function wasJSON(clean) {
    return JSON.stringify(cleaner(clean));
  });
}

exports.asArray = asArray;
exports.asBoolean = asBoolean;
exports.asCodec = asCodec;
exports.asDate = asDate;
exports.asEither = asEither;
exports.asJSON = asJSON;
exports.asMap = asMap;
exports.asMaybe = asMaybe;
exports.asNone = asNone;
exports.asNull = asNull;
exports.asNumber = asNumber;
exports.asObject = asObject;
exports.asOptional = asOptional;
exports.asString = asString;
exports.asTuple = asTuple;
exports.asUndefined = asUndefined;
exports.asUnknown = asUnknown;
exports.asValue = asValue;
exports.uncleaner = uncleaner;


/***/ }),

/***/ "./node_modules/edge-core-js/types.js":
/*!********************************************!*\
  !*** ./node_modules/edge-core-js/types.js ***!
  \********************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({ value: true }));

var cleaners = __webpack_require__(/*! cleaners */ "./node_modules/cleaners/lib/cjs/cleaners.js");
var rfc4648 = __webpack_require__(/*! rfc4648 */ "./node_modules/rfc4648/lib/cjs/rfc4648.js");

/**
 * A string of hex-encoded binary data.
 */
const asBase16 = cleaners.asCodec(raw => rfc4648.base16.parse(cleaners.asString(raw)), clean => rfc4648.base16.stringify(clean).toLowerCase());

/**
 * A string of base32-encoded binary data.
 */
const asBase32 = cleaners.asCodec(raw => rfc4648.base32.parse(cleaners.asString(raw), {
  loose: true
}), clean => rfc4648.base32.stringify(clean, {
  pad: false
}));

/**
 * A string of base64-encoded binary data.
 */
const asBase64 = cleaners.asCodec(raw => rfc4648.base64.parse(cleaners.asString(raw)), clean => rfc4648.base64.stringify(clean));

// ---------------------------------------------------------------------
// public Edge types
// ---------------------------------------------------------------------

const asEdgePendingVoucher = cleaners.asObject({
  voucherId: cleaners.asString,
  activates: cleaners.asDate,
  created: cleaners.asDate,
  ip: cleaners.asString,
  ipDescription: cleaners.asString,
  deviceDescription: cleaners.asOptional(cleaners.asString)
});

// ---------------------------------------------------------------------
// internal Edge types
// ---------------------------------------------------------------------

const asEdgeBox = cleaners.asObject({
  encryptionType: cleaners.asNumber,
  data_base64: asBase64,
  iv_hex: asBase16
});
const asEdgeKeyBox = cleaners.asObject({
  created: cleaners.asOptional(cleaners.asDate),
  data_base64: asBase64,
  encryptionType: cleaners.asNumber,
  iv_hex: asBase16
});
const asEdgeSnrp = cleaners.asObject({
  salt_hex: asBase16,
  n: cleaners.asNumber,
  r: cleaners.asNumber,
  p: cleaners.asNumber
});
const asEdgeLobbyRequest = cleaners.asObject({
  loginRequest: cleaners.asOptional(cleaners.asObject({
    appId: cleaners.asString
  }).withRest),
  publicKey: asBase64,
  timeout: cleaners.asOptional(cleaners.asNumber)
}).withRest;
const asEdgeLobbyReply = cleaners.asObject({
  publicKey: asBase64,
  box: asEdgeBox
});

/**
 * An array of base64-encoded hashed recovery answers.
 */
const asRecovery2Auth = cleaners.asArray(asBase64);

// ---------------------------------------------------------------------
// top-level request & response bodies
// ---------------------------------------------------------------------

const asLoginRequestBody = cleaners.asObject({
  // The request payload:
  data: cleaners.asUnknown,
  // Common fields for all login methods:
  challengeId: cleaners.asOptional(cleaners.asString),
  deviceDescription: cleaners.asOptional(cleaners.asString),
  otp: cleaners.asOptional(cleaners.asString),
  syncToken: cleaners.asOptional(cleaners.asString),
  voucherId: cleaners.asOptional(cleaners.asString),
  voucherAuth: cleaners.asOptional(asBase64),
  // Secret-key login:
  loginId: cleaners.asOptional(asBase64),
  loginAuth: cleaners.asOptional(asBase64),
  // Password login:
  userId: cleaners.asOptional(asBase64),
  passwordAuth: cleaners.asOptional(asBase64),
  // PIN login:
  pin2Id: cleaners.asOptional(asBase64),
  pin2Auth: cleaners.asOptional(asBase64),
  // Recovery login:
  recovery2Id: cleaners.asOptional(asBase64),
  recovery2Auth: cleaners.asOptional(asRecovery2Auth),
  // Messages:
  loginIds: cleaners.asOptional(cleaners.asArray(asBase64)),
  // OTP reset:
  otpResetAuth: cleaners.asOptional(cleaners.asString),
  // Legacy:
  did: cleaners.asOptional(cleaners.asString),
  l1: cleaners.asOptional(asBase64),
  lp1: cleaners.asOptional(asBase64),
  lpin1: cleaners.asOptional(asBase64),
  lra1: cleaners.asOptional(asBase64),
  recoveryAuth: cleaners.asOptional(asBase64) // lra1
});

const asLoginResponseBody = cleaners.asObject({
  // The response payload:
  results: cleaners.asOptional(cleaners.asUnknown),
  // What type of response is this (success or failure)?:
  status_code: cleaners.asNumber,
  message: cleaners.asString
});

// ---------------------------------------------------------------------
// request payloads
// ---------------------------------------------------------------------

const asChangeOtpPayload = cleaners.asObject({
  otpTimeout: cleaners.asOptional(cleaners.asNumber, 7 * 24 * 60 * 60),
  // seconds
  otpKey: asBase32
});
const asChangePasswordPayload = cleaners.asObject({
  passwordAuth: asBase64,
  passwordAuthBox: asEdgeBox,
  passwordAuthSnrp: asEdgeSnrp,
  passwordBox: asEdgeBox,
  passwordKeySnrp: asEdgeSnrp
});
const asChangePin2IdPayload = cleaners.asObject({
  pin2Id: asBase64
});
const asChangePin2Payload = cleaners.asObject({
  pin2Id: cleaners.asOptional(asBase64),
  pin2Auth: cleaners.asOptional(asBase64),
  pin2Box: cleaners.asOptional(asEdgeBox),
  pin2KeyBox: cleaners.asOptional(asEdgeBox),
  pin2TextBox: asEdgeBox
});
const asChangeRecovery2IdPayload = cleaners.asObject({
  recovery2Id: asBase64
});
const asChangeRecovery2Payload = cleaners.asObject({
  recovery2Id: asBase64,
  recovery2Auth: asRecovery2Auth,
  recovery2Box: asEdgeBox,
  recovery2KeyBox: asEdgeBox,
  question2Box: asEdgeBox
});
const asChangeSecretPayload = cleaners.asObject({
  loginAuthBox: asEdgeBox,
  loginAuth: asBase64
});
const asChangeUsernamePayload = cleaners.asObject({
  userId: asBase64,
  userTextBox: asEdgeBox
});
const asChangeVouchersPayload = cleaners.asObject({
  approvedVouchers: cleaners.asOptional(cleaners.asArray(cleaners.asString)),
  rejectedVouchers: cleaners.asOptional(cleaners.asArray(cleaners.asString))
});
const asCreateKeysPayload = cleaners.asObject({
  keyBoxes: cleaners.asArray(asEdgeBox),
  newSyncKeys: cleaners.asOptional(cleaners.asArray(cleaners.asString), () => [])
});
const asCreateLoginPayload = cleaners.asObject({
  appId: cleaners.asString,
  loginId: asBase64,
  parentBox: cleaners.asOptional(asEdgeBox)
});

// ---------------------------------------------------------------------
// response payloads
// ---------------------------------------------------------------------

const asChallengeErrorPayload = cleaners.asObject({
  challengeId: cleaners.asString,
  challengeUri: cleaners.asString
});
const asCreateChallengePayload = cleaners.asObject({
  challengeId: cleaners.asString,
  challengeUri: cleaners.asOptional(cleaners.asString)
});
const asLobbyPayload = cleaners.asObject({
  request: asEdgeLobbyRequest,
  replies: cleaners.asArray(asEdgeLobbyReply)
});
const asTrue = cleaners.asValue(true);
const asLoginPayload = cleaners.asObject({
  // Identity:
  appId: cleaners.asString,
  created: cleaners.asDate,
  loginId: asBase64,
  syncToken: cleaners.asOptional(cleaners.asString),
  // Nested logins:
  children: cleaners.asOptional(cleaners.asArray(raw => asLoginPayload(raw))),
  parentBox: cleaners.asOptional(asEdgeBox),
  // 2-factor login:
  otpKey: cleaners.asOptional(cleaners.asEither(asTrue, asBase32)),
  otpResetDate: cleaners.asOptional(cleaners.asDate),
  otpTimeout: cleaners.asOptional(cleaners.asNumber),
  // Password login:
  passwordAuthBox: cleaners.asOptional(asEdgeBox),
  passwordAuthSnrp: cleaners.asOptional(asEdgeSnrp),
  passwordBox: cleaners.asOptional(cleaners.asEither(asTrue, asEdgeBox)),
  passwordKeySnrp: cleaners.asOptional(asEdgeSnrp),
  // PIN v2 login:
  pin2Box: cleaners.asOptional(cleaners.asEither(asTrue, asEdgeBox)),
  pin2KeyBox: cleaners.asOptional(asEdgeBox),
  pin2TextBox: cleaners.asOptional(asEdgeBox),
  // Recovery v2 login:
  question2Box: cleaners.asOptional(asEdgeBox),
  recovery2Box: cleaners.asOptional(cleaners.asEither(asTrue, asEdgeBox)),
  recovery2KeyBox: cleaners.asOptional(asEdgeBox),
  // Secret-key login:
  loginAuthBox: cleaners.asOptional(asEdgeBox),
  // Username:
  userId: cleaners.asOptional(asBase64),
  userTextBox: cleaners.asOptional(asEdgeBox),
  // Voucher login:
  pendingVouchers: cleaners.asOptional(cleaners.asArray(asEdgePendingVoucher), () => []),
  // Resources:
  keyBoxes: cleaners.asOptional(cleaners.asArray(asEdgeKeyBox)),
  mnemonicBox: cleaners.asOptional(asEdgeBox),
  rootKeyBox: cleaners.asOptional(asEdgeBox),
  syncKeyBox: cleaners.asOptional(asEdgeBox)
});
const asMessagesPayload = cleaners.asArray(cleaners.asObject({
  loginId: asBase64,
  otpResetPending: cleaners.asOptional(cleaners.asBoolean, false),
  pendingVouchers: cleaners.asOptional(cleaners.asArray(asEdgePendingVoucher), () => []),
  recovery2Corrupt: cleaners.asOptional(cleaners.asBoolean, false)
}));
const asOtpErrorPayload = cleaners.asObject({
  login_id: cleaners.asOptional(asBase64),
  otp_reset_auth: cleaners.asOptional(cleaners.asString),
  otp_timeout_date: cleaners.asOptional(cleaners.asDate),
  reason: cleaners.asOptional(cleaners.asValue('ip', 'otp'), 'otp'),
  voucher_activates: cleaners.asOptional(cleaners.asDate),
  voucher_auth: cleaners.asOptional(asBase64),
  voucher_id: cleaners.asOptional(cleaners.asString)
});
const asOtpResetPayload = cleaners.asObject({
  otpResetDate: cleaners.asDate
});
const asPasswordErrorPayload = cleaners.asObject({
  wait_seconds: cleaners.asOptional(cleaners.asNumber)
});
const asRecovery2InfoPayload = cleaners.asObject({
  question2Box: asEdgeBox
});
const asUsernameInfoPayload = cleaners.asObject({
  loginId: asBase64,
  // Password login:
  passwordAuthSnrp: cleaners.asOptional(asEdgeSnrp),
  // Recovery v1 login:
  questionBox: cleaners.asOptional(asEdgeBox),
  questionKeySnrp: cleaners.asOptional(asEdgeSnrp),
  recoveryAuthSnrp: cleaners.asOptional(asEdgeSnrp)
});

// ---------------------------------------------------------------------
// uncleaners
// ---------------------------------------------------------------------

// Common types:
const wasEdgeBox = cleaners.uncleaner(asEdgeBox);
const wasEdgeLobbyReply = cleaners.uncleaner(asEdgeLobbyReply);
const wasEdgeLobbyRequest = cleaners.uncleaner(asEdgeLobbyRequest);

// Top-level request / response bodies:
const wasLoginRequestBody = cleaners.uncleaner(asLoginRequestBody);
const wasLoginResponseBody = cleaners.uncleaner(asLoginResponseBody);

// Request payloads:
const wasChangeOtpPayload = cleaners.uncleaner(asChangeOtpPayload);
const wasChangePasswordPayload = cleaners.uncleaner(asChangePasswordPayload);
const wasChangePin2IdPayload = cleaners.uncleaner(asChangePin2IdPayload);
const wasChangePin2Payload = cleaners.uncleaner(asChangePin2Payload);
const wasChangeRecovery2IdPayload = cleaners.uncleaner(asChangeRecovery2IdPayload);
const wasChangeRecovery2Payload = cleaners.uncleaner(asChangeRecovery2Payload);
const wasChangeSecretPayload = cleaners.uncleaner(asChangeSecretPayload);
const wasChangeUsernamePayload = cleaners.uncleaner(asChangeUsernamePayload);
const wasChangeVouchersPayload = cleaners.uncleaner(asChangeVouchersPayload);
const wasCreateKeysPayload = cleaners.uncleaner(asCreateKeysPayload);
const wasCreateLoginPayload = cleaners.uncleaner(asCreateLoginPayload);

// Response payloads:
const wasChallengeErrorPayload = cleaners.uncleaner(asChallengeErrorPayload);
const wasCreateChallengePayload = cleaners.uncleaner(asCreateChallengePayload);
const wasLobbyPayload = cleaners.uncleaner(asLobbyPayload);
const wasLoginPayload = cleaners.uncleaner(asLoginPayload);
const wasMessagesPayload = cleaners.uncleaner(asMessagesPayload);
const wasOtpErrorPayload = cleaners.uncleaner(asOtpErrorPayload);
const wasOtpResetPayload = cleaners.uncleaner(asOtpResetPayload);
const wasPasswordErrorPayload = cleaners.uncleaner(asPasswordErrorPayload);
const wasRecovery2InfoPayload = cleaners.uncleaner(asRecovery2InfoPayload);
const wasUsernameInfoPayload = cleaners.uncleaner(asUsernameInfoPayload);

/*
 * These are errors the core knows about.
 *
 * The GUI should handle these errors in an "intelligent" way, such as by
 * displaying a localized error message or asking the user for more info.
 * All these errors have a `name` field, which the GUI can use to select
 * the appropriate response.
 *
 * Other errors are possible, of course, since the Javascript language
 * itself can generate exceptions. Those errors won't have a `type` field,
 * and the GUI should just show them with a stack trace & generic message,
 * since the program has basically crashed at that point.
 */
/**
 * Thrown when the login server requires a CAPTCHA.
 *
 * After showing the WebView with the challengeUri,
 * pass the challengeId to the login method
 * (such as loginWithPassword) to complete the login.
 *
 * The challengeUri web page will signal that it is done by navigating
 * to a new location that ends with either /success or /failure,
 * such as https://login.edge.app/challenge/success
 * The login UI can use this as a signal to close the WebView.
 */
function ChallengeError(resultsJson, message = 'Login requires a CAPTCHA') {
  if (!(this instanceof ChallengeError)) throw new TypeError("Class constructor ChallengeError cannot be invoked without 'new'");
  var _this;
  function _super(message) {
    _this = new Error(message);
    Object.defineProperty(_this, "constructor", {
      value: ChallengeError,
      configurable: true,
      writable: true
    });
    return _this;
  }
  _super(message);
  _this.name = 'ChallengeError';
  _this.challengeId = resultsJson.challengeId;
  _this.challengeUri = resultsJson.challengeUri;
  return _this;
}

/**
 * Trying to spend an uneconomically small amount of money.
 */
function DustSpendError(message = 'Please send a larger amount') {
  if (!(this instanceof DustSpendError)) throw new TypeError("Class constructor DustSpendError cannot be invoked without 'new'");
  var _this2;
  function _super2(message) {
    _this2 = new Error(message);
    Object.defineProperty(_this2, "constructor", {
      value: DustSpendError,
      configurable: true,
      writable: true
    });
    return _this2;
  }
  _super2(message);
  _this2.name = 'DustSpendError';
  return _this2;
}
/**
 * Trying to spend more money than the wallet contains.
 */
function InsufficientFundsError(opts) {
  if (!(this instanceof InsufficientFundsError)) throw new TypeError("Class constructor InsufficientFundsError cannot be invoked without 'new'");
  var _this3;
  function _super3(message) {
    _this3 = new Error(message);
    Object.defineProperty(_this3, "constructor", {
      value: InsufficientFundsError,
      configurable: true,
      writable: true
    });
    return _this3;
  }
  const {
    tokenId = null,
    networkFee
  } = opts ?? {};
  _super3(`Insufficient ${tokenId ?? 'funds'}`);
  _this3.tokenId = tokenId;
  _this3.networkFee = networkFee;
  _this3.name = 'InsufficientFundsError';
  return _this3;
}

/**
 * Could not reach the server at all.
 */
function NetworkError(message = 'Cannot reach the network') {
  if (!(this instanceof NetworkError)) throw new TypeError("Class constructor NetworkError cannot be invoked without 'new'");
  var _this4;
  function _super4(message) {
    _this4 = new Error(message);
    Object.defineProperty(_this4, "constructor", {
      value: NetworkError,
      configurable: true,
      writable: true
    });
    return _this4;
  }
  _super4(message);
  _this4.name = 'NetworkError';
  return _this4;
}

/**
 * Attempting to create a MakeSpend without specifying an amount of currency to send
 */
function NoAmountSpecifiedError(message = 'Unable to create zero-amount transaction.') {
  if (!(this instanceof NoAmountSpecifiedError)) throw new TypeError("Class constructor NoAmountSpecifiedError cannot be invoked without 'new'");
  var _this5;
  function _super5(message) {
    _this5 = new Error(message);
    Object.defineProperty(_this5, "constructor", {
      value: NoAmountSpecifiedError,
      configurable: true,
      writable: true
    });
    return _this5;
  }
  _super5(message);
  _this5.name = 'NoAmountSpecifiedError';
  return _this5;
}

/**
 * The endpoint on the server is obsolete, and the app needs to be upgraded.
 */
function ObsoleteApiError(message = 'The application is too old. Please upgrade.') {
  if (!(this instanceof ObsoleteApiError)) throw new TypeError("Class constructor ObsoleteApiError cannot be invoked without 'new'");
  var _this6;
  function _super6(message) {
    _this6 = new Error(message);
    Object.defineProperty(_this6, "constructor", {
      value: ObsoleteApiError,
      configurable: true,
      writable: true
    });
    return _this6;
  }
  _super6(message);
  _this6.name = 'ObsoleteApiError';
  return _this6;
}

/**
 * The OTP token was missing / incorrect.
 *
 * The error object should include a `resetToken` member,
 * which can be used to reset OTP protection on the account.
 *
 * The error object may include a `resetDate` member,
 * which indicates that an OTP reset is already pending,
 * and when it will complete.
 */
function OtpError(resultsJson, message = 'Invalid OTP token') {
  if (!(this instanceof OtpError)) throw new TypeError("Class constructor OtpError cannot be invoked without 'new'");
  var _this7;
  function _super7(message) {
    _this7 = new Error(message);
    Object.defineProperty(_this7, "constructor", {
      value: OtpError,
      configurable: true,
      writable: true
    });
    return _this7;
  }
  _super7(message);
  _this7.name = 'OtpError';
  _this7.reason = 'otp';
  const clean = cleaners.asMaybe(asOtpErrorPayload)(resultsJson);
  if (clean == null) return;
  if (clean.login_id != null) {
    _this7.loginId = rfc4648.base64.stringify(clean.login_id);
  }
  _this7.resetToken = clean.otp_reset_auth;
  _this7.reason = clean.reason;
  _this7.resetDate = clean.otp_timeout_date;
  _this7.voucherActivates = clean.voucher_activates;
  if (clean.voucher_auth != null) {
    _this7.voucherAuth = rfc4648.base64.stringify(clean.voucher_auth);
  }
  _this7.voucherId = clean.voucher_id;
  return _this7;
}

/**
 * The provided authentication is incorrect.
 *
 * Reasons could include:
 * - Password login: wrong password
 * - PIN login: wrong PIN
 * - Recovery login: wrong answers
 *
 * The error object may include a `wait` member,
 * which is the number of seconds the user must wait before trying again.
 */
function PasswordError(resultsJson, message = 'Invalid password') {
  if (!(this instanceof PasswordError)) throw new TypeError("Class constructor PasswordError cannot be invoked without 'new'");
  var _this8;
  function _super8(message) {
    _this8 = new Error(message);
    Object.defineProperty(_this8, "constructor", {
      value: PasswordError,
      configurable: true,
      writable: true
    });
    return _this8;
  }
  _super8(message);
  _this8.name = 'PasswordError';
  const clean = cleaners.asMaybe(asPasswordErrorPayload)(resultsJson);
  if (clean == null) return;
  _this8.wait = clean.wait_seconds;
  return _this8;
}

/**
 * Trying to spend funds that are not yet confirmed.
 */
function PendingFundsError(message = 'Not enough confirmed funds') {
  if (!(this instanceof PendingFundsError)) throw new TypeError("Class constructor PendingFundsError cannot be invoked without 'new'");
  var _this9;
  function _super9(message) {
    _this9 = new Error(message);
    Object.defineProperty(_this9, "constructor", {
      value: PendingFundsError,
      configurable: true,
      writable: true
    });
    return _this9;
  }
  _super9(message);
  _this9.name = 'PendingFundsError';
  return _this9;
}

/**
 * Attempting to shape shift between two wallets of same currency.
 */
function SameCurrencyError(message = 'Wallets can not be the same currency') {
  if (!(this instanceof SameCurrencyError)) throw new TypeError("Class constructor SameCurrencyError cannot be invoked without 'new'");
  var _this10;
  function _super10(message) {
    _this10 = new Error(message);
    Object.defineProperty(_this10, "constructor", {
      value: SameCurrencyError,
      configurable: true,
      writable: true
    });
    return _this10;
  }
  _super10(message);
  _this10.name = 'SameCurrencyError';
  return _this10;
}

/**
 * Trying to spend to an address of the source wallet
 */
function SpendToSelfError(message = 'Spending to self') {
  if (!(this instanceof SpendToSelfError)) throw new TypeError("Class constructor SpendToSelfError cannot be invoked without 'new'");
  var _this11;
  function _super11(message) {
    _this11 = new Error(message);
    Object.defineProperty(_this11, "constructor", {
      value: SpendToSelfError,
      configurable: true,
      writable: true
    });
    return _this11;
  }
  _super11(message);
  _this11.name = 'SpendToSelfError';
  return _this11;
}

/**
 * Trying to swap an amount that is either too low or too high.
 * @param nativeMax the maximum supported amount, in the currency specified
 * by the direction (defaults to "from" currency)
 */
function SwapAboveLimitError(swapInfo, nativeMax, direction = 'from') {
  if (!(this instanceof SwapAboveLimitError)) throw new TypeError("Class constructor SwapAboveLimitError cannot be invoked without 'new'");
  var _this12;
  function _super12(message) {
    _this12 = new Error(message);
    Object.defineProperty(_this12, "constructor", {
      value: SwapAboveLimitError,
      configurable: true,
      writable: true
    });
    return _this12;
  }
  _super12('Amount is too high');
  _this12.name = 'SwapAboveLimitError';
  _this12.pluginId = swapInfo.pluginId;
  _this12.nativeMax = nativeMax;
  _this12.direction = direction;
  return _this12;
}

/**
 * Trying to swap an amount that is either too low or too high.
 * @param nativeMin the minimum supported amount, in the currency specified
 * by the direction (defaults to "from" currency)
 */
function SwapBelowLimitError(swapInfo, nativeMin, direction = 'from') {
  if (!(this instanceof SwapBelowLimitError)) throw new TypeError("Class constructor SwapBelowLimitError cannot be invoked without 'new'");
  var _this13;
  function _super13(message) {
    _this13 = new Error(message);
    Object.defineProperty(_this13, "constructor", {
      value: SwapBelowLimitError,
      configurable: true,
      writable: true
    });
    return _this13;
  }
  _super13('Amount is too low');
  _this13.name = 'SwapBelowLimitError';
  _this13.pluginId = swapInfo.pluginId;
  _this13.nativeMin = nativeMin;
  _this13.direction = direction;
  return _this13;
}

/**
 * The swap plugin does not support this currency pair.
 */
function SwapCurrencyError(swapInfo, request) {
  if (!(this instanceof SwapCurrencyError)) throw new TypeError("Class constructor SwapCurrencyError cannot be invoked without 'new'");
  var _this14;
  function _super14(message) {
    _this14 = new Error(message);
    Object.defineProperty(_this14, "constructor", {
      value: SwapCurrencyError,
      configurable: true,
      writable: true
    });
    return _this14;
  }
  const {
    fromWallet,
    toWallet,
    fromTokenId,
    toTokenId
  } = request;
  const fromPluginId = fromWallet.currencyConfig.currencyInfo.pluginId;
  const toPluginId = toWallet.currencyConfig.currencyInfo.pluginId;
  const fromString = `${fromPluginId}:${String(fromTokenId)}`;
  const toString = `${toPluginId}:${String(toTokenId)}`;
  _super14(`${swapInfo.displayName} does not support ${fromString} to ${toString}`);
  _this14.name = 'SwapCurrencyError';
  _this14.pluginId = swapInfo.pluginId;
  _this14.fromTokenId = fromTokenId ?? null;
  _this14.toTokenId = toTokenId ?? null;
  return _this14;
}
/**
 * The user is not allowed to swap these coins for some reason
 * (no KYC, restricted IP address, etc...).
 * @param reason A string giving the reason for the denial.
 * - 'geoRestriction': The IP address is in a restricted region
 * - 'noVerification': The user needs to provide KYC credentials
 * - 'needsActivation': The user needs to log into the service.
 */
function SwapPermissionError(swapInfo, reason) {
  if (!(this instanceof SwapPermissionError)) throw new TypeError("Class constructor SwapPermissionError cannot be invoked without 'new'");
  var _this15;
  function _super15(message) {
    _this15 = new Error(message);
    Object.defineProperty(_this15, "constructor", {
      value: SwapPermissionError,
      configurable: true,
      writable: true
    });
    return _this15;
  }
  if (reason != null) _super15(reason);else _super15('You are not allowed to make this trade');
  _this15.name = 'SwapPermissionError';
  _this15.pluginId = swapInfo.pluginId;
  _this15.reason = reason;
  return _this15;
}

/**
 * Cannot find a login with that id.
 *
 * Reasons could include:
 * - Password login: wrong username
 * - PIN login: wrong PIN key
 * - Recovery login: wrong username, or wrong recovery key
 */
function UsernameError(message = 'Invalid username') {
  if (!(this instanceof UsernameError)) throw new TypeError("Class constructor UsernameError cannot be invoked without 'new'");
  var _this16;
  function _super16(message) {
    _this16 = new Error(message);
    Object.defineProperty(_this16, "constructor", {
      value: UsernameError,
      configurable: true,
      writable: true
    });
    return _this16;
  }
  _super16(message);
  _this16.name = 'UsernameError';
  return _this16;
}
function asMaybeError(name) {
  return function asError(raw) {
    if (raw instanceof Error && raw.name === name) {
      const typeHack = raw;
      return typeHack;
    }
  };
}
const asMaybeChallengeError = asMaybeError('ChallengeError');
const asMaybeDustSpendError = asMaybeError('DustSpendError');
const asMaybeInsufficientFundsError = asMaybeError('InsufficientFundsError');
const asMaybeNetworkError = asMaybeError('NetworkError');
const asMaybeNoAmountSpecifiedError = asMaybeError('NoAmountSpecifiedError');
const asMaybeObsoleteApiError = asMaybeError('ObsoleteApiError');
const asMaybeOtpError = asMaybeError('OtpError');
const asMaybePasswordError = asMaybeError('PasswordError');
const asMaybePendingFundsError = asMaybeError('PendingFundsError');
const asMaybeSameCurrencyError = asMaybeError('SameCurrencyError');
const asMaybeSpendToSelfError = asMaybeError('SpendToSelfError');
const asMaybeSwapAboveLimitError = asMaybeError('SwapAboveLimitError');
const asMaybeSwapBelowLimitError = asMaybeError('SwapBelowLimitError');
const asMaybeSwapCurrencyError = asMaybeError('SwapCurrencyError');
const asMaybeSwapPermissionError = asMaybeError('SwapPermissionError');
const asMaybeUsernameError = asMaybeError('UsernameError');

const asEdgeRepoDump = cleaners.asObject(asEdgeBox);
const asEdgeVoucherDump = cleaners.asObject({
  // Identity:
  loginId: asBase64,
  voucherAuth: asBase64,
  voucherId: cleaners.asString,
  // Login capability:
  created: cleaners.asDate,
  activates: cleaners.asDate,
  // Automatically becomes approved on this date
  status: cleaners.asValue('pending', 'approved', 'rejected'),
  // Information about the login:
  ip: cleaners.asString,
  ipDescription: cleaners.asString,
  deviceDescription: cleaners.asOptional(cleaners.asString)
});
const asEdgeLoginDump = cleaners.asObject({
  // Identity:
  appId: cleaners.asString,
  created: cleaners.asOptional(cleaners.asDate, () => new Date()),
  loginId: asBase64,
  // Nested logins:
  children: cleaners.asOptional(cleaners.asArray(raw => asEdgeLoginDump(raw)), () => []),
  parentBox: cleaners.asOptional(asEdgeBox),
  parentId: () => undefined,
  // 2-factor login:
  otpKey: cleaners.asOptional(asBase32),
  otpResetAuth: cleaners.asOptional(cleaners.asString),
  otpResetDate: cleaners.asOptional(cleaners.asDate),
  otpTimeout: cleaners.asOptional(cleaners.asNumber),
  // Password login:
  passwordAuth: cleaners.asOptional(asBase64),
  passwordAuthBox: cleaners.asOptional(asEdgeBox),
  passwordAuthSnrp: cleaners.asOptional(asEdgeSnrp),
  passwordBox: cleaners.asOptional(asEdgeBox),
  passwordKeySnrp: cleaners.asOptional(asEdgeSnrp),
  // PIN v2 login:
  pin2Id: cleaners.asOptional(asBase64),
  pin2Auth: cleaners.asOptional(asBase64),
  pin2Box: cleaners.asOptional(asEdgeBox),
  pin2KeyBox: cleaners.asOptional(asEdgeBox),
  pin2TextBox: cleaners.asOptional(asEdgeBox),
  // Recovery v2 login:
  recovery2Id: cleaners.asOptional(asBase64),
  recovery2Auth: cleaners.asOptional(asRecovery2Auth),
  question2Box: cleaners.asOptional(asEdgeBox),
  recovery2Box: cleaners.asOptional(asEdgeBox),
  recovery2KeyBox: cleaners.asOptional(asEdgeBox),
  // Secret-key login:
  loginAuth: cleaners.asOptional(asBase64),
  loginAuthBox: cleaners.asOptional(asEdgeBox),
  // Username:
  userId: cleaners.asOptional(asBase64),
  userTextBox: cleaners.asOptional(asEdgeBox),
  // Keys and assorted goodies:
  keyBoxes: cleaners.asOptional(cleaners.asArray(asEdgeKeyBox), () => []),
  mnemonicBox: cleaners.asOptional(asEdgeBox),
  rootKeyBox: cleaners.asOptional(asEdgeBox),
  syncKeyBox: cleaners.asOptional(asEdgeBox),
  vouchers: cleaners.asOptional(cleaners.asArray(asEdgeVoucherDump), () => []),
  // Obsolete:
  pinBox: cleaners.asOptional(asEdgeBox),
  pinId: cleaners.asOptional(cleaners.asString),
  pinKeyBox: cleaners.asOptional(asEdgeBox)
});
const wasEdgeLoginDump = cleaners.uncleaner(asEdgeLoginDump);
const wasEdgeRepoDump = cleaners.uncleaner(asEdgeRepoDump);

exports.ChallengeError = ChallengeError;
exports.DustSpendError = DustSpendError;
exports.InsufficientFundsError = InsufficientFundsError;
exports.NetworkError = NetworkError;
exports.NoAmountSpecifiedError = NoAmountSpecifiedError;
exports.ObsoleteApiError = ObsoleteApiError;
exports.OtpError = OtpError;
exports.PasswordError = PasswordError;
exports.PendingFundsError = PendingFundsError;
exports.SameCurrencyError = SameCurrencyError;
exports.SpendToSelfError = SpendToSelfError;
exports.SwapAboveLimitError = SwapAboveLimitError;
exports.SwapBelowLimitError = SwapBelowLimitError;
exports.SwapCurrencyError = SwapCurrencyError;
exports.SwapPermissionError = SwapPermissionError;
exports.UsernameError = UsernameError;
exports.asBase16 = asBase16;
exports.asBase32 = asBase32;
exports.asBase64 = asBase64;
exports.asChallengeErrorPayload = asChallengeErrorPayload;
exports.asChangeOtpPayload = asChangeOtpPayload;
exports.asChangePasswordPayload = asChangePasswordPayload;
exports.asChangePin2IdPayload = asChangePin2IdPayload;
exports.asChangePin2Payload = asChangePin2Payload;
exports.asChangeRecovery2IdPayload = asChangeRecovery2IdPayload;
exports.asChangeRecovery2Payload = asChangeRecovery2Payload;
exports.asChangeSecretPayload = asChangeSecretPayload;
exports.asChangeUsernamePayload = asChangeUsernamePayload;
exports.asChangeVouchersPayload = asChangeVouchersPayload;
exports.asCreateChallengePayload = asCreateChallengePayload;
exports.asCreateKeysPayload = asCreateKeysPayload;
exports.asCreateLoginPayload = asCreateLoginPayload;
exports.asEdgeBox = asEdgeBox;
exports.asEdgeKeyBox = asEdgeKeyBox;
exports.asEdgeLobbyReply = asEdgeLobbyReply;
exports.asEdgeLobbyRequest = asEdgeLobbyRequest;
exports.asEdgeLoginDump = asEdgeLoginDump;
exports.asEdgePendingVoucher = asEdgePendingVoucher;
exports.asEdgeRepoDump = asEdgeRepoDump;
exports.asEdgeSnrp = asEdgeSnrp;
exports.asEdgeVoucherDump = asEdgeVoucherDump;
exports.asLobbyPayload = asLobbyPayload;
exports.asLoginPayload = asLoginPayload;
exports.asLoginRequestBody = asLoginRequestBody;
exports.asLoginResponseBody = asLoginResponseBody;
exports.asMaybeChallengeError = asMaybeChallengeError;
exports.asMaybeDustSpendError = asMaybeDustSpendError;
exports.asMaybeInsufficientFundsError = asMaybeInsufficientFundsError;
exports.asMaybeNetworkError = asMaybeNetworkError;
exports.asMaybeNoAmountSpecifiedError = asMaybeNoAmountSpecifiedError;
exports.asMaybeObsoleteApiError = asMaybeObsoleteApiError;
exports.asMaybeOtpError = asMaybeOtpError;
exports.asMaybePasswordError = asMaybePasswordError;
exports.asMaybePendingFundsError = asMaybePendingFundsError;
exports.asMaybeSameCurrencyError = asMaybeSameCurrencyError;
exports.asMaybeSpendToSelfError = asMaybeSpendToSelfError;
exports.asMaybeSwapAboveLimitError = asMaybeSwapAboveLimitError;
exports.asMaybeSwapBelowLimitError = asMaybeSwapBelowLimitError;
exports.asMaybeSwapCurrencyError = asMaybeSwapCurrencyError;
exports.asMaybeSwapPermissionError = asMaybeSwapPermissionError;
exports.asMaybeUsernameError = asMaybeUsernameError;
exports.asMessagesPayload = asMessagesPayload;
exports.asOtpErrorPayload = asOtpErrorPayload;
exports.asOtpResetPayload = asOtpResetPayload;
exports.asPasswordErrorPayload = asPasswordErrorPayload;
exports.asRecovery2Auth = asRecovery2Auth;
exports.asRecovery2InfoPayload = asRecovery2InfoPayload;
exports.asUsernameInfoPayload = asUsernameInfoPayload;
exports.wasChallengeErrorPayload = wasChallengeErrorPayload;
exports.wasChangeOtpPayload = wasChangeOtpPayload;
exports.wasChangePasswordPayload = wasChangePasswordPayload;
exports.wasChangePin2IdPayload = wasChangePin2IdPayload;
exports.wasChangePin2Payload = wasChangePin2Payload;
exports.wasChangeRecovery2IdPayload = wasChangeRecovery2IdPayload;
exports.wasChangeRecovery2Payload = wasChangeRecovery2Payload;
exports.wasChangeSecretPayload = wasChangeSecretPayload;
exports.wasChangeUsernamePayload = wasChangeUsernamePayload;
exports.wasChangeVouchersPayload = wasChangeVouchersPayload;
exports.wasCreateChallengePayload = wasCreateChallengePayload;
exports.wasCreateKeysPayload = wasCreateKeysPayload;
exports.wasCreateLoginPayload = wasCreateLoginPayload;
exports.wasEdgeBox = wasEdgeBox;
exports.wasEdgeLobbyReply = wasEdgeLobbyReply;
exports.wasEdgeLobbyRequest = wasEdgeLobbyRequest;
exports.wasEdgeLoginDump = wasEdgeLoginDump;
exports.wasEdgeRepoDump = wasEdgeRepoDump;
exports.wasLobbyPayload = wasLobbyPayload;
exports.wasLoginPayload = wasLoginPayload;
exports.wasLoginRequestBody = wasLoginRequestBody;
exports.wasLoginResponseBody = wasLoginResponseBody;
exports.wasMessagesPayload = wasMessagesPayload;
exports.wasOtpErrorPayload = wasOtpErrorPayload;
exports.wasOtpResetPayload = wasOtpResetPayload;
exports.wasPasswordErrorPayload = wasPasswordErrorPayload;
exports.wasRecovery2InfoPayload = wasRecovery2InfoPayload;
exports.wasUsernameInfoPayload = wasUsernameInfoPayload;


/***/ }),

/***/ "./node_modules/ieee754/index.js":
/*!***************************************!*\
  !*** ./node_modules/ieee754/index.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, exports) => {

exports.read = function (buffer, offset, isLE, mLen, nBytes) {
  var e, m
  var eLen = (nBytes * 8) - mLen - 1
  var eMax = (1 << eLen) - 1
  var eBias = eMax >> 1
  var nBits = -7
  var i = isLE ? (nBytes - 1) : 0
  var d = isLE ? -1 : 1
  var s = buffer[offset + i]

  i += d

  e = s & ((1 << (-nBits)) - 1)
  s >>= (-nBits)
  nBits += eLen
  for (; nBits > 0; e = (e * 256) + buffer[offset + i], i += d, nBits -= 8) {}

  m = e & ((1 << (-nBits)) - 1)
  e >>= (-nBits)
  nBits += mLen
  for (; nBits > 0; m = (m * 256) + buffer[offset + i], i += d, nBits -= 8) {}

  if (e === 0) {
    e = 1 - eBias
  } else if (e === eMax) {
    return m ? NaN : ((s ? -1 : 1) * Infinity)
  } else {
    m = m + Math.pow(2, mLen)
    e = e - eBias
  }
  return (s ? -1 : 1) * m * Math.pow(2, e - mLen)
}

exports.write = function (buffer, value, offset, isLE, mLen, nBytes) {
  var e, m, c
  var eLen = (nBytes * 8) - mLen - 1
  var eMax = (1 << eLen) - 1
  var eBias = eMax >> 1
  var rt = (mLen === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0)
  var i = isLE ? 0 : (nBytes - 1)
  var d = isLE ? 1 : -1
  var s = value < 0 || (value === 0 && 1 / value < 0) ? 1 : 0

  value = Math.abs(value)

  if (isNaN(value) || value === Infinity) {
    m = isNaN(value) ? 1 : 0
    e = eMax
  } else {
    e = Math.floor(Math.log(value) / Math.LN2)
    if (value * (c = Math.pow(2, -e)) < 1) {
      e--
      c *= 2
    }
    if (e + eBias >= 1) {
      value += rt / c
    } else {
      value += rt * Math.pow(2, 1 - eBias)
    }
    if (value * c >= 2) {
      e++
      c /= 2
    }

    if (e + eBias >= eMax) {
      m = 0
      e = eMax
    } else if (e + eBias >= 1) {
      m = ((value * c) - 1) * Math.pow(2, mLen)
      e = e + eBias
    } else {
      m = value * Math.pow(2, eBias - 1) * Math.pow(2, mLen)
      e = 0
    }
  }

  for (; mLen >= 8; buffer[offset + i] = m & 0xff, i += d, m /= 256, mLen -= 8) {}

  e = (e << mLen) | m
  eLen += mLen
  for (; eLen > 0; buffer[offset + i] = e & 0xff, i += d, e /= 256, eLen -= 8) {}

  buffer[offset + i - d] |= s * 128
}


/***/ }),

/***/ "./node_modules/punycode/punycode.es6.js":
/*!***********************************************!*\
  !*** ./node_modules/punycode/punycode.es6.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   decode: () => (/* binding */ decode),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   encode: () => (/* binding */ encode),
/* harmony export */   toASCII: () => (/* binding */ toASCII),
/* harmony export */   toUnicode: () => (/* binding */ toUnicode),
/* harmony export */   ucs2decode: () => (/* binding */ ucs2decode),
/* harmony export */   ucs2encode: () => (/* binding */ ucs2encode)
/* harmony export */ });


/** Highest positive signed 32-bit float value */
const maxInt = 2147483647; // aka. 0x7FFFFFFF or 2^31-1

/** Bootstring parameters */
const base = 36;
const tMin = 1;
const tMax = 26;
const skew = 38;
const damp = 700;
const initialBias = 72;
const initialN = 128; // 0x80
const delimiter = '-'; // '\x2D'

/** Regular expressions */
const regexPunycode = /^xn--/;
const regexNonASCII = /[^\0-\x7E]/; // non-ASCII chars
const regexSeparators = /[\x2E\u3002\uFF0E\uFF61]/g; // RFC 3490 separators

/** Error messages */
const errors = {
	'overflow': 'Overflow: input needs wider integers to process',
	'not-basic': 'Illegal input >= 0x80 (not a basic code point)',
	'invalid-input': 'Invalid input'
};

/** Convenience shortcuts */
const baseMinusTMin = base - tMin;
const floor = Math.floor;
const stringFromCharCode = String.fromCharCode;

/*--------------------------------------------------------------------------*/

/**
 * A generic error utility function.
 * @private
 * @param {String} type The error type.
 * @returns {Error} Throws a `RangeError` with the applicable error message.
 */
function error(type) {
	throw new RangeError(errors[type]);
}

/**
 * A generic `Array#map` utility function.
 * @private
 * @param {Array} array The array to iterate over.
 * @param {Function} callback The function that gets called for every array
 * item.
 * @returns {Array} A new array of values returned by the callback function.
 */
function map(array, fn) {
	const result = [];
	let length = array.length;
	while (length--) {
		result[length] = fn(array[length]);
	}
	return result;
}

/**
 * A simple `Array#map`-like wrapper to work with domain name strings or email
 * addresses.
 * @private
 * @param {String} domain The domain name or email address.
 * @param {Function} callback The function that gets called for every
 * character.
 * @returns {Array} A new string of characters returned by the callback
 * function.
 */
function mapDomain(string, fn) {
	const parts = string.split('@');
	let result = '';
	if (parts.length > 1) {
		// In email addresses, only the domain name should be punycoded. Leave
		// the local part (i.e. everything up to `@`) intact.
		result = parts[0] + '@';
		string = parts[1];
	}
	// Avoid `split(regex)` for IE8 compatibility. See #17.
	string = string.replace(regexSeparators, '\x2E');
	const labels = string.split('.');
	const encoded = map(labels, fn).join('.');
	return result + encoded;
}

/**
 * Creates an array containing the numeric code points of each Unicode
 * character in the string. While JavaScript uses UCS-2 internally,
 * this function will convert a pair of surrogate halves (each of which
 * UCS-2 exposes as separate characters) into a single code point,
 * matching UTF-16.
 * @see `punycode.ucs2.encode`
 * @see <https://mathiasbynens.be/notes/javascript-encoding>
 * @memberOf punycode.ucs2
 * @name decode
 * @param {String} string The Unicode input string (UCS-2).
 * @returns {Array} The new array of code points.
 */
function ucs2decode(string) {
	const output = [];
	let counter = 0;
	const length = string.length;
	while (counter < length) {
		const value = string.charCodeAt(counter++);
		if (value >= 0xD800 && value <= 0xDBFF && counter < length) {
			// It's a high surrogate, and there is a next character.
			const extra = string.charCodeAt(counter++);
			if ((extra & 0xFC00) == 0xDC00) { // Low surrogate.
				output.push(((value & 0x3FF) << 10) + (extra & 0x3FF) + 0x10000);
			} else {
				// It's an unmatched surrogate; only append this code unit, in case the
				// next code unit is the high surrogate of a surrogate pair.
				output.push(value);
				counter--;
			}
		} else {
			output.push(value);
		}
	}
	return output;
}

/**
 * Creates a string based on an array of numeric code points.
 * @see `punycode.ucs2.decode`
 * @memberOf punycode.ucs2
 * @name encode
 * @param {Array} codePoints The array of numeric code points.
 * @returns {String} The new Unicode string (UCS-2).
 */
const ucs2encode = array => String.fromCodePoint(...array);

/**
 * Converts a basic code point into a digit/integer.
 * @see `digitToBasic()`
 * @private
 * @param {Number} codePoint The basic numeric code point value.
 * @returns {Number} The numeric value of a basic code point (for use in
 * representing integers) in the range `0` to `base - 1`, or `base` if
 * the code point does not represent a value.
 */
const basicToDigit = function(codePoint) {
	if (codePoint - 0x30 < 0x0A) {
		return codePoint - 0x16;
	}
	if (codePoint - 0x41 < 0x1A) {
		return codePoint - 0x41;
	}
	if (codePoint - 0x61 < 0x1A) {
		return codePoint - 0x61;
	}
	return base;
};

/**
 * Converts a digit/integer into a basic code point.
 * @see `basicToDigit()`
 * @private
 * @param {Number} digit The numeric value of a basic code point.
 * @returns {Number} The basic code point whose value (when used for
 * representing integers) is `digit`, which needs to be in the range
 * `0` to `base - 1`. If `flag` is non-zero, the uppercase form is
 * used; else, the lowercase form is used. The behavior is undefined
 * if `flag` is non-zero and `digit` has no uppercase form.
 */
const digitToBasic = function(digit, flag) {
	//  0..25 map to ASCII a..z or A..Z
	// 26..35 map to ASCII 0..9
	return digit + 22 + 75 * (digit < 26) - ((flag != 0) << 5);
};

/**
 * Bias adaptation function as per section 3.4 of RFC 3492.
 * https://tools.ietf.org/html/rfc3492#section-3.4
 * @private
 */
const adapt = function(delta, numPoints, firstTime) {
	let k = 0;
	delta = firstTime ? floor(delta / damp) : delta >> 1;
	delta += floor(delta / numPoints);
	for (/* no initialization */; delta > baseMinusTMin * tMax >> 1; k += base) {
		delta = floor(delta / baseMinusTMin);
	}
	return floor(k + (baseMinusTMin + 1) * delta / (delta + skew));
};

/**
 * Converts a Punycode string of ASCII-only symbols to a string of Unicode
 * symbols.
 * @memberOf punycode
 * @param {String} input The Punycode string of ASCII-only symbols.
 * @returns {String} The resulting string of Unicode symbols.
 */
const decode = function(input) {
	// Don't use UCS-2.
	const output = [];
	const inputLength = input.length;
	let i = 0;
	let n = initialN;
	let bias = initialBias;

	// Handle the basic code points: let `basic` be the number of input code
	// points before the last delimiter, or `0` if there is none, then copy
	// the first basic code points to the output.

	let basic = input.lastIndexOf(delimiter);
	if (basic < 0) {
		basic = 0;
	}

	for (let j = 0; j < basic; ++j) {
		// if it's not a basic code point
		if (input.charCodeAt(j) >= 0x80) {
			error('not-basic');
		}
		output.push(input.charCodeAt(j));
	}

	// Main decoding loop: start just after the last delimiter if any basic code
	// points were copied; start at the beginning otherwise.

	for (let index = basic > 0 ? basic + 1 : 0; index < inputLength; /* no final expression */) {

		// `index` is the index of the next character to be consumed.
		// Decode a generalized variable-length integer into `delta`,
		// which gets added to `i`. The overflow checking is easier
		// if we increase `i` as we go, then subtract off its starting
		// value at the end to obtain `delta`.
		let oldi = i;
		for (let w = 1, k = base; /* no condition */; k += base) {

			if (index >= inputLength) {
				error('invalid-input');
			}

			const digit = basicToDigit(input.charCodeAt(index++));

			if (digit >= base || digit > floor((maxInt - i) / w)) {
				error('overflow');
			}

			i += digit * w;
			const t = k <= bias ? tMin : (k >= bias + tMax ? tMax : k - bias);

			if (digit < t) {
				break;
			}

			const baseMinusT = base - t;
			if (w > floor(maxInt / baseMinusT)) {
				error('overflow');
			}

			w *= baseMinusT;

		}

		const out = output.length + 1;
		bias = adapt(i - oldi, out, oldi == 0);

		// `i` was supposed to wrap around from `out` to `0`,
		// incrementing `n` each time, so we'll fix that now:
		if (floor(i / out) > maxInt - n) {
			error('overflow');
		}

		n += floor(i / out);
		i %= out;

		// Insert `n` at position `i` of the output.
		output.splice(i++, 0, n);

	}

	return String.fromCodePoint(...output);
};

/**
 * Converts a string of Unicode symbols (e.g. a domain name label) to a
 * Punycode string of ASCII-only symbols.
 * @memberOf punycode
 * @param {String} input The string of Unicode symbols.
 * @returns {String} The resulting Punycode string of ASCII-only symbols.
 */
const encode = function(input) {
	const output = [];

	// Convert the input in UCS-2 to an array of Unicode code points.
	input = ucs2decode(input);

	// Cache the length.
	let inputLength = input.length;

	// Initialize the state.
	let n = initialN;
	let delta = 0;
	let bias = initialBias;

	// Handle the basic code points.
	for (const currentValue of input) {
		if (currentValue < 0x80) {
			output.push(stringFromCharCode(currentValue));
		}
	}

	let basicLength = output.length;
	let handledCPCount = basicLength;

	// `handledCPCount` is the number of code points that have been handled;
	// `basicLength` is the number of basic code points.

	// Finish the basic string with a delimiter unless it's empty.
	if (basicLength) {
		output.push(delimiter);
	}

	// Main encoding loop:
	while (handledCPCount < inputLength) {

		// All non-basic code points < n have been handled already. Find the next
		// larger one:
		let m = maxInt;
		for (const currentValue of input) {
			if (currentValue >= n && currentValue < m) {
				m = currentValue;
			}
		}

		// Increase `delta` enough to advance the decoder's <n,i> state to <m,0>,
		// but guard against overflow.
		const handledCPCountPlusOne = handledCPCount + 1;
		if (m - n > floor((maxInt - delta) / handledCPCountPlusOne)) {
			error('overflow');
		}

		delta += (m - n) * handledCPCountPlusOne;
		n = m;

		for (const currentValue of input) {
			if (currentValue < n && ++delta > maxInt) {
				error('overflow');
			}
			if (currentValue == n) {
				// Represent delta as a generalized variable-length integer.
				let q = delta;
				for (let k = base; /* no condition */; k += base) {
					const t = k <= bias ? tMin : (k >= bias + tMax ? tMax : k - bias);
					if (q < t) {
						break;
					}
					const qMinusT = q - t;
					const baseMinusT = base - t;
					output.push(
						stringFromCharCode(digitToBasic(t + qMinusT % baseMinusT, 0))
					);
					q = floor(qMinusT / baseMinusT);
				}

				output.push(stringFromCharCode(digitToBasic(q, 0)));
				bias = adapt(delta, handledCPCountPlusOne, handledCPCount == basicLength);
				delta = 0;
				++handledCPCount;
			}
		}

		++delta;
		++n;

	}
	return output.join('');
};

/**
 * Converts a Punycode string representing a domain name or an email address
 * to Unicode. Only the Punycoded parts of the input will be converted, i.e.
 * it doesn't matter if you call it on a string that has already been
 * converted to Unicode.
 * @memberOf punycode
 * @param {String} input The Punycoded domain name or email address to
 * convert to Unicode.
 * @returns {String} The Unicode representation of the given Punycode
 * string.
 */
const toUnicode = function(input) {
	return mapDomain(input, function(string) {
		return regexPunycode.test(string)
			? decode(string.slice(4).toLowerCase())
			: string;
	});
};

/**
 * Converts a Unicode string representing a domain name or an email address to
 * Punycode. Only the non-ASCII parts of the domain name will be converted,
 * i.e. it doesn't matter if you call it with a domain that's already in
 * ASCII.
 * @memberOf punycode
 * @param {String} input The domain name or email address to convert, as a
 * Unicode string.
 * @returns {String} The Punycode representation of the given domain name or
 * email address.
 */
const toASCII = function(input) {
	return mapDomain(input, function(string) {
		return regexNonASCII.test(string)
			? 'xn--' + encode(string)
			: string;
	});
};

/*--------------------------------------------------------------------------*/

/** Define the public API */
const punycode = {
	/**
	 * A string representing the current Punycode.js version number.
	 * @memberOf punycode
	 * @type String
	 */
	'version': '2.1.0',
	/**
	 * An object of methods to convert from JavaScript's internal character
	 * representation (UCS-2) to Unicode code points, and back.
	 * @see <https://mathiasbynens.be/notes/javascript-encoding>
	 * @memberOf punycode
	 * @type Object
	 */
	'ucs2': {
		'decode': ucs2decode,
		'encode': ucs2encode
	},
	'decode': decode,
	'encode': encode,
	'toASCII': toASCII,
	'toUnicode': toUnicode
};


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (punycode);


/***/ }),

/***/ "./node_modules/react-native-mymonero-core/src/CppBridge.js":
/*!******************************************************************!*\
  !*** ./node_modules/react-native-mymonero-core/src/CppBridge.js ***!
  \******************************************************************/
/***/ ((module) => {

"use strict";
// This has been taken from @mymonero/mymonero-monero-client v2.0.0
// Changes include:
// - Rename the class from `WABridge` to `CppBridge`
// - Make all methods `async`
// - Remove a try-catch block
// - Change the shouldSweep `send_amount` check from number 0 to string '0'
// - Add a mutex around `createTransaction`
// - Assemble the `this.Module` property in the constructor



let lastSpend = Promise.resolve()

class CppBridge {
  constructor (MyMoneroCore) {
    // Put the methods back together:
    this.Module = {}
    for (const name of MyMoneroCore.methodNames) {
      this.Module[name] = function (...args) {
        return MyMoneroCore.callMyMonero(name, args).then(out => {
          // We have to cast some return values:
          return name === 'compareMnemonics' ||
            name === 'isIntegratedAddress' ||
            name === 'isSubaddress'
            ? Boolean(out)
            : out
        })
      }
    }

    // Only allow one createTransaction call at a time:
    const oldCreateTransaction = this.createTransaction.bind(this)
    this.createTransaction = function (opts) {
      const out = lastSpend.then(
        () => oldCreateTransaction(opts),
        () => oldCreateTransaction(opts)
      )
      lastSpend = out
      return out
    }
  }

  /**
 * Callback to fetch the random decoys from the light wallet service needed for the transaction.
 *
 * @callback randomOutsCallback
 * @param {number} numberOfOuts - The number of outputs needing decoys.
 */

  /**
   * Creates a transfer of funds to the recipient address and returns the raw signed tx.
   * @param {object} options
   * @param {number} options.amount
   * @param {string} options.recipientAddress
   * @param {number} options.priority
   * @param {string} options.address
   * @param {string} options.privateViewKey
   * @param {string} options.publicSpendKey
   * @param {string} options.privateSpendKey
   * @param {boolean} options.shouldSweep
   * @param {?string} options.paymentId - The payment id for the transaction. can be null.
   * @param {string} options.nettype - The network name eg MAINNET.
   * @param {object} options.unspentOuts - List of unspent outs as well as per byte fee.
   * @param {randomOutsCallback} options.randomOutsCb - Used to fetch the random outs from the light wallet service.
   * @returns
   */
  async createTransaction (options) {
    const self = this
    checkPriority(options.priority)
    checkNetType(options.nettype)
    if (options.privateViewKey.length !== 64) {
      throw Error('Invalid privateViewKey length')
    }
    if (options.publicSpendKey.length !== 64) {
      throw Error('Invalid publicSpendKey length')
    }
    if (options.privateSpendKey.length !== 64) {
      throw Error('Invalid privateSpendKey length')
    }
    if (typeof options.randomOutsCb !== 'function') {
      throw Error('Invalid randomsOutCB not a function')
    }
    if (!Array.isArray(options.destinations)) {
      throw Error('Invalid destinations')
    }
    options.destinations.forEach(function (destination) {
      if (!destination.hasOwnProperty('to_address') || !destination.hasOwnProperty('send_amount')) {
        throw Error('Invalid destinations missing values')
      }
    })
    if (options.shouldSweep) {
      if (options.destinations.length !== 1) {
        throw Error('Invalid number of destinations must be 1')
      }
      if (options.destinations[0].send_amount !== '0') {
        throw Error('Invalid amount when sweeping amount must be 0')
      }
    }

    // check if destinations is set correctly
    const args =
    {
      destinations: options.destinations,
      is_sweeping: options.shouldSweep,
      from_address_string: options.address,
      sec_viewKey_string: options.privateViewKey,
      sec_spendKey_string: options.privateSpendKey,
      pub_spendKey_string: options.publicSpendKey,
      priority: '' + options.priority,
      nettype_string: options.nettype,
      manuallyEnteredPaymentID: options.paymentId,
      unspentOuts: options.unspentOuts
    }

      // WebAssembly keeps state between calls so we can prepare the tx before getting the random out and signing tx
      const retString = await this.Module.prepareTx(JSON.stringify(args, null, ''))
      const ret = JSON.parse(retString)
      // check for any errors passed back from WebAssembly
      if (ret.err_msg) {
        throw Error(ret.err_msg)
      }
      // fetch random decoys
      const randomOuts = await self._getRandomOuts(ret.amounts.length, options.randomOutsCb)
      // send random decoys on and complete the tx creation
      const retString2 = await this.Module.createAndSignTx(JSON.stringify(randomOuts))
      const rawTx = JSON.parse(retString2)
      // check for any errors passed back from WebAssembly
      if (rawTx.err_msg) {
        throw Error(rawTx.err_msg)
      }
      // parse variables ruturned as strings
      rawTx.mixin = parseInt(rawTx.mixin)
      rawTx.isXMRAddressIntegrated = rawTx.isXMRAddressIntegrated === 'true'

      return rawTx
  }

  /**
   * Generates a random short payment id.
   * @returns {string} new 16 char short Payment id.
   */
  async generatePaymentId () {
    return await this.Module.generatePaymentId()
  }

  /**
   * Connects to the WASM to generate the Key Image of the specific output.
   * @param {string} txPublicKey - The output public key.
   * @param {string} privateViewKey - The wallet private view key.
   * @param {string} publicSpendKey - The spend public key.
   * @param {string} privateSpendKey - The spend secret key.
   * @param {number} outputIndex - The output index within the transaction.
   * @returns {string} Returns the key image.
   */
  async generateKeyImage (txPublicKey, privateViewKey, publicSpendKey, privateSpendKey, outputIndex) {
    if (txPublicKey.length !== 64) {
      throw Error('Invalid txPublicKey length')
    }
    if (privateViewKey.length !== 64) {
      throw Error('Invalid privateViewKey length')
    }
    if (publicSpendKey.length !== 64) {
      throw Error('Invalid publicSpendKey length')
    }
    if (privateSpendKey.length !== 64) {
      throw Error('Invalid privateSpendKey length')
    }
    if (outputIndex === '' || outputIndex == null) {
      throw Error('Missing outputIndex')
    }
    if (isNaN(outputIndex)) {
      throw Error('Invalid outputIndex is not a number')
    }

    const retString = await this.Module.generateKeyImage(txPublicKey, privateViewKey, publicSpendKey, privateSpendKey, '' + outputIndex)
    const ret = JSON.parse(retString)
    if (ret.err_msg) {
      throw Error(ret.err_msg)
    }

    return ret.retVal
  }

  /**
   * Estimates the transaction fee based on two outputs.
   * @param {number} priority - The priority level the estimate is for.
   * @param {number} feePerb - The fee per byte. This is retrieved from the MM server.
   * @param {number} forkVersion - The fork version defaults to 0 which is the latest.
   * @returns {number} The estiamted fee amount in piconeros
   */
  async estimateTxFee (priority, feePerb, forkVersion = 0) {
    checkPriority(priority)
    if (isNaN(feePerb)) {
      throw Error('Invalid feePerb. must be an number')
    }
    const retString = await this.Module.estimateTxFee('' + priority, '' + feePerb, '' + forkVersion)
    const ret = JSON.parse(retString)

    return parseInt(ret.retVal)
  }

  /**
   * Derives the seed and keys from the mnemonic string.
   * @param {string} mnemonic - The string of mnemonic words.
   * @param {string} nettype - The network name eg MAINNET.
   * @returns {array} List of public and private keys.
   */
  async seedAndKeysFromMnemonic (mnemonic, nettype) {
    checkNetType(nettype)
    if (typeof mnemonic !== 'string') {
      throw Error('Invalid mnemonic')
    }
    mnemonic = mnemonic.replace(/\s+/g, ' ').trim()
    const wordArray = mnemonic.split(' ')

    if (wordArray.length !== 13 && wordArray.length !== 25) {
      throw Error('Invalid number of words. must be 13 or 25-word mnemonic')
    }
    const retString = await this.Module.seedAndKeysFromMnemonic(mnemonic, nettype)
    const ret = JSON.parse(retString)
    if (ret.err_msg) {
      throw Error(ret.err_msg)
    }

    return ret
  }

  /**
   * Validates the provided information for logging into the wallet.
   * @param {string} address - The primary address.
   * @param {string} privateViewKey - The wallet private view key.
   * @param {string} privateSpendKey - The wallet private spend key.
   * @param {string} seed - The seed as optional.
   * @param {string} nettype - The network name eg MAINNET.
   * @returns {array} Returns if its valid, view only and the public view and spend keys.
   */
  async isValidKeys (address, privateViewKey, privateSpendKey, seed, nettype) {
    checkNetType(nettype)
    const retString = await this.Module.isValidKeys(address, privateViewKey, privateSpendKey, seed, nettype)
    const ret = JSON.parse(retString)
    if (ret.err_msg) {
      throw Error(ret.err_msg)
    }

    return { // calling these out so as to provide a stable ret val interface
      isValid: ret.isValid === 'true',
      isViewOnly: ret.isViewOnly === 'true',
      publicViewKey: ret.publicViewKey,
      publicSpendKey: ret.publicSpendKey
    }
  }

  /**
   * Decodes address to provide spend and view keys.
   * @param {string} address - The primary address to decode.
   * @param {string} nettype - The network name eg MAINNET.
   * @returns {array} Break down of the address.
   */
  async decodeAddress (address, nettype) {
    checkNetType(nettype)
    const retString = await this.Module.decodeAddress(address, nettype)
    const ret = JSON.parse(retString)
    if (ret.err_msg) {
      throw Error(ret.err_msg)
    }

    return {
      publicSpendKey: ret.publicSpendKey,
      publicViewKey: ret.publicViewKey,
      paymentId: ret.paymentId, // may be undefined
      isSubaddress: ret.isSubaddress === 'true'
    }
  }

  /**
   * Creates a new wallet based on the locale.
   * @param {string} localeLanguageCode The locale  based on language and Country. eg. en-US.
   * @param {string} nettype - The network name eg MAINNET.
   * @returns {array} mnemonic details as well as the public and private keys.
   */
  async generateWallet (localeLanguageCode, nettype) {
    checkNetType(nettype)
    const retString = await this.Module.generateWallet(localeLanguageCode, nettype)
    const ret = JSON.parse(retString)
    if (ret.err_msg) {
      throw Error(ret.err_msg)
    }
    return ret
  }

  /**
   * Compares two mnemonics.
   * @param {string} a - First mnemonic.
   * @param {string} b - Second mnemonic.
   * @returns {boolean} True if they match.
   */
  async compareMnemonics (a, b) {
    return await this.Module.compareMnemonics(a, b)
  }

  /**
   * Derives the mnemonic from the seed.
   * @param {string} seed - Seed that the mnemonic will be derived from.
   * @param {string} wordsetName - The language wordlist name.
   * @returns {string} The mnemonic seed phrase.
   */
  async mnemonicFromSeed (seed, wordsetName) {
    const retString = await this.Module.mnemonicFromSeed(seed, apiSafeWordsetName(wordsetName))
    const ret = JSON.parse(retString)
    if (ret.err_msg) {
      throw Error(ret.err_msg)
    }

    return ret.retVal
  }

  /**
   * (Deprecated) Returns a list of public amd private keys derived from the seed.
   * @param {string} seed - The seed string. not to be confused with the mnemonic seed.
   * @param {string} nettype - The network name eg MAINNET.
   * @returns {array} A breakdown of the public and private keys.
   */
  async addressAndKeysFromSeed (seed, nettype) {
    checkNetType(nettype)
    const retString = await this.Module.addressAndKeysFromSeed(seed, nettype)
    const ret = JSON.parse(retString)
    if (ret.err_msg) {
      throw Error(ret.err_msg)
    }

    return ret
  }

  /**
   * (Deprecated) Checks if address is a subaddress.
   * @param {string} address - The address to check.
   * @param {string} nettype - The network type name eg MAINNET.
   * @returns {boolean} True if address is a subaddress.
   */
  async isSubaddress (address, nettype) {
    checkNetType(nettype)
    return await this.Module.isSubaddress(address, nettype)
  }

  /**
   * (Deprecated) Checks if address is a integrated address.
   * @param {string} address - The address to check.
   * @param {string} nettype - The network type name eg MAINNET.
   * @returns {boolean} True if address is a integrated address.
   */
  async isIntegratedAddress (address, nettype) {
    checkNetType(nettype)
    return await this.Module.isIntegratedAddress(address, nettype)
  }

  /**
   * (Deprecated) Generates a integraded address using the address and short payment id provided.
   * @param {string} address - Address you would like to integrate with the payment id.
   * @param {string} paymentId - 16 char short payment id.
   * @param {string} nettype - The network name eg MAINNET.
   * @returns {string} The new integrated addresss.
   */
  async newIntegratedAddress (address, paymentId, nettype) {
    checkNetType(nettype)
    if (!paymentId || paymentId.length !== 16) {
      throw Error('expected valid paymentId')
    }
    const ret = await this.Module.newIntegratedAddress(address, paymentId, nettype)

    return ret
  }

  /**
   *  Calls the randomOutsCb function provided and validates the response.
   * @private
   * @param {number} numberOfOuts - number of random outs needed.
   * @param {randomOutsCallback} randomOutsCb - The callback function to fetch random outs.
   * @returns {object} An object with a property amount_outs array.
   */
  async _getRandomOuts (numberOfOuts, randomOutsCb) {
    const randomOuts = await randomOutsCb(numberOfOuts)

    if (typeof randomOuts.amount_outs === 'undefined' || !Array.isArray(randomOuts.amount_outs)) {
      throw Error('Invalid amount_outs in randomOutsCb response')
    }

    return randomOuts
  }
}

module.exports = CppBridge

function checkNetType (netType) {
  switch (netType) {
    case 'MAINNET':
    case 'STAGENET':
    case 'TESTNET':
    case 'FAKECHAIN':
      break
    default:
      throw Error('Invalid nettype')
  }
}

function checkPriority (priority) {
  switch (priority) {
    case 1:
    case 2:
    case 3:
    case 4:
      break
    default:
      throw Error('Invalid priority. must be between 1 to 4')
  }
}

function apiSafeWordsetName (wordsetName) {
  // convert all lowercase, legacy values to core-cpp compatible
  if (wordsetName === 'english') {
    return 'English'
  } else if (wordsetName === 'spanish') {
    return 'Español'
  } else if (wordsetName === 'portuguese') {
    return 'Português'
  } else if (wordsetName === 'japanese') {
    return '日本語'
  }
  return wordsetName // must be a value returned by core-cpp
}


/***/ }),

/***/ "./node_modules/regenerator-runtime/runtime.js":
/*!*****************************************************!*\
  !*** ./node_modules/regenerator-runtime/runtime.js ***!
  \*****************************************************/
/***/ ((module) => {

/**
 * Copyright (c) 2014-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

var runtime = (function (exports) {
  "use strict";

  var Op = Object.prototype;
  var hasOwn = Op.hasOwnProperty;
  var defineProperty = Object.defineProperty || function (obj, key, desc) { obj[key] = desc.value; };
  var undefined; // More compressible than void 0.
  var $Symbol = typeof Symbol === "function" ? Symbol : {};
  var iteratorSymbol = $Symbol.iterator || "@@iterator";
  var asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator";
  var toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";

  function define(obj, key, value) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
    return obj[key];
  }
  try {
    // IE 8 has a broken Object.defineProperty that only works on DOM objects.
    define({}, "");
  } catch (err) {
    define = function(obj, key, value) {
      return obj[key] = value;
    };
  }

  function wrap(innerFn, outerFn, self, tryLocsList) {
    // If outerFn provided and outerFn.prototype is a Generator, then outerFn.prototype instanceof Generator.
    var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator;
    var generator = Object.create(protoGenerator.prototype);
    var context = new Context(tryLocsList || []);

    // The ._invoke method unifies the implementations of the .next,
    // .throw, and .return methods.
    defineProperty(generator, "_invoke", { value: makeInvokeMethod(innerFn, self, context) });

    return generator;
  }
  exports.wrap = wrap;

  // Try/catch helper to minimize deoptimizations. Returns a completion
  // record like context.tryEntries[i].completion. This interface could
  // have been (and was previously) designed to take a closure to be
  // invoked without arguments, but in all the cases we care about we
  // already have an existing method we want to call, so there's no need
  // to create a new function object. We can even get away with assuming
  // the method takes exactly one argument, since that happens to be true
  // in every case, so we don't have to touch the arguments object. The
  // only additional allocation required is the completion record, which
  // has a stable shape and so hopefully should be cheap to allocate.
  function tryCatch(fn, obj, arg) {
    try {
      return { type: "normal", arg: fn.call(obj, arg) };
    } catch (err) {
      return { type: "throw", arg: err };
    }
  }

  var GenStateSuspendedStart = "suspendedStart";
  var GenStateSuspendedYield = "suspendedYield";
  var GenStateExecuting = "executing";
  var GenStateCompleted = "completed";

  // Returning this object from the innerFn has the same effect as
  // breaking out of the dispatch switch statement.
  var ContinueSentinel = {};

  // Dummy constructor functions that we use as the .constructor and
  // .constructor.prototype properties for functions that return Generator
  // objects. For full spec compliance, you may wish to configure your
  // minifier not to mangle the names of these two functions.
  function Generator() {}
  function GeneratorFunction() {}
  function GeneratorFunctionPrototype() {}

  // This is a polyfill for %IteratorPrototype% for environments that
  // don't natively support it.
  var IteratorPrototype = {};
  define(IteratorPrototype, iteratorSymbol, function () {
    return this;
  });

  var getProto = Object.getPrototypeOf;
  var NativeIteratorPrototype = getProto && getProto(getProto(values([])));
  if (NativeIteratorPrototype &&
      NativeIteratorPrototype !== Op &&
      hasOwn.call(NativeIteratorPrototype, iteratorSymbol)) {
    // This environment has a native %IteratorPrototype%; use it instead
    // of the polyfill.
    IteratorPrototype = NativeIteratorPrototype;
  }

  var Gp = GeneratorFunctionPrototype.prototype =
    Generator.prototype = Object.create(IteratorPrototype);
  GeneratorFunction.prototype = GeneratorFunctionPrototype;
  defineProperty(Gp, "constructor", { value: GeneratorFunctionPrototype, configurable: true });
  defineProperty(
    GeneratorFunctionPrototype,
    "constructor",
    { value: GeneratorFunction, configurable: true }
  );
  GeneratorFunction.displayName = define(
    GeneratorFunctionPrototype,
    toStringTagSymbol,
    "GeneratorFunction"
  );

  // Helper for defining the .next, .throw, and .return methods of the
  // Iterator interface in terms of a single ._invoke method.
  function defineIteratorMethods(prototype) {
    ["next", "throw", "return"].forEach(function(method) {
      define(prototype, method, function(arg) {
        return this._invoke(method, arg);
      });
    });
  }

  exports.isGeneratorFunction = function(genFun) {
    var ctor = typeof genFun === "function" && genFun.constructor;
    return ctor
      ? ctor === GeneratorFunction ||
        // For the native GeneratorFunction constructor, the best we can
        // do is to check its .name property.
        (ctor.displayName || ctor.name) === "GeneratorFunction"
      : false;
  };

  exports.mark = function(genFun) {
    if (Object.setPrototypeOf) {
      Object.setPrototypeOf(genFun, GeneratorFunctionPrototype);
    } else {
      genFun.__proto__ = GeneratorFunctionPrototype;
      define(genFun, toStringTagSymbol, "GeneratorFunction");
    }
    genFun.prototype = Object.create(Gp);
    return genFun;
  };

  // Within the body of any async function, `await x` is transformed to
  // `yield regeneratorRuntime.awrap(x)`, so that the runtime can test
  // `hasOwn.call(value, "__await")` to determine if the yielded value is
  // meant to be awaited.
  exports.awrap = function(arg) {
    return { __await: arg };
  };

  function AsyncIterator(generator, PromiseImpl) {
    function invoke(method, arg, resolve, reject) {
      var record = tryCatch(generator[method], generator, arg);
      if (record.type === "throw") {
        reject(record.arg);
      } else {
        var result = record.arg;
        var value = result.value;
        if (value &&
            typeof value === "object" &&
            hasOwn.call(value, "__await")) {
          return PromiseImpl.resolve(value.__await).then(function(value) {
            invoke("next", value, resolve, reject);
          }, function(err) {
            invoke("throw", err, resolve, reject);
          });
        }

        return PromiseImpl.resolve(value).then(function(unwrapped) {
          // When a yielded Promise is resolved, its final value becomes
          // the .value of the Promise<{value,done}> result for the
          // current iteration.
          result.value = unwrapped;
          resolve(result);
        }, function(error) {
          // If a rejected Promise was yielded, throw the rejection back
          // into the async generator function so it can be handled there.
          return invoke("throw", error, resolve, reject);
        });
      }
    }

    var previousPromise;

    function enqueue(method, arg) {
      function callInvokeWithMethodAndArg() {
        return new PromiseImpl(function(resolve, reject) {
          invoke(method, arg, resolve, reject);
        });
      }

      return previousPromise =
        // If enqueue has been called before, then we want to wait until
        // all previous Promises have been resolved before calling invoke,
        // so that results are always delivered in the correct order. If
        // enqueue has not been called before, then it is important to
        // call invoke immediately, without waiting on a callback to fire,
        // so that the async generator function has the opportunity to do
        // any necessary setup in a predictable way. This predictability
        // is why the Promise constructor synchronously invokes its
        // executor callback, and why async functions synchronously
        // execute code before the first await. Since we implement simple
        // async functions in terms of async generators, it is especially
        // important to get this right, even though it requires care.
        previousPromise ? previousPromise.then(
          callInvokeWithMethodAndArg,
          // Avoid propagating failures to Promises returned by later
          // invocations of the iterator.
          callInvokeWithMethodAndArg
        ) : callInvokeWithMethodAndArg();
    }

    // Define the unified helper method that is used to implement .next,
    // .throw, and .return (see defineIteratorMethods).
    defineProperty(this, "_invoke", { value: enqueue });
  }

  defineIteratorMethods(AsyncIterator.prototype);
  define(AsyncIterator.prototype, asyncIteratorSymbol, function () {
    return this;
  });
  exports.AsyncIterator = AsyncIterator;

  // Note that simple async functions are implemented on top of
  // AsyncIterator objects; they just return a Promise for the value of
  // the final result produced by the iterator.
  exports.async = function(innerFn, outerFn, self, tryLocsList, PromiseImpl) {
    if (PromiseImpl === void 0) PromiseImpl = Promise;

    var iter = new AsyncIterator(
      wrap(innerFn, outerFn, self, tryLocsList),
      PromiseImpl
    );

    return exports.isGeneratorFunction(outerFn)
      ? iter // If outerFn is a generator, return the full iterator.
      : iter.next().then(function(result) {
          return result.done ? result.value : iter.next();
        });
  };

  function makeInvokeMethod(innerFn, self, context) {
    var state = GenStateSuspendedStart;

    return function invoke(method, arg) {
      if (state === GenStateExecuting) {
        throw new Error("Generator is already running");
      }

      if (state === GenStateCompleted) {
        if (method === "throw") {
          throw arg;
        }

        // Be forgiving, per 25.3.3.3.3 of the spec:
        // https://people.mozilla.org/~jorendorff/es6-draft.html#sec-generatorresume
        return doneResult();
      }

      context.method = method;
      context.arg = arg;

      while (true) {
        var delegate = context.delegate;
        if (delegate) {
          var delegateResult = maybeInvokeDelegate(delegate, context);
          if (delegateResult) {
            if (delegateResult === ContinueSentinel) continue;
            return delegateResult;
          }
        }

        if (context.method === "next") {
          // Setting context._sent for legacy support of Babel's
          // function.sent implementation.
          context.sent = context._sent = context.arg;

        } else if (context.method === "throw") {
          if (state === GenStateSuspendedStart) {
            state = GenStateCompleted;
            throw context.arg;
          }

          context.dispatchException(context.arg);

        } else if (context.method === "return") {
          context.abrupt("return", context.arg);
        }

        state = GenStateExecuting;

        var record = tryCatch(innerFn, self, context);
        if (record.type === "normal") {
          // If an exception is thrown from innerFn, we leave state ===
          // GenStateExecuting and loop back for another invocation.
          state = context.done
            ? GenStateCompleted
            : GenStateSuspendedYield;

          if (record.arg === ContinueSentinel) {
            continue;
          }

          return {
            value: record.arg,
            done: context.done
          };

        } else if (record.type === "throw") {
          state = GenStateCompleted;
          // Dispatch the exception by looping back around to the
          // context.dispatchException(context.arg) call above.
          context.method = "throw";
          context.arg = record.arg;
        }
      }
    };
  }

  // Call delegate.iterator[context.method](context.arg) and handle the
  // result, either by returning a { value, done } result from the
  // delegate iterator, or by modifying context.method and context.arg,
  // setting context.delegate to null, and returning the ContinueSentinel.
  function maybeInvokeDelegate(delegate, context) {
    var methodName = context.method;
    var method = delegate.iterator[methodName];
    if (method === undefined) {
      // A .throw or .return when the delegate iterator has no .throw
      // method, or a missing .next mehtod, always terminate the
      // yield* loop.
      context.delegate = null;

      // Note: ["return"] must be used for ES3 parsing compatibility.
      if (methodName === "throw" && delegate.iterator["return"]) {
        // If the delegate iterator has a return method, give it a
        // chance to clean up.
        context.method = "return";
        context.arg = undefined;
        maybeInvokeDelegate(delegate, context);

        if (context.method === "throw") {
          // If maybeInvokeDelegate(context) changed context.method from
          // "return" to "throw", let that override the TypeError below.
          return ContinueSentinel;
        }
      }
      if (methodName !== "return") {
        context.method = "throw";
        context.arg = new TypeError(
          "The iterator does not provide a '" + methodName + "' method");
      }

      return ContinueSentinel;
    }

    var record = tryCatch(method, delegate.iterator, context.arg);

    if (record.type === "throw") {
      context.method = "throw";
      context.arg = record.arg;
      context.delegate = null;
      return ContinueSentinel;
    }

    var info = record.arg;

    if (! info) {
      context.method = "throw";
      context.arg = new TypeError("iterator result is not an object");
      context.delegate = null;
      return ContinueSentinel;
    }

    if (info.done) {
      // Assign the result of the finished delegate to the temporary
      // variable specified by delegate.resultName (see delegateYield).
      context[delegate.resultName] = info.value;

      // Resume execution at the desired location (see delegateYield).
      context.next = delegate.nextLoc;

      // If context.method was "throw" but the delegate handled the
      // exception, let the outer generator proceed normally. If
      // context.method was "next", forget context.arg since it has been
      // "consumed" by the delegate iterator. If context.method was
      // "return", allow the original .return call to continue in the
      // outer generator.
      if (context.method !== "return") {
        context.method = "next";
        context.arg = undefined;
      }

    } else {
      // Re-yield the result returned by the delegate method.
      return info;
    }

    // The delegate iterator is finished, so forget it and continue with
    // the outer generator.
    context.delegate = null;
    return ContinueSentinel;
  }

  // Define Generator.prototype.{next,throw,return} in terms of the
  // unified ._invoke helper method.
  defineIteratorMethods(Gp);

  define(Gp, toStringTagSymbol, "Generator");

  // A Generator should always return itself as the iterator object when the
  // @@iterator function is called on it. Some browsers' implementations of the
  // iterator prototype chain incorrectly implement this, causing the Generator
  // object to not be returned from this call. This ensures that doesn't happen.
  // See https://github.com/facebook/regenerator/issues/274 for more details.
  define(Gp, iteratorSymbol, function() {
    return this;
  });

  define(Gp, "toString", function() {
    return "[object Generator]";
  });

  function pushTryEntry(locs) {
    var entry = { tryLoc: locs[0] };

    if (1 in locs) {
      entry.catchLoc = locs[1];
    }

    if (2 in locs) {
      entry.finallyLoc = locs[2];
      entry.afterLoc = locs[3];
    }

    this.tryEntries.push(entry);
  }

  function resetTryEntry(entry) {
    var record = entry.completion || {};
    record.type = "normal";
    delete record.arg;
    entry.completion = record;
  }

  function Context(tryLocsList) {
    // The root entry object (effectively a try statement without a catch
    // or a finally block) gives us a place to store values thrown from
    // locations where there is no enclosing try statement.
    this.tryEntries = [{ tryLoc: "root" }];
    tryLocsList.forEach(pushTryEntry, this);
    this.reset(true);
  }

  exports.keys = function(val) {
    var object = Object(val);
    var keys = [];
    for (var key in object) {
      keys.push(key);
    }
    keys.reverse();

    // Rather than returning an object with a next method, we keep
    // things simple and return the next function itself.
    return function next() {
      while (keys.length) {
        var key = keys.pop();
        if (key in object) {
          next.value = key;
          next.done = false;
          return next;
        }
      }

      // To avoid creating an additional object, we just hang the .value
      // and .done properties off the next function object itself. This
      // also ensures that the minifier will not anonymize the function.
      next.done = true;
      return next;
    };
  };

  function values(iterable) {
    if (iterable) {
      var iteratorMethod = iterable[iteratorSymbol];
      if (iteratorMethod) {
        return iteratorMethod.call(iterable);
      }

      if (typeof iterable.next === "function") {
        return iterable;
      }

      if (!isNaN(iterable.length)) {
        var i = -1, next = function next() {
          while (++i < iterable.length) {
            if (hasOwn.call(iterable, i)) {
              next.value = iterable[i];
              next.done = false;
              return next;
            }
          }

          next.value = undefined;
          next.done = true;

          return next;
        };

        return next.next = next;
      }
    }

    // Return an iterator with no values.
    return { next: doneResult };
  }
  exports.values = values;

  function doneResult() {
    return { value: undefined, done: true };
  }

  Context.prototype = {
    constructor: Context,

    reset: function(skipTempReset) {
      this.prev = 0;
      this.next = 0;
      // Resetting context._sent for legacy support of Babel's
      // function.sent implementation.
      this.sent = this._sent = undefined;
      this.done = false;
      this.delegate = null;

      this.method = "next";
      this.arg = undefined;

      this.tryEntries.forEach(resetTryEntry);

      if (!skipTempReset) {
        for (var name in this) {
          // Not sure about the optimal order of these conditions:
          if (name.charAt(0) === "t" &&
              hasOwn.call(this, name) &&
              !isNaN(+name.slice(1))) {
            this[name] = undefined;
          }
        }
      }
    },

    stop: function() {
      this.done = true;

      var rootEntry = this.tryEntries[0];
      var rootRecord = rootEntry.completion;
      if (rootRecord.type === "throw") {
        throw rootRecord.arg;
      }

      return this.rval;
    },

    dispatchException: function(exception) {
      if (this.done) {
        throw exception;
      }

      var context = this;
      function handle(loc, caught) {
        record.type = "throw";
        record.arg = exception;
        context.next = loc;

        if (caught) {
          // If the dispatched exception was caught by a catch block,
          // then let that catch block handle the exception normally.
          context.method = "next";
          context.arg = undefined;
        }

        return !! caught;
      }

      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        var record = entry.completion;

        if (entry.tryLoc === "root") {
          // Exception thrown outside of any try block that could handle
          // it, so set the completion value of the entire function to
          // throw the exception.
          return handle("end");
        }

        if (entry.tryLoc <= this.prev) {
          var hasCatch = hasOwn.call(entry, "catchLoc");
          var hasFinally = hasOwn.call(entry, "finallyLoc");

          if (hasCatch && hasFinally) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            } else if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }

          } else if (hasCatch) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            }

          } else if (hasFinally) {
            if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }

          } else {
            throw new Error("try statement without catch or finally");
          }
        }
      }
    },

    abrupt: function(type, arg) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc <= this.prev &&
            hasOwn.call(entry, "finallyLoc") &&
            this.prev < entry.finallyLoc) {
          var finallyEntry = entry;
          break;
        }
      }

      if (finallyEntry &&
          (type === "break" ||
           type === "continue") &&
          finallyEntry.tryLoc <= arg &&
          arg <= finallyEntry.finallyLoc) {
        // Ignore the finally entry if control is not jumping to a
        // location outside the try/catch block.
        finallyEntry = null;
      }

      var record = finallyEntry ? finallyEntry.completion : {};
      record.type = type;
      record.arg = arg;

      if (finallyEntry) {
        this.method = "next";
        this.next = finallyEntry.finallyLoc;
        return ContinueSentinel;
      }

      return this.complete(record);
    },

    complete: function(record, afterLoc) {
      if (record.type === "throw") {
        throw record.arg;
      }

      if (record.type === "break" ||
          record.type === "continue") {
        this.next = record.arg;
      } else if (record.type === "return") {
        this.rval = this.arg = record.arg;
        this.method = "return";
        this.next = "end";
      } else if (record.type === "normal" && afterLoc) {
        this.next = afterLoc;
      }

      return ContinueSentinel;
    },

    finish: function(finallyLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.finallyLoc === finallyLoc) {
          this.complete(entry.completion, entry.afterLoc);
          resetTryEntry(entry);
          return ContinueSentinel;
        }
      }
    },

    "catch": function(tryLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc === tryLoc) {
          var record = entry.completion;
          if (record.type === "throw") {
            var thrown = record.arg;
            resetTryEntry(entry);
          }
          return thrown;
        }
      }

      // The context.catch method must only be called with a location
      // argument that corresponds to a known catch block.
      throw new Error("illegal catch attempt");
    },

    delegateYield: function(iterable, resultName, nextLoc) {
      this.delegate = {
        iterator: values(iterable),
        resultName: resultName,
        nextLoc: nextLoc
      };

      if (this.method === "next") {
        // Deliberately forget the last sent value so that we don't
        // accidentally pass it on to the delegate.
        this.arg = undefined;
      }

      return ContinueSentinel;
    }
  };

  // Regardless of whether this script is executing as a CommonJS module
  // or not, return the runtime object so that we can declare the variable
  // regeneratorRuntime in the outer scope, which allows this module to be
  // injected easily by `bin/regenerator --include-runtime script.js`.
  return exports;

}(
  // If this script is executing as a CommonJS module, use module.exports
  // as the regeneratorRuntime namespace. Otherwise create a new empty
  // object. Either way, the resulting object will be used to initialize
  // the regeneratorRuntime variable at the top of this file.
   true ? module.exports : 0
));

try {
  regeneratorRuntime = runtime;
} catch (accidentalStrictMode) {
  // This module should not be running in strict mode, so the above
  // assignment should always work unless something is misconfigured. Just
  // in case runtime.js accidentally runs in strict mode, in modern engines
  // we can explicitly access globalThis. In older engines we can escape
  // strict mode using a global Function call. This could conceivably fail
  // if a Content Security Policy forbids using Function, but in that case
  // the proper solution is to fix the accidental strict mode problem. If
  // you've misconfigured your bundler to force strict mode and applied a
  // CSP to forbid Function, and you're not willing to fix either of those
  // problems, please detail your unique predicament in a GitHub issue.
  if (typeof globalThis === "object") {
    globalThis.regeneratorRuntime = runtime;
  } else {
    Function("r", "regeneratorRuntime = r")(runtime);
  }
}


/***/ }),

/***/ "./node_modules/uri-js/dist/esnext/index.js":
/*!**************************************************!*\
  !*** ./node_modules/uri-js/dist/esnext/index.js ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SCHEMES: () => (/* reexport safe */ _uri__WEBPACK_IMPORTED_MODULE_0__.SCHEMES),
/* harmony export */   equal: () => (/* reexport safe */ _uri__WEBPACK_IMPORTED_MODULE_0__.equal),
/* harmony export */   escapeComponent: () => (/* reexport safe */ _uri__WEBPACK_IMPORTED_MODULE_0__.escapeComponent),
/* harmony export */   normalize: () => (/* reexport safe */ _uri__WEBPACK_IMPORTED_MODULE_0__.normalize),
/* harmony export */   parse: () => (/* reexport safe */ _uri__WEBPACK_IMPORTED_MODULE_0__.parse),
/* harmony export */   pctDecChars: () => (/* reexport safe */ _uri__WEBPACK_IMPORTED_MODULE_0__.pctDecChars),
/* harmony export */   pctEncChar: () => (/* reexport safe */ _uri__WEBPACK_IMPORTED_MODULE_0__.pctEncChar),
/* harmony export */   removeDotSegments: () => (/* reexport safe */ _uri__WEBPACK_IMPORTED_MODULE_0__.removeDotSegments),
/* harmony export */   resolve: () => (/* reexport safe */ _uri__WEBPACK_IMPORTED_MODULE_0__.resolve),
/* harmony export */   resolveComponents: () => (/* reexport safe */ _uri__WEBPACK_IMPORTED_MODULE_0__.resolveComponents),
/* harmony export */   serialize: () => (/* reexport safe */ _uri__WEBPACK_IMPORTED_MODULE_0__.serialize),
/* harmony export */   unescapeComponent: () => (/* reexport safe */ _uri__WEBPACK_IMPORTED_MODULE_0__.unescapeComponent)
/* harmony export */ });
/* harmony import */ var _uri__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./uri */ "./node_modules/uri-js/dist/esnext/uri.js");
/* harmony import */ var _schemes_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./schemes/http */ "./node_modules/uri-js/dist/esnext/schemes/http.js");
/* harmony import */ var _schemes_https__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./schemes/https */ "./node_modules/uri-js/dist/esnext/schemes/https.js");
/* harmony import */ var _schemes_mailto__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./schemes/mailto */ "./node_modules/uri-js/dist/esnext/schemes/mailto.js");
/* harmony import */ var _schemes_urn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./schemes/urn */ "./node_modules/uri-js/dist/esnext/schemes/urn.js");
/* harmony import */ var _schemes_urn_uuid__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./schemes/urn-uuid */ "./node_modules/uri-js/dist/esnext/schemes/urn-uuid.js");


_uri__WEBPACK_IMPORTED_MODULE_0__.SCHEMES["http"] = _schemes_http__WEBPACK_IMPORTED_MODULE_1__["default"];

_uri__WEBPACK_IMPORTED_MODULE_0__.SCHEMES["https"] = _schemes_https__WEBPACK_IMPORTED_MODULE_2__["default"];

_uri__WEBPACK_IMPORTED_MODULE_0__.SCHEMES["mailto"] = _schemes_mailto__WEBPACK_IMPORTED_MODULE_3__["default"];

_uri__WEBPACK_IMPORTED_MODULE_0__.SCHEMES["urn"] = _schemes_urn__WEBPACK_IMPORTED_MODULE_4__["default"];

_uri__WEBPACK_IMPORTED_MODULE_0__.SCHEMES["urn:uuid"] = _schemes_urn_uuid__WEBPACK_IMPORTED_MODULE_5__["default"];

//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/uri-js/dist/esnext/regexps-iri.js":
/*!********************************************************!*\
  !*** ./node_modules/uri-js/dist/esnext/regexps-iri.js ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _regexps_uri__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./regexps-uri */ "./node_modules/uri-js/dist/esnext/regexps-uri.js");

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_regexps_uri__WEBPACK_IMPORTED_MODULE_0__.buildExps)(true));
//# sourceMappingURL=regexps-iri.js.map

/***/ }),

/***/ "./node_modules/uri-js/dist/esnext/regexps-uri.js":
/*!********************************************************!*\
  !*** ./node_modules/uri-js/dist/esnext/regexps-uri.js ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   buildExps: () => (/* binding */ buildExps),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./util */ "./node_modules/uri-js/dist/esnext/util.js");

function buildExps(isIRI) {
    const ALPHA$$ = "[A-Za-z]", CR$ = "[\\x0D]", DIGIT$$ = "[0-9]", DQUOTE$$ = "[\\x22]", HEXDIG$$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.merge)(DIGIT$$, "[A-Fa-f]"), //case-insensitive
    LF$$ = "[\\x0A]", SP$$ = "[\\x20]", PCT_ENCODED$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)((0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("%[EFef]" + HEXDIG$$ + "%" + HEXDIG$$ + HEXDIG$$ + "%" + HEXDIG$$ + HEXDIG$$) + "|" + (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("%[89A-Fa-f]" + HEXDIG$$ + "%" + HEXDIG$$ + HEXDIG$$) + "|" + (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("%" + HEXDIG$$ + HEXDIG$$)), //expanded
    GEN_DELIMS$$ = "[\\:\\/\\?\\#\\[\\]\\@]", SUB_DELIMS$$ = "[\\!\\$\\&\\'\\(\\)\\*\\+\\,\\;\\=]", RESERVED$$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.merge)(GEN_DELIMS$$, SUB_DELIMS$$), UCSCHAR$$ = isIRI ? "[\\xA0-\\u200D\\u2010-\\u2029\\u202F-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF]" : "[]", //subset, excludes bidi control characters
    IPRIVATE$$ = isIRI ? "[\\uE000-\\uF8FF]" : "[]", //subset
    UNRESERVED$$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.merge)(ALPHA$$, DIGIT$$, "[\\-\\.\\_\\~]", UCSCHAR$$), SCHEME$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(ALPHA$$ + (0,_util__WEBPACK_IMPORTED_MODULE_0__.merge)(ALPHA$$, DIGIT$$, "[\\+\\-\\.]") + "*"), USERINFO$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)((0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(PCT_ENCODED$ + "|" + (0,_util__WEBPACK_IMPORTED_MODULE_0__.merge)(UNRESERVED$$, SUB_DELIMS$$, "[\\:]")) + "*"), DEC_OCTET$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)((0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("25[0-5]") + "|" + (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("2[0-4]" + DIGIT$$) + "|" + (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("1" + DIGIT$$ + DIGIT$$) + "|" + (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("[1-9]" + DIGIT$$) + "|" + DIGIT$$), IPV4ADDRESS$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(DEC_OCTET$ + "\\." + DEC_OCTET$ + "\\." + DEC_OCTET$ + "\\." + DEC_OCTET$), H16$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(HEXDIG$$ + "{1,4}"), LS32$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)((0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(H16$ + "\\:" + H16$) + "|" + IPV4ADDRESS$), IPV6ADDRESS1$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)((0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(H16$ + "\\:") + "{6}" + LS32$), //                           6( h16 ":" ) ls32
    IPV6ADDRESS2$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("\\:\\:" + (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(H16$ + "\\:") + "{5}" + LS32$), //                      "::" 5( h16 ":" ) ls32
    IPV6ADDRESS3$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)((0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(H16$) + "?\\:\\:" + (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(H16$ + "\\:") + "{4}" + LS32$), //[               h16 ] "::" 4( h16 ":" ) ls32
    IPV6ADDRESS4$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)((0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)((0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(H16$ + "\\:") + "{0,1}" + H16$) + "?\\:\\:" + (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(H16$ + "\\:") + "{3}" + LS32$), //[ *1( h16 ":" ) h16 ] "::" 3( h16 ":" ) ls32
    IPV6ADDRESS5$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)((0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)((0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(H16$ + "\\:") + "{0,2}" + H16$) + "?\\:\\:" + (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(H16$ + "\\:") + "{2}" + LS32$), //[ *2( h16 ":" ) h16 ] "::" 2( h16 ":" ) ls32
    IPV6ADDRESS6$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)((0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)((0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(H16$ + "\\:") + "{0,3}" + H16$) + "?\\:\\:" + H16$ + "\\:" + LS32$), //[ *3( h16 ":" ) h16 ] "::"    h16 ":"   ls32
    IPV6ADDRESS7$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)((0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)((0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(H16$ + "\\:") + "{0,4}" + H16$) + "?\\:\\:" + LS32$), //[ *4( h16 ":" ) h16 ] "::"              ls32
    IPV6ADDRESS8$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)((0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)((0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(H16$ + "\\:") + "{0,5}" + H16$) + "?\\:\\:" + H16$), //[ *5( h16 ":" ) h16 ] "::"              h16
    IPV6ADDRESS9$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)((0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)((0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(H16$ + "\\:") + "{0,6}" + H16$) + "?\\:\\:"), //[ *6( h16 ":" ) h16 ] "::"
    IPV6ADDRESS$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)([IPV6ADDRESS1$, IPV6ADDRESS2$, IPV6ADDRESS3$, IPV6ADDRESS4$, IPV6ADDRESS5$, IPV6ADDRESS6$, IPV6ADDRESS7$, IPV6ADDRESS8$, IPV6ADDRESS9$].join("|")), IPVFUTURE$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("[vV]" + HEXDIG$$ + "+\\." + (0,_util__WEBPACK_IMPORTED_MODULE_0__.merge)(UNRESERVED$$, SUB_DELIMS$$, "[\\:]") + "+"), IP_LITERAL$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("\\[" + (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(IPV6ADDRESS$ + "|" + IPVFUTURE$) + "\\]"), REG_NAME$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)((0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(PCT_ENCODED$ + "|" + (0,_util__WEBPACK_IMPORTED_MODULE_0__.merge)(UNRESERVED$$, SUB_DELIMS$$)) + "*"), HOST$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(IP_LITERAL$ + "|" + IPV4ADDRESS$ + "(?!" + REG_NAME$ + ")" + "|" + REG_NAME$), PORT$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(DIGIT$$ + "*"), AUTHORITY$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)((0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(USERINFO$ + "@") + "?" + HOST$ + (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("\\:" + PORT$) + "?"), PCHAR$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(PCT_ENCODED$ + "|" + (0,_util__WEBPACK_IMPORTED_MODULE_0__.merge)(UNRESERVED$$, SUB_DELIMS$$, "[\\:\\@]")), SEGMENT$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(PCHAR$ + "*"), SEGMENT_NZ$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(PCHAR$ + "+"), SEGMENT_NZ_NC$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)((0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(PCT_ENCODED$ + "|" + (0,_util__WEBPACK_IMPORTED_MODULE_0__.merge)(UNRESERVED$$, SUB_DELIMS$$, "[\\@]")) + "+"), PATH_ABEMPTY$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)((0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("\\/" + SEGMENT$) + "*"), PATH_ABSOLUTE$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("\\/" + (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(SEGMENT_NZ$ + PATH_ABEMPTY$) + "?"), //simplified
    PATH_NOSCHEME$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(SEGMENT_NZ_NC$ + PATH_ABEMPTY$), //simplified
    PATH_ROOTLESS$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(SEGMENT_NZ$ + PATH_ABEMPTY$), //simplified
    PATH_EMPTY$ = "(?!" + PCHAR$ + ")", PATH$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(PATH_ABEMPTY$ + "|" + PATH_ABSOLUTE$ + "|" + PATH_NOSCHEME$ + "|" + PATH_ROOTLESS$ + "|" + PATH_EMPTY$), QUERY$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)((0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(PCHAR$ + "|" + (0,_util__WEBPACK_IMPORTED_MODULE_0__.merge)("[\\/\\?]", IPRIVATE$$)) + "*"), FRAGMENT$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)((0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(PCHAR$ + "|[\\/\\?]") + "*"), HIER_PART$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)((0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("\\/\\/" + AUTHORITY$ + PATH_ABEMPTY$) + "|" + PATH_ABSOLUTE$ + "|" + PATH_ROOTLESS$ + "|" + PATH_EMPTY$), URI$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(SCHEME$ + "\\:" + HIER_PART$ + (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("\\?" + QUERY$) + "?" + (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("\\#" + FRAGMENT$) + "?"), RELATIVE_PART$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)((0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("\\/\\/" + AUTHORITY$ + PATH_ABEMPTY$) + "|" + PATH_ABSOLUTE$ + "|" + PATH_NOSCHEME$ + "|" + PATH_EMPTY$), RELATIVE$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(RELATIVE_PART$ + (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("\\?" + QUERY$) + "?" + (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("\\#" + FRAGMENT$) + "?"), URI_REFERENCE$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(URI$ + "|" + RELATIVE$), ABSOLUTE_URI$ = (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)(SCHEME$ + "\\:" + HIER_PART$ + (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("\\?" + QUERY$) + "?"), GENERIC_REF$ = "^(" + SCHEME$ + ")\\:" + (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)((0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("\\/\\/(" + (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("(" + USERINFO$ + ")@") + "?(" + HOST$ + ")" + (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("\\:(" + PORT$ + ")") + "?)") + "?(" + PATH_ABEMPTY$ + "|" + PATH_ABSOLUTE$ + "|" + PATH_ROOTLESS$ + "|" + PATH_EMPTY$ + ")") + (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("\\?(" + QUERY$ + ")") + "?" + (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("\\#(" + FRAGMENT$ + ")") + "?$", RELATIVE_REF$ = "^(){0}" + (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)((0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("\\/\\/(" + (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("(" + USERINFO$ + ")@") + "?(" + HOST$ + ")" + (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("\\:(" + PORT$ + ")") + "?)") + "?(" + PATH_ABEMPTY$ + "|" + PATH_ABSOLUTE$ + "|" + PATH_NOSCHEME$ + "|" + PATH_EMPTY$ + ")") + (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("\\?(" + QUERY$ + ")") + "?" + (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("\\#(" + FRAGMENT$ + ")") + "?$", ABSOLUTE_REF$ = "^(" + SCHEME$ + ")\\:" + (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)((0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("\\/\\/(" + (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("(" + USERINFO$ + ")@") + "?(" + HOST$ + ")" + (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("\\:(" + PORT$ + ")") + "?)") + "?(" + PATH_ABEMPTY$ + "|" + PATH_ABSOLUTE$ + "|" + PATH_ROOTLESS$ + "|" + PATH_EMPTY$ + ")") + (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("\\?(" + QUERY$ + ")") + "?$", SAMEDOC_REF$ = "^" + (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("\\#(" + FRAGMENT$ + ")") + "?$", AUTHORITY_REF$ = "^" + (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("(" + USERINFO$ + ")@") + "?(" + HOST$ + ")" + (0,_util__WEBPACK_IMPORTED_MODULE_0__.subexp)("\\:(" + PORT$ + ")") + "?$";
    return {
        NOT_SCHEME: new RegExp((0,_util__WEBPACK_IMPORTED_MODULE_0__.merge)("[^]", ALPHA$$, DIGIT$$, "[\\+\\-\\.]"), "g"),
        NOT_USERINFO: new RegExp((0,_util__WEBPACK_IMPORTED_MODULE_0__.merge)("[^\\%\\:]", UNRESERVED$$, SUB_DELIMS$$), "g"),
        NOT_HOST: new RegExp((0,_util__WEBPACK_IMPORTED_MODULE_0__.merge)("[^\\%\\[\\]\\:]", UNRESERVED$$, SUB_DELIMS$$), "g"),
        NOT_PATH: new RegExp((0,_util__WEBPACK_IMPORTED_MODULE_0__.merge)("[^\\%\\/\\:\\@]", UNRESERVED$$, SUB_DELIMS$$), "g"),
        NOT_PATH_NOSCHEME: new RegExp((0,_util__WEBPACK_IMPORTED_MODULE_0__.merge)("[^\\%\\/\\@]", UNRESERVED$$, SUB_DELIMS$$), "g"),
        NOT_QUERY: new RegExp((0,_util__WEBPACK_IMPORTED_MODULE_0__.merge)("[^\\%]", UNRESERVED$$, SUB_DELIMS$$, "[\\:\\@\\/\\?]", IPRIVATE$$), "g"),
        NOT_FRAGMENT: new RegExp((0,_util__WEBPACK_IMPORTED_MODULE_0__.merge)("[^\\%]", UNRESERVED$$, SUB_DELIMS$$, "[\\:\\@\\/\\?]"), "g"),
        ESCAPE: new RegExp((0,_util__WEBPACK_IMPORTED_MODULE_0__.merge)("[^]", UNRESERVED$$, SUB_DELIMS$$), "g"),
        UNRESERVED: new RegExp(UNRESERVED$$, "g"),
        OTHER_CHARS: new RegExp((0,_util__WEBPACK_IMPORTED_MODULE_0__.merge)("[^\\%]", UNRESERVED$$, RESERVED$$), "g"),
        PCT_ENCODED: new RegExp(PCT_ENCODED$, "g"),
        IPV6ADDRESS: new RegExp("\\[?(" + IPV6ADDRESS$ + ")\\]?", "g")
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (buildExps(false));
//# sourceMappingURL=regexps-uri.js.map

/***/ }),

/***/ "./node_modules/uri-js/dist/esnext/schemes/http.js":
/*!*********************************************************!*\
  !*** ./node_modules/uri-js/dist/esnext/schemes/http.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    scheme: "http",
    domainHost: true,
    parse: function (components, options) {
        //report missing host
        if (!components.host) {
            components.error = components.error || "HTTP URIs must have a host.";
        }
        return components;
    },
    serialize: function (components, options) {
        //normalize the default port
        if (components.port === (String(components.scheme).toLowerCase() !== "https" ? 80 : 443) || components.port === "") {
            components.port = undefined;
        }
        //normalize the empty path
        if (!components.path) {
            components.path = "/";
        }
        //NOTE: We do not parse query strings for HTTP URIs
        //as WWW Form Url Encoded query strings are part of the HTML4+ spec,
        //and not the HTTP spec.
        return components;
    }
});
//# sourceMappingURL=http.js.map

/***/ }),

/***/ "./node_modules/uri-js/dist/esnext/schemes/https.js":
/*!**********************************************************!*\
  !*** ./node_modules/uri-js/dist/esnext/schemes/https.js ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./http */ "./node_modules/uri-js/dist/esnext/schemes/http.js");

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    scheme: "https",
    domainHost: _http__WEBPACK_IMPORTED_MODULE_0__["default"].domainHost,
    parse: _http__WEBPACK_IMPORTED_MODULE_0__["default"].parse,
    serialize: _http__WEBPACK_IMPORTED_MODULE_0__["default"].serialize
});
//# sourceMappingURL=https.js.map

/***/ }),

/***/ "./node_modules/uri-js/dist/esnext/schemes/mailto.js":
/*!***********************************************************!*\
  !*** ./node_modules/uri-js/dist/esnext/schemes/mailto.js ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _uri__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../uri */ "./node_modules/uri-js/dist/esnext/uri.js");
/* harmony import */ var punycode__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! punycode */ "./node_modules/punycode/punycode.es6.js");
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../util */ "./node_modules/uri-js/dist/esnext/util.js");



const O = {};
const isIRI = true;
//RFC 3986
const UNRESERVED$$ = "[A-Za-z0-9\\-\\.\\_\\~" + (isIRI ? "\\xA0-\\u200D\\u2010-\\u2029\\u202F-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF" : "") + "]";
const HEXDIG$$ = "[0-9A-Fa-f]"; //case-insensitive
const PCT_ENCODED$ = (0,_util__WEBPACK_IMPORTED_MODULE_2__.subexp)((0,_util__WEBPACK_IMPORTED_MODULE_2__.subexp)("%[EFef]" + HEXDIG$$ + "%" + HEXDIG$$ + HEXDIG$$ + "%" + HEXDIG$$ + HEXDIG$$) + "|" + (0,_util__WEBPACK_IMPORTED_MODULE_2__.subexp)("%[89A-Fa-f]" + HEXDIG$$ + "%" + HEXDIG$$ + HEXDIG$$) + "|" + (0,_util__WEBPACK_IMPORTED_MODULE_2__.subexp)("%" + HEXDIG$$ + HEXDIG$$)); //expanded
//RFC 5322, except these symbols as per RFC 6068: @ : / ? # [ ] & ; =
//const ATEXT$$ = "[A-Za-z0-9\\!\\#\\$\\%\\&\\'\\*\\+\\-\\/\\=\\?\\^\\_\\`\\{\\|\\}\\~]";
//const WSP$$ = "[\\x20\\x09]";
//const OBS_QTEXT$$ = "[\\x01-\\x08\\x0B\\x0C\\x0E-\\x1F\\x7F]";  //(%d1-8 / %d11-12 / %d14-31 / %d127)
//const QTEXT$$ = merge("[\\x21\\x23-\\x5B\\x5D-\\x7E]", OBS_QTEXT$$);  //%d33 / %d35-91 / %d93-126 / obs-qtext
//const VCHAR$$ = "[\\x21-\\x7E]";
//const WSP$$ = "[\\x20\\x09]";
//const OBS_QP$ = subexp("\\\\" + merge("[\\x00\\x0D\\x0A]", OBS_QTEXT$$));  //%d0 / CR / LF / obs-qtext
//const FWS$ = subexp(subexp(WSP$$ + "*" + "\\x0D\\x0A") + "?" + WSP$$ + "+");
//const QUOTED_PAIR$ = subexp(subexp("\\\\" + subexp(VCHAR$$ + "|" + WSP$$)) + "|" + OBS_QP$);
//const QUOTED_STRING$ = subexp('\\"' + subexp(FWS$ + "?" + QCONTENT$) + "*" + FWS$ + "?" + '\\"');
const ATEXT$$ = "[A-Za-z0-9\\!\\$\\%\\'\\*\\+\\-\\^\\_\\`\\{\\|\\}\\~]";
const QTEXT$$ = "[\\!\\$\\%\\'\\(\\)\\*\\+\\,\\-\\.0-9\\<\\>A-Z\\x5E-\\x7E]";
const VCHAR$$ = (0,_util__WEBPACK_IMPORTED_MODULE_2__.merge)(QTEXT$$, "[\\\"\\\\]");
const DOT_ATOM_TEXT$ = (0,_util__WEBPACK_IMPORTED_MODULE_2__.subexp)(ATEXT$$ + "+" + (0,_util__WEBPACK_IMPORTED_MODULE_2__.subexp)("\\." + ATEXT$$ + "+") + "*");
const QUOTED_PAIR$ = (0,_util__WEBPACK_IMPORTED_MODULE_2__.subexp)("\\\\" + VCHAR$$);
const QCONTENT$ = (0,_util__WEBPACK_IMPORTED_MODULE_2__.subexp)(QTEXT$$ + "|" + QUOTED_PAIR$);
const QUOTED_STRING$ = (0,_util__WEBPACK_IMPORTED_MODULE_2__.subexp)('\\"' + QCONTENT$ + "*" + '\\"');
//RFC 6068
const DTEXT_NO_OBS$$ = "[\\x21-\\x5A\\x5E-\\x7E]"; //%d33-90 / %d94-126
const SOME_DELIMS$$ = "[\\!\\$\\'\\(\\)\\*\\+\\,\\;\\:\\@]";
const QCHAR$ = (0,_util__WEBPACK_IMPORTED_MODULE_2__.subexp)(UNRESERVED$$ + "|" + PCT_ENCODED$ + "|" + SOME_DELIMS$$);
const DOMAIN$ = (0,_util__WEBPACK_IMPORTED_MODULE_2__.subexp)(DOT_ATOM_TEXT$ + "|" + "\\[" + DTEXT_NO_OBS$$ + "*" + "\\]");
const LOCAL_PART$ = (0,_util__WEBPACK_IMPORTED_MODULE_2__.subexp)(DOT_ATOM_TEXT$ + "|" + QUOTED_STRING$);
const ADDR_SPEC$ = (0,_util__WEBPACK_IMPORTED_MODULE_2__.subexp)(LOCAL_PART$ + "\\@" + DOMAIN$);
const TO$ = (0,_util__WEBPACK_IMPORTED_MODULE_2__.subexp)(ADDR_SPEC$ + (0,_util__WEBPACK_IMPORTED_MODULE_2__.subexp)("\\," + ADDR_SPEC$) + "*");
const HFNAME$ = (0,_util__WEBPACK_IMPORTED_MODULE_2__.subexp)(QCHAR$ + "*");
const HFVALUE$ = HFNAME$;
const HFIELD$ = (0,_util__WEBPACK_IMPORTED_MODULE_2__.subexp)(HFNAME$ + "\\=" + HFVALUE$);
const HFIELDS2$ = (0,_util__WEBPACK_IMPORTED_MODULE_2__.subexp)(HFIELD$ + (0,_util__WEBPACK_IMPORTED_MODULE_2__.subexp)("\\&" + HFIELD$) + "*");
const HFIELDS$ = (0,_util__WEBPACK_IMPORTED_MODULE_2__.subexp)("\\?" + HFIELDS2$);
const MAILTO_URI = new RegExp("^mailto\\:" + TO$ + "?" + HFIELDS$ + "?$");
const UNRESERVED = new RegExp(UNRESERVED$$, "g");
const PCT_ENCODED = new RegExp(PCT_ENCODED$, "g");
const NOT_LOCAL_PART = new RegExp((0,_util__WEBPACK_IMPORTED_MODULE_2__.merge)("[^]", ATEXT$$, "[\\.]", '[\\"]', VCHAR$$), "g");
const NOT_DOMAIN = new RegExp((0,_util__WEBPACK_IMPORTED_MODULE_2__.merge)("[^]", ATEXT$$, "[\\.]", "[\\[]", DTEXT_NO_OBS$$, "[\\]]"), "g");
const NOT_HFNAME = new RegExp((0,_util__WEBPACK_IMPORTED_MODULE_2__.merge)("[^]", UNRESERVED$$, SOME_DELIMS$$), "g");
const NOT_HFVALUE = NOT_HFNAME;
const TO = new RegExp("^" + TO$ + "$");
const HFIELDS = new RegExp("^" + HFIELDS2$ + "$");
function decodeUnreserved(str) {
    const decStr = (0,_uri__WEBPACK_IMPORTED_MODULE_0__.pctDecChars)(str);
    return (!decStr.match(UNRESERVED) ? str : decStr);
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    scheme: "mailto",
    parse: function (components, options) {
        const to = components.to = (components.path ? components.path.split(",") : []);
        components.path = undefined;
        if (components.query) {
            let unknownHeaders = false;
            const headers = {};
            const hfields = components.query.split("&");
            for (let x = 0, xl = hfields.length; x < xl; ++x) {
                const hfield = hfields[x].split("=");
                switch (hfield[0]) {
                    case "to":
                        const toAddrs = hfield[1].split(",");
                        for (let x = 0, xl = toAddrs.length; x < xl; ++x) {
                            to.push(toAddrs[x]);
                        }
                        break;
                    case "subject":
                        components.subject = (0,_uri__WEBPACK_IMPORTED_MODULE_0__.unescapeComponent)(hfield[1], options);
                        break;
                    case "body":
                        components.body = (0,_uri__WEBPACK_IMPORTED_MODULE_0__.unescapeComponent)(hfield[1], options);
                        break;
                    default:
                        unknownHeaders = true;
                        headers[(0,_uri__WEBPACK_IMPORTED_MODULE_0__.unescapeComponent)(hfield[0], options)] = (0,_uri__WEBPACK_IMPORTED_MODULE_0__.unescapeComponent)(hfield[1], options);
                        break;
                }
            }
            if (unknownHeaders)
                components.headers = headers;
        }
        components.query = undefined;
        for (let x = 0, xl = to.length; x < xl; ++x) {
            const addr = to[x].split("@");
            addr[0] = (0,_uri__WEBPACK_IMPORTED_MODULE_0__.unescapeComponent)(addr[0]);
            if (!options.unicodeSupport) {
                //convert Unicode IDN -> ASCII IDN
                try {
                    addr[1] = punycode__WEBPACK_IMPORTED_MODULE_1__["default"].toASCII((0,_uri__WEBPACK_IMPORTED_MODULE_0__.unescapeComponent)(addr[1], options).toLowerCase());
                }
                catch (e) {
                    components.error = components.error || "Email address's domain name can not be converted to ASCII via punycode: " + e;
                }
            }
            else {
                addr[1] = (0,_uri__WEBPACK_IMPORTED_MODULE_0__.unescapeComponent)(addr[1], options).toLowerCase();
            }
            to[x] = addr.join("@");
        }
        return components;
    },
    serialize: function (components, options) {
        const to = (0,_util__WEBPACK_IMPORTED_MODULE_2__.toArray)(components.to);
        if (to) {
            for (let x = 0, xl = to.length; x < xl; ++x) {
                const toAddr = String(to[x]);
                const atIdx = toAddr.lastIndexOf("@");
                const localPart = (toAddr.slice(0, atIdx)).replace(PCT_ENCODED, decodeUnreserved).replace(PCT_ENCODED, _util__WEBPACK_IMPORTED_MODULE_2__.toUpperCase).replace(NOT_LOCAL_PART, _uri__WEBPACK_IMPORTED_MODULE_0__.pctEncChar);
                let domain = toAddr.slice(atIdx + 1);
                //convert IDN via punycode
                try {
                    domain = (!options.iri ? punycode__WEBPACK_IMPORTED_MODULE_1__["default"].toASCII((0,_uri__WEBPACK_IMPORTED_MODULE_0__.unescapeComponent)(domain, options).toLowerCase()) : punycode__WEBPACK_IMPORTED_MODULE_1__["default"].toUnicode(domain));
                }
                catch (e) {
                    components.error = components.error || "Email address's domain name can not be converted to " + (!options.iri ? "ASCII" : "Unicode") + " via punycode: " + e;
                }
                to[x] = localPart + "@" + domain;
            }
            components.path = to.join(",");
        }
        const headers = components.headers = components.headers || {};
        if (components.subject)
            headers["subject"] = components.subject;
        if (components.body)
            headers["body"] = components.body;
        const fields = [];
        for (const name in headers) {
            if (headers[name] !== O[name]) {
                fields.push(name.replace(PCT_ENCODED, decodeUnreserved).replace(PCT_ENCODED, _util__WEBPACK_IMPORTED_MODULE_2__.toUpperCase).replace(NOT_HFNAME, _uri__WEBPACK_IMPORTED_MODULE_0__.pctEncChar) +
                    "=" +
                    headers[name].replace(PCT_ENCODED, decodeUnreserved).replace(PCT_ENCODED, _util__WEBPACK_IMPORTED_MODULE_2__.toUpperCase).replace(NOT_HFVALUE, _uri__WEBPACK_IMPORTED_MODULE_0__.pctEncChar));
            }
        }
        if (fields.length) {
            components.query = fields.join("&");
        }
        return components;
    }
});
//# sourceMappingURL=mailto.js.map

/***/ }),

/***/ "./node_modules/uri-js/dist/esnext/schemes/urn-uuid.js":
/*!*************************************************************!*\
  !*** ./node_modules/uri-js/dist/esnext/schemes/urn-uuid.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _uri__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../uri */ "./node_modules/uri-js/dist/esnext/uri.js");

const UUID = /^[0-9A-Fa-f]{8}(?:\-[0-9A-Fa-f]{4}){3}\-[0-9A-Fa-f]{12}$/;
//RFC 4122
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    scheme: "urn:uuid",
    parse: function (components, options) {
        if (!options.tolerant && (!components.path || !components.path.match(UUID))) {
            components.error = components.error || "UUID is not valid.";
        }
        return components;
    },
    serialize: function (components, options) {
        //ensure UUID is valid
        if (!options.tolerant && (!components.path || !components.path.match(UUID))) {
            //invalid UUIDs can not have this scheme
            components.scheme = undefined;
        }
        else {
            //normalize UUID
            components.path = (components.path || "").toLowerCase();
        }
        return _uri__WEBPACK_IMPORTED_MODULE_0__.SCHEMES["urn"].serialize(components, options);
    }
});
//# sourceMappingURL=urn-uuid.js.map

/***/ }),

/***/ "./node_modules/uri-js/dist/esnext/schemes/urn.js":
/*!********************************************************!*\
  !*** ./node_modules/uri-js/dist/esnext/schemes/urn.js ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _uri__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../uri */ "./node_modules/uri-js/dist/esnext/uri.js");

const NID$ = "(?:[0-9A-Za-z][0-9A-Za-z\\-]{1,31})";
const PCT_ENCODED$ = "(?:\\%[0-9A-Fa-f]{2})";
const TRANS$$ = "[0-9A-Za-z\\(\\)\\+\\,\\-\\.\\:\\=\\@\\;\\$\\_\\!\\*\\'\\/\\?\\#]";
const NSS$ = "(?:(?:" + PCT_ENCODED$ + "|" + TRANS$$ + ")+)";
const URN_SCHEME = new RegExp("^urn\\:(" + NID$ + ")$");
const URN_PATH = new RegExp("^(" + NID$ + ")\\:(" + NSS$ + ")$");
const URN_PARSE = /^([^\:]+)\:(.*)/;
const URN_EXCLUDED = /[\x00-\x20\\\"\&\<\>\[\]\^\`\{\|\}\~\x7F-\xFF]/g;
//RFC 2141
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    scheme: "urn",
    parse: function (components, options) {
        const matches = components.path && components.path.match(URN_PARSE);
        if (matches) {
            const scheme = "urn:" + matches[1].toLowerCase();
            let schemeHandler = _uri__WEBPACK_IMPORTED_MODULE_0__.SCHEMES[scheme];
            //in order to serialize properly,
            //every URN must have a serializer that calls the URN serializer
            if (!schemeHandler) {
                //create fake scheme handler
                schemeHandler = _uri__WEBPACK_IMPORTED_MODULE_0__.SCHEMES[scheme] = {
                    scheme: scheme,
                    parse: function (components, options) {
                        return components;
                    },
                    serialize: _uri__WEBPACK_IMPORTED_MODULE_0__.SCHEMES["urn"].serialize
                };
            }
            components.scheme = scheme;
            components.path = matches[2];
            components = schemeHandler.parse(components, options);
        }
        else {
            components.error = components.error || "URN can not be parsed.";
        }
        return components;
    },
    serialize: function (components, options) {
        const scheme = components.scheme || options.scheme;
        if (scheme && scheme !== "urn") {
            const matches = scheme.match(URN_SCHEME) || ["urn:" + scheme, scheme];
            components.scheme = "urn";
            components.path = matches[1] + ":" + (components.path ? components.path.replace(URN_EXCLUDED, _uri__WEBPACK_IMPORTED_MODULE_0__.pctEncChar) : "");
        }
        return components;
    }
});
//# sourceMappingURL=urn.js.map

/***/ }),

/***/ "./node_modules/uri-js/dist/esnext/uri.js":
/*!************************************************!*\
  !*** ./node_modules/uri-js/dist/esnext/uri.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SCHEMES: () => (/* binding */ SCHEMES),
/* harmony export */   equal: () => (/* binding */ equal),
/* harmony export */   escapeComponent: () => (/* binding */ escapeComponent),
/* harmony export */   normalize: () => (/* binding */ normalize),
/* harmony export */   parse: () => (/* binding */ parse),
/* harmony export */   pctDecChars: () => (/* binding */ pctDecChars),
/* harmony export */   pctEncChar: () => (/* binding */ pctEncChar),
/* harmony export */   removeDotSegments: () => (/* binding */ removeDotSegments),
/* harmony export */   resolve: () => (/* binding */ resolve),
/* harmony export */   resolveComponents: () => (/* binding */ resolveComponents),
/* harmony export */   serialize: () => (/* binding */ serialize),
/* harmony export */   unescapeComponent: () => (/* binding */ unescapeComponent)
/* harmony export */ });
/* harmony import */ var _regexps_uri__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./regexps-uri */ "./node_modules/uri-js/dist/esnext/regexps-uri.js");
/* harmony import */ var _regexps_iri__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./regexps-iri */ "./node_modules/uri-js/dist/esnext/regexps-iri.js");
/* harmony import */ var punycode__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! punycode */ "./node_modules/punycode/punycode.es6.js");
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./util */ "./node_modules/uri-js/dist/esnext/util.js");
/**
 * URI.js
 *
 * @fileoverview An RFC 3986 compliant, scheme extendable URI parsing/validating/resolving library for JavaScript.
 * @author <a href="mailto:gary.court@gmail.com">Gary Court</a>
 * @see http://github.com/garycourt/uri-js
 */
/**
 * Copyright 2011 Gary Court. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification, are
 * permitted provided that the following conditions are met:
 *
 *    1. Redistributions of source code must retain the above copyright notice, this list of
 *       conditions and the following disclaimer.
 *
 *    2. Redistributions in binary form must reproduce the above copyright notice, this list
 *       of conditions and the following disclaimer in the documentation and/or other materials
 *       provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY GARY COURT ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL GARY COURT OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * The views and conclusions contained in the software and documentation are those of the
 * authors and should not be interpreted as representing official policies, either expressed
 * or implied, of Gary Court.
 */




const SCHEMES = {};
function pctEncChar(chr) {
    const c = chr.charCodeAt(0);
    let e;
    if (c < 16)
        e = "%0" + c.toString(16).toUpperCase();
    else if (c < 128)
        e = "%" + c.toString(16).toUpperCase();
    else if (c < 2048)
        e = "%" + ((c >> 6) | 192).toString(16).toUpperCase() + "%" + ((c & 63) | 128).toString(16).toUpperCase();
    else
        e = "%" + ((c >> 12) | 224).toString(16).toUpperCase() + "%" + (((c >> 6) & 63) | 128).toString(16).toUpperCase() + "%" + ((c & 63) | 128).toString(16).toUpperCase();
    return e;
}
function pctDecChars(str) {
    let newStr = "";
    let i = 0;
    const il = str.length;
    while (i < il) {
        const c = parseInt(str.substr(i + 1, 2), 16);
        if (c < 128) {
            newStr += String.fromCharCode(c);
            i += 3;
        }
        else if (c >= 194 && c < 224) {
            if ((il - i) >= 6) {
                const c2 = parseInt(str.substr(i + 4, 2), 16);
                newStr += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
            }
            else {
                newStr += str.substr(i, 6);
            }
            i += 6;
        }
        else if (c >= 224) {
            if ((il - i) >= 9) {
                const c2 = parseInt(str.substr(i + 4, 2), 16);
                const c3 = parseInt(str.substr(i + 7, 2), 16);
                newStr += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
            }
            else {
                newStr += str.substr(i, 9);
            }
            i += 9;
        }
        else {
            newStr += str.substr(i, 3);
            i += 3;
        }
    }
    return newStr;
}
function _normalizeComponentEncoding(components, protocol) {
    function decodeUnreserved(str) {
        const decStr = pctDecChars(str);
        return (!decStr.match(protocol.UNRESERVED) ? str : decStr);
    }
    if (components.scheme)
        components.scheme = String(components.scheme).replace(protocol.PCT_ENCODED, decodeUnreserved).toLowerCase().replace(protocol.NOT_SCHEME, "");
    if (components.userinfo !== undefined)
        components.userinfo = String(components.userinfo).replace(protocol.PCT_ENCODED, decodeUnreserved).replace(protocol.NOT_USERINFO, pctEncChar).replace(protocol.PCT_ENCODED, _util__WEBPACK_IMPORTED_MODULE_3__.toUpperCase);
    if (components.host !== undefined)
        components.host = String(components.host).replace(protocol.PCT_ENCODED, decodeUnreserved).toLowerCase().replace(protocol.NOT_HOST, pctEncChar).replace(protocol.PCT_ENCODED, _util__WEBPACK_IMPORTED_MODULE_3__.toUpperCase);
    if (components.path !== undefined)
        components.path = String(components.path).replace(protocol.PCT_ENCODED, decodeUnreserved).replace((components.scheme ? protocol.NOT_PATH : protocol.NOT_PATH_NOSCHEME), pctEncChar).replace(protocol.PCT_ENCODED, _util__WEBPACK_IMPORTED_MODULE_3__.toUpperCase);
    if (components.query !== undefined)
        components.query = String(components.query).replace(protocol.PCT_ENCODED, decodeUnreserved).replace(protocol.NOT_QUERY, pctEncChar).replace(protocol.PCT_ENCODED, _util__WEBPACK_IMPORTED_MODULE_3__.toUpperCase);
    if (components.fragment !== undefined)
        components.fragment = String(components.fragment).replace(protocol.PCT_ENCODED, decodeUnreserved).replace(protocol.NOT_FRAGMENT, pctEncChar).replace(protocol.PCT_ENCODED, _util__WEBPACK_IMPORTED_MODULE_3__.toUpperCase);
    return components;
}
;
const URI_PARSE = /^(?:([^:\/?#]+):)?(?:\/\/((?:([^\/?#@]*)@)?(\[[\dA-F:.]+\]|[^\/?#:]*)(?:\:(\d*))?))?([^?#]*)(?:\?([^#]*))?(?:#((?:.|\n|\r)*))?/i;
const NO_MATCH_IS_UNDEFINED = ("").match(/(){0}/)[1] === undefined;
function parse(uriString, options = {}) {
    const components = {};
    const protocol = (options.iri !== false ? _regexps_iri__WEBPACK_IMPORTED_MODULE_1__["default"] : _regexps_uri__WEBPACK_IMPORTED_MODULE_0__["default"]);
    if (options.reference === "suffix")
        uriString = (options.scheme ? options.scheme + ":" : "") + "//" + uriString;
    const matches = uriString.match(URI_PARSE);
    if (matches) {
        if (NO_MATCH_IS_UNDEFINED) {
            //store each component
            components.scheme = matches[1];
            components.userinfo = matches[3];
            components.host = matches[4];
            components.port = parseInt(matches[5], 10);
            components.path = matches[6] || "";
            components.query = matches[7];
            components.fragment = matches[8];
            //fix port number
            if (isNaN(components.port)) {
                components.port = matches[5];
            }
        }
        else {
            //store each component
            components.scheme = matches[1] || undefined;
            components.userinfo = (uriString.indexOf("@") !== -1 ? matches[3] : undefined);
            components.host = (uriString.indexOf("//") !== -1 ? matches[4] : undefined);
            components.port = parseInt(matches[5], 10);
            components.path = matches[6] || "";
            components.query = (uriString.indexOf("?") !== -1 ? matches[7] : undefined);
            components.fragment = (uriString.indexOf("#") !== -1 ? matches[8] : undefined);
            //fix port number
            if (isNaN(components.port)) {
                components.port = (uriString.match(/\/\/(?:.|\n)*\:(?:\/|\?|\#|$)/) ? matches[4] : undefined);
            }
        }
        //strip brackets from IPv6 hosts
        if (components.host) {
            components.host = components.host.replace(protocol.IPV6ADDRESS, "$1");
        }
        //determine reference type
        if (components.scheme === undefined && components.userinfo === undefined && components.host === undefined && components.port === undefined && !components.path && components.query === undefined) {
            components.reference = "same-document";
        }
        else if (components.scheme === undefined) {
            components.reference = "relative";
        }
        else if (components.fragment === undefined) {
            components.reference = "absolute";
        }
        else {
            components.reference = "uri";
        }
        //check for reference errors
        if (options.reference && options.reference !== "suffix" && options.reference !== components.reference) {
            components.error = components.error || "URI is not a " + options.reference + " reference.";
        }
        //find scheme handler
        const schemeHandler = SCHEMES[(options.scheme || components.scheme || "").toLowerCase()];
        //check if scheme can't handle IRIs
        if (!options.unicodeSupport && (!schemeHandler || !schemeHandler.unicodeSupport)) {
            //if host component is a domain name
            if (components.host && (options.domainHost || (schemeHandler && schemeHandler.domainHost))) {
                //convert Unicode IDN -> ASCII IDN
                try {
                    components.host = punycode__WEBPACK_IMPORTED_MODULE_2__["default"].toASCII(components.host.replace(protocol.PCT_ENCODED, pctDecChars).toLowerCase());
                }
                catch (e) {
                    components.error = components.error || "Host's domain name can not be converted to ASCII via punycode: " + e;
                }
            }
            //convert IRI -> URI
            _normalizeComponentEncoding(components, _regexps_uri__WEBPACK_IMPORTED_MODULE_0__["default"]);
        }
        else {
            //normalize encodings
            _normalizeComponentEncoding(components, protocol);
        }
        //perform scheme specific parsing
        if (schemeHandler && schemeHandler.parse) {
            schemeHandler.parse(components, options);
        }
    }
    else {
        components.error = components.error || "URI can not be parsed.";
    }
    return components;
}
;
function _recomposeAuthority(components, options) {
    const protocol = (options.iri !== false ? _regexps_iri__WEBPACK_IMPORTED_MODULE_1__["default"] : _regexps_uri__WEBPACK_IMPORTED_MODULE_0__["default"]);
    const uriTokens = [];
    if (components.userinfo !== undefined) {
        uriTokens.push(components.userinfo);
        uriTokens.push("@");
    }
    if (components.host !== undefined) {
        //ensure IPv6 addresses are bracketed
        uriTokens.push(String(components.host).replace(protocol.IPV6ADDRESS, "[$1]"));
    }
    if (typeof components.port === "number") {
        uriTokens.push(":");
        uriTokens.push(components.port.toString(10));
    }
    return uriTokens.length ? uriTokens.join("") : undefined;
}
;
const RDS1 = /^\.\.?\//;
const RDS2 = /^\/\.(\/|$)/;
const RDS3 = /^\/\.\.(\/|$)/;
const RDS4 = /^\.\.?$/;
const RDS5 = /^\/?(?:.|\n)*?(?=\/|$)/;
function removeDotSegments(input) {
    const output = [];
    while (input.length) {
        if (input.match(RDS1)) {
            input = input.replace(RDS1, "");
        }
        else if (input.match(RDS2)) {
            input = input.replace(RDS2, "/");
        }
        else if (input.match(RDS3)) {
            input = input.replace(RDS3, "/");
            output.pop();
        }
        else if (input === "." || input === "..") {
            input = "";
        }
        else {
            const im = input.match(RDS5);
            if (im) {
                const s = im[0];
                input = input.slice(s.length);
                output.push(s);
            }
            else {
                throw new Error("Unexpected dot segment condition");
            }
        }
    }
    return output.join("");
}
;
function serialize(components, options = {}) {
    const protocol = (options.iri ? _regexps_iri__WEBPACK_IMPORTED_MODULE_1__["default"] : _regexps_uri__WEBPACK_IMPORTED_MODULE_0__["default"]);
    const uriTokens = [];
    //find scheme handler
    const schemeHandler = SCHEMES[(options.scheme || components.scheme || "").toLowerCase()];
    //perform scheme specific serialization
    if (schemeHandler && schemeHandler.serialize)
        schemeHandler.serialize(components, options);
    if (components.host) {
        //if host component is an IPv6 address
        if (protocol.IPV6ADDRESS.test(components.host)) {
            //TODO: normalize IPv6 address as per RFC 5952
        }
        else if (options.domainHost || (schemeHandler && schemeHandler.domainHost)) {
            //convert IDN via punycode
            try {
                components.host = (!options.iri ? punycode__WEBPACK_IMPORTED_MODULE_2__["default"].toASCII(components.host.replace(protocol.PCT_ENCODED, pctDecChars).toLowerCase()) : punycode__WEBPACK_IMPORTED_MODULE_2__["default"].toUnicode(components.host));
            }
            catch (e) {
                components.error = components.error || "Host's domain name can not be converted to " + (!options.iri ? "ASCII" : "Unicode") + " via punycode: " + e;
            }
        }
    }
    //normalize encoding
    _normalizeComponentEncoding(components, protocol);
    if (options.reference !== "suffix" && components.scheme) {
        uriTokens.push(components.scheme);
        uriTokens.push(":");
    }
    const authority = _recomposeAuthority(components, options);
    if (authority !== undefined) {
        if (options.reference !== "suffix") {
            uriTokens.push("//");
        }
        uriTokens.push(authority);
        if (components.path && components.path.charAt(0) !== "/") {
            uriTokens.push("/");
        }
    }
    if (components.path !== undefined) {
        let s = components.path;
        if (!options.absolutePath && (!schemeHandler || !schemeHandler.absolutePath)) {
            s = removeDotSegments(s);
        }
        if (authority === undefined) {
            s = s.replace(/^\/\//, "/%2F"); //don't allow the path to start with "//"
        }
        uriTokens.push(s);
    }
    if (components.query !== undefined) {
        uriTokens.push("?");
        uriTokens.push(components.query);
    }
    if (components.fragment !== undefined) {
        uriTokens.push("#");
        uriTokens.push(components.fragment);
    }
    return uriTokens.join(""); //merge tokens into a string
}
;
function resolveComponents(base, relative, options = {}, skipNormalization) {
    const target = {};
    if (!skipNormalization) {
        base = parse(serialize(base, options), options); //normalize base components
        relative = parse(serialize(relative, options), options); //normalize relative components
    }
    options = options || {};
    if (!options.tolerant && relative.scheme) {
        target.scheme = relative.scheme;
        //target.authority = relative.authority;
        target.userinfo = relative.userinfo;
        target.host = relative.host;
        target.port = relative.port;
        target.path = removeDotSegments(relative.path || "");
        target.query = relative.query;
    }
    else {
        if (relative.userinfo !== undefined || relative.host !== undefined || relative.port !== undefined) {
            //target.authority = relative.authority;
            target.userinfo = relative.userinfo;
            target.host = relative.host;
            target.port = relative.port;
            target.path = removeDotSegments(relative.path || "");
            target.query = relative.query;
        }
        else {
            if (!relative.path) {
                target.path = base.path;
                if (relative.query !== undefined) {
                    target.query = relative.query;
                }
                else {
                    target.query = base.query;
                }
            }
            else {
                if (relative.path.charAt(0) === "/") {
                    target.path = removeDotSegments(relative.path);
                }
                else {
                    if ((base.userinfo !== undefined || base.host !== undefined || base.port !== undefined) && !base.path) {
                        target.path = "/" + relative.path;
                    }
                    else if (!base.path) {
                        target.path = relative.path;
                    }
                    else {
                        target.path = base.path.slice(0, base.path.lastIndexOf("/") + 1) + relative.path;
                    }
                    target.path = removeDotSegments(target.path);
                }
                target.query = relative.query;
            }
            //target.authority = base.authority;
            target.userinfo = base.userinfo;
            target.host = base.host;
            target.port = base.port;
        }
        target.scheme = base.scheme;
    }
    target.fragment = relative.fragment;
    return target;
}
;
function resolve(baseURI, relativeURI, options) {
    return serialize(resolveComponents(parse(baseURI, options), parse(relativeURI, options), options, true), options);
}
;
function normalize(uri, options) {
    if (typeof uri === "string") {
        uri = serialize(parse(uri, options), options);
    }
    else if ((0,_util__WEBPACK_IMPORTED_MODULE_3__.typeOf)(uri) === "object") {
        uri = parse(serialize(uri, options), options);
    }
    return uri;
}
;
function equal(uriA, uriB, options) {
    if (typeof uriA === "string") {
        uriA = serialize(parse(uriA, options), options);
    }
    else if ((0,_util__WEBPACK_IMPORTED_MODULE_3__.typeOf)(uriA) === "object") {
        uriA = serialize(uriA, options);
    }
    if (typeof uriB === "string") {
        uriB = serialize(parse(uriB, options), options);
    }
    else if ((0,_util__WEBPACK_IMPORTED_MODULE_3__.typeOf)(uriB) === "object") {
        uriB = serialize(uriB, options);
    }
    return uriA === uriB;
}
;
function escapeComponent(str, options) {
    return str && str.toString().replace((!options || !options.iri ? _regexps_uri__WEBPACK_IMPORTED_MODULE_0__["default"].ESCAPE : _regexps_iri__WEBPACK_IMPORTED_MODULE_1__["default"].ESCAPE), pctEncChar);
}
;
function unescapeComponent(str, options) {
    return str && str.toString().replace((!options || !options.iri ? _regexps_uri__WEBPACK_IMPORTED_MODULE_0__["default"].PCT_ENCODED : _regexps_iri__WEBPACK_IMPORTED_MODULE_1__["default"].PCT_ENCODED), pctDecChars);
}
;
//# sourceMappingURL=uri.js.map

/***/ }),

/***/ "./node_modules/uri-js/dist/esnext/util.js":
/*!*************************************************!*\
  !*** ./node_modules/uri-js/dist/esnext/util.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   merge: () => (/* binding */ merge),
/* harmony export */   subexp: () => (/* binding */ subexp),
/* harmony export */   toArray: () => (/* binding */ toArray),
/* harmony export */   toUpperCase: () => (/* binding */ toUpperCase),
/* harmony export */   typeOf: () => (/* binding */ typeOf)
/* harmony export */ });
function merge(...sets) {
    if (sets.length > 1) {
        sets[0] = sets[0].slice(0, -1);
        const xl = sets.length - 1;
        for (let x = 1; x < xl; ++x) {
            sets[x] = sets[x].slice(1, -1);
        }
        sets[xl] = sets[xl].slice(1);
        return sets.join('');
    }
    else {
        return sets[0];
    }
}
function subexp(str) {
    return "(?:" + str + ")";
}
function typeOf(o) {
    return o === undefined ? "undefined" : (o === null ? "null" : Object.prototype.toString.call(o).split(" ").pop().split("]").shift().toLowerCase());
}
function toUpperCase(str) {
    return str.toUpperCase();
}
function toArray(obj) {
    return obj !== undefined && obj !== null ? (obj instanceof Array ? obj : (typeof obj.length !== "number" || obj.split || obj.setInterval || obj.call ? [obj] : Array.prototype.slice.call(obj))) : [];
}
//# sourceMappingURL=util.js.map

/***/ }),

/***/ "./src/mymonero-utils/ResponseParser.js":
/*!**********************************************!*\
  !*** ./src/mymonero-utils/ResponseParser.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
// This has been taken from @mymonero/mymonero-response-parser-utils v2.0.0
// We have made the "__sync" methods async and deleted the rest.

// Copyright (c) 2014-2019, MyMonero.com
//
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without modification, are
// permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice, this list of
//	conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright notice, this list
//	of conditions and the following disclaimer in the documentation and/or other
//	materials provided with the distribution.
//
// 3. Neither the name of the copyright holder nor the names of its contributors may be
//	used to endorse or promote products derived from this software without specific
//	prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
// THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
// STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
// THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

//
const JSBigInt = (__webpack_require__(/*! @mymonero/mymonero-bigint */ "./node_modules/@mymonero/mymonero-bigint/index.js").BigInteger)
const monero_amount_format_utils = __webpack_require__(/*! @mymonero/mymonero-money-format */ "./node_modules/@mymonero/mymonero-money-format/index.js")
const monero_keyImage_cache_utils = __webpack_require__(/*! ./mymonero-keyimage-cache.js */ "./src/mymonero-utils/mymonero-keyimage-cache.js")
//
async function Parsed_AddressInfo__async (
  keyImage_cache,
  data,
  address,
  view_key__private,
  spend_key__public,
  spend_key__private,
  coreBridge_instance
) {
  // -> returnValuesByKey
  const total_received = new JSBigInt(data.total_received || 0)
  const locked_balance = new JSBigInt(data.locked_funds || 0)
  var total_sent = new JSBigInt(data.total_sent || 0) // will be modified in place
  //
  const account_scanned_tx_height = data.scanned_height || 0
  const account_scanned_block_height = data.scanned_block_height || 0
  const account_scan_start_height = data.start_height || 0
  const transaction_height = data.transaction_height || 0
  const blockchain_height = data.blockchain_height || 0
  const spent_outputs = data.spent_outputs || []
  //
  for (let spent_output of spent_outputs) {
    var key_image = await monero_keyImage_cache_utils.Lazy_KeyImage(
      keyImage_cache,
      spent_output.tx_pub_key,
      spent_output.out_index,
      address,
      view_key__private,
      spend_key__public,
      spend_key__private,
      coreBridge_instance
    )
    if (spent_output.key_image !== key_image) {
      // console.log('💬  Output used as mixin (' + spent_output.key_image + '/' + key_image + ')')
      total_sent = new JSBigInt(total_sent).subtract(spent_output.amount)
    }
  }
  //
  const ratesBySymbol = data.rates || {} // jic it's not there
  //
  const returnValuesByKey = {
    total_received_String: total_received
      ? total_received.toString()
      : null,
    locked_balance_String: locked_balance
      ? locked_balance.toString()
      : null,
    total_sent_String: total_sent ? total_sent.toString() : null,
    // ^serialized JSBigInt
    spent_outputs: spent_outputs,
    account_scanned_tx_height: account_scanned_tx_height,
    account_scanned_block_height: account_scanned_block_height,
    account_scan_start_height: account_scan_start_height,
    transaction_height: transaction_height,
    blockchain_height: blockchain_height,
    //
    ratesBySymbol: ratesBySymbol
  }
  return returnValuesByKey
}
exports.Parsed_AddressInfo__async = Parsed_AddressInfo__async
//
async function Parsed_AddressTransactions__async (
  keyImage_cache,
  data,
  address,
  view_key__private,
  spend_key__public,
  spend_key__private,
  coreBridge_instance
) {
  const account_scanned_height = data.scanned_height || 0
  const account_scanned_block_height = data.scanned_block_height || 0
  const account_scan_start_height = data.start_height || 0
  const transaction_height = data.transaction_height || 0
  const blockchain_height = data.blockchain_height || 0
  //
  const transactions = data.transactions || []
  //
  // TODO: rewrite this with more clarity if possible
  for (let i = 0; i < transactions.length; ++i) {
    if ((transactions[i].spent_outputs || []).length > 0) {
      for (var j = 0; j < transactions[i].spent_outputs.length; ++j) {
        var key_image = await monero_keyImage_cache_utils.Lazy_KeyImage(
          keyImage_cache,
          transactions[i].spent_outputs[j].tx_pub_key,
          transactions[i].spent_outputs[j].out_index,
          address,
          view_key__private,
          spend_key__public,
          spend_key__private,
          coreBridge_instance
        )
        if (transactions[i].spent_outputs[j].key_image !== key_image) {
          // console.log('Output used as mixin, ignoring (' + transactions[i].spent_outputs[j].key_image + '/' + key_image + ')')
          transactions[i].total_sent = new JSBigInt(
            transactions[i].total_sent
          )
            .subtract(transactions[i].spent_outputs[j].amount)
            .toString()
          transactions[i].spent_outputs.splice(j, 1)
          j--
        }
      }
    }
    if (
      new JSBigInt(transactions[i].total_received || 0)
        .add(transactions[i].total_sent || 0)
        .compare(0) <= 0
    ) {
      transactions.splice(i, 1)
      i--
      continue
    }
    transactions[i].amount = new JSBigInt(
      transactions[i].total_received || 0
    )
      .subtract(transactions[i].total_sent || 0)
      .toString()
    transactions[i].approx_float_amount = parseFloat(
      monero_amount_format_utils.formatMoney(transactions[i].amount)
    )
    transactions[i].timestamp = transactions[i].timestamp
    const record__payment_id = transactions[i].payment_id
    if (typeof record__payment_id !== 'undefined' && record__payment_id) {
      if (record__payment_id.length == 16) {
        // short (encrypted) pid
        if (transactions[i].approx_float_amount < 0) {
          // outgoing
          delete transactions[i]['payment_id'] // need to filter these out .. because the server can't filter out short (encrypted) pids on outgoing txs
        }
      }
    }
  }
  transactions.sort(function (a, b) {
    if (a.mempool == true) {
      if (b.mempool != true) {
        return -1 // a first
      }
      // both mempool - fall back to .id compare
    } else if (b.mempool == true) {
      return 1 // b first
    }
    return b.id - a.id
  })
  // prepare transactions to be serialized
  for (let transaction of transactions) {
    transaction.amount = transaction.amount.toString() // JSBigInt -> String
    if (
      typeof transaction.total_sent !== 'undefined' &&
			transaction.total_sent !== null
    ) {
      transaction.total_sent = transaction.total_sent.toString()
    }
  }
  // on the other side, we convert transactions timestamp to Date obj
  const returnValuesByKey = {
    account_scanned_height: account_scanned_height,
    account_scanned_block_height: account_scanned_block_height,
    account_scan_start_height: account_scan_start_height,
    transaction_height: transaction_height,
    blockchain_height: blockchain_height,
    serialized_transactions: transactions
  }
  return returnValuesByKey
}
exports.Parsed_AddressTransactions__async = Parsed_AddressTransactions__async


/***/ }),

/***/ "./src/mymonero-utils/mymonero-keyimage-cache.js":
/*!*******************************************************!*\
  !*** ./src/mymonero-utils/mymonero-keyimage-cache.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";
// This has been taken from @mymonero/mymonero-keyimage-cache v2.0.0
// We have made `Lazy_KeyImage` async and deleted the rest.
// We have also renamed generate_key_image to generateKeyImage.



const Lazy_KeyImage = async function (
  mutable_keyImagesByCacheKey, // pass a mutable JS dictionary
  tx_pub_key,
  out_index,
  public_address,
  view_key__private,
  spend_key__public,
  spend_key__private,
  coreBridge_instance // must pass this so this fn can remain synchronous
) {
  var cache_index = tx_pub_key + ':' + public_address + ':' + out_index
  const cached__key_image = mutable_keyImagesByCacheKey[cache_index]
  if (
    typeof cached__key_image !== 'undefined' &&
		cached__key_image !== null
  ) {
    return cached__key_image
  }
  var key_image = await coreBridge_instance.generateKeyImage(
    tx_pub_key,
    view_key__private,
    spend_key__public,
    spend_key__private,
    out_index
  )
  // cache:
  mutable_keyImagesByCacheKey[cache_index] = key_image
  //
  return key_image
}
exports.Lazy_KeyImage = Lazy_KeyImage


/***/ }),

/***/ "./node_modules/rfc4648/lib/cjs/rfc4648.js":
/*!*************************************************!*\
  !*** ./node_modules/rfc4648/lib/cjs/rfc4648.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({ value: true }));

/* eslint-disable @typescript-eslint/strict-boolean-expressions */
function parse(string, encoding, opts) {
  var _opts$out;

  if (opts === void 0) {
    opts = {};
  }

  // Build the character lookup table:
  if (!encoding.codes) {
    encoding.codes = {};

    for (var i = 0; i < encoding.chars.length; ++i) {
      encoding.codes[encoding.chars[i]] = i;
    }
  } // The string must have a whole number of bytes:


  if (!opts.loose && string.length * encoding.bits & 7) {
    throw new SyntaxError('Invalid padding');
  } // Count the padding bytes:


  var end = string.length;

  while (string[end - 1] === '=') {
    --end; // If we get a whole number of bytes, there is too much padding:

    if (!opts.loose && !((string.length - end) * encoding.bits & 7)) {
      throw new SyntaxError('Invalid padding');
    }
  } // Allocate the output:


  var out = new ((_opts$out = opts.out) != null ? _opts$out : Uint8Array)(end * encoding.bits / 8 | 0); // Parse the data:

  var bits = 0; // Number of bits currently in the buffer

  var buffer = 0; // Bits waiting to be written out, MSB first

  var written = 0; // Next byte to write

  for (var _i = 0; _i < end; ++_i) {
    // Read one character from the string:
    var value = encoding.codes[string[_i]];

    if (value === undefined) {
      throw new SyntaxError('Invalid character ' + string[_i]);
    } // Append the bits to the buffer:


    buffer = buffer << encoding.bits | value;
    bits += encoding.bits; // Write out some bits if the buffer has a byte's worth:

    if (bits >= 8) {
      bits -= 8;
      out[written++] = 0xff & buffer >> bits;
    }
  } // Verify that we have received just enough bits:


  if (bits >= encoding.bits || 0xff & buffer << 8 - bits) {
    throw new SyntaxError('Unexpected end of data');
  }

  return out;
}
function stringify(data, encoding, opts) {
  if (opts === void 0) {
    opts = {};
  }

  var _opts = opts,
      _opts$pad = _opts.pad,
      pad = _opts$pad === void 0 ? true : _opts$pad;
  var mask = (1 << encoding.bits) - 1;
  var out = '';
  var bits = 0; // Number of bits currently in the buffer

  var buffer = 0; // Bits waiting to be written out, MSB first

  for (var i = 0; i < data.length; ++i) {
    // Slurp data into the buffer:
    buffer = buffer << 8 | 0xff & data[i];
    bits += 8; // Write out as much as we can:

    while (bits > encoding.bits) {
      bits -= encoding.bits;
      out += encoding.chars[mask & buffer >> bits];
    }
  } // Partial character:


  if (bits) {
    out += encoding.chars[mask & buffer << encoding.bits - bits];
  } // Add padding characters until we hit a byte boundary:


  if (pad) {
    while (out.length * encoding.bits & 7) {
      out += '=';
    }
  }

  return out;
}

/* eslint-disable @typescript-eslint/strict-boolean-expressions */
var base16Encoding = {
  chars: '0123456789ABCDEF',
  bits: 4
};
var base32Encoding = {
  chars: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567',
  bits: 5
};
var base32HexEncoding = {
  chars: '0123456789ABCDEFGHIJKLMNOPQRSTUV',
  bits: 5
};
var base64Encoding = {
  chars: 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',
  bits: 6
};
var base64UrlEncoding = {
  chars: 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_',
  bits: 6
};
var base16 = {
  parse: function parse$1(string, opts) {
    return parse(string.toUpperCase(), base16Encoding, opts);
  },
  stringify: function stringify$1(data, opts) {
    return stringify(data, base16Encoding, opts);
  }
};
var base32 = {
  parse: function parse$1(string, opts) {
    if (opts === void 0) {
      opts = {};
    }

    return parse(opts.loose ? string.toUpperCase().replace(/0/g, 'O').replace(/1/g, 'L').replace(/8/g, 'B') : string, base32Encoding, opts);
  },
  stringify: function stringify$1(data, opts) {
    return stringify(data, base32Encoding, opts);
  }
};
var base32hex = {
  parse: function parse$1(string, opts) {
    return parse(string, base32HexEncoding, opts);
  },
  stringify: function stringify$1(data, opts) {
    return stringify(data, base32HexEncoding, opts);
  }
};
var base64 = {
  parse: function parse$1(string, opts) {
    return parse(string, base64Encoding, opts);
  },
  stringify: function stringify$1(data, opts) {
    return stringify(data, base64Encoding, opts);
  }
};
var base64url = {
  parse: function parse$1(string, opts) {
    return parse(string, base64UrlEncoding, opts);
  },
  stringify: function stringify$1(data, opts) {
    return stringify(data, base64UrlEncoding, opts);
  }
};
var codec = {
  parse: parse,
  stringify: stringify
};

exports.base16 = base16;
exports.base32 = base32;
exports.base32hex = base32hex;
exports.base64 = base64;
exports.base64url = base64url;
exports.codec = codec;


/***/ }),

/***/ "./node_modules/cleaners/lib/esm/cleaners.js":
/*!***************************************************!*\
  !*** ./node_modules/cleaners/lib/esm/cleaners.js ***!
  \***************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   asArray: () => (/* binding */ asArray),
/* harmony export */   asBoolean: () => (/* binding */ asBoolean),
/* harmony export */   asCodec: () => (/* binding */ asCodec),
/* harmony export */   asDate: () => (/* binding */ asDate),
/* harmony export */   asEither: () => (/* binding */ asEither),
/* harmony export */   asJSON: () => (/* binding */ asJSON),
/* harmony export */   asMap: () => (/* binding */ asMap),
/* harmony export */   asMaybe: () => (/* binding */ asMaybe),
/* harmony export */   asNone: () => (/* binding */ asNone),
/* harmony export */   asNull: () => (/* binding */ asNull),
/* harmony export */   asNumber: () => (/* binding */ asNumber),
/* harmony export */   asObject: () => (/* binding */ asObject),
/* harmony export */   asOptional: () => (/* binding */ asOptional),
/* harmony export */   asString: () => (/* binding */ asString),
/* harmony export */   asTuple: () => (/* binding */ asTuple),
/* harmony export */   asUndefined: () => (/* binding */ asUndefined),
/* harmony export */   asUnknown: () => (/* binding */ asUnknown),
/* harmony export */   asValue: () => (/* binding */ asValue),
/* harmony export */   uncleaner: () => (/* binding */ uncleaner)
/* harmony export */ });
/**
 * Given a JS value, produce a descriptive string.
 */
function showValue(value) {
  switch (typeof value) {
    case 'function':
    case 'object':
      if (value == null) return 'null';
      if (Array.isArray(value)) return 'array';
      return typeof value;

    case 'string':
      return JSON.stringify(value);

    default:
      return String(value);
  }
}

function asOptional(cleaner, fallback) {
  return function asOptional(raw) {
    return raw != null ? cleaner(raw) : typeof fallback === 'function' ? fallback() : fallback;
  };
}

function asValue() {
  for (var _len = arguments.length, values = new Array(_len), _key = 0; _key < _len; _key++) {
    values[_key] = arguments[_key];
  }

  return function asValue(raw) {
    for (var i = 0; i < values.length; ++i) {
      if (raw === values[i]) return raw;
    } // Create a fancy error message:


    var message = 'Expected ';
    if (values.length !== 1) message += 'one of: ';

    for (var _i = 0; _i < values.length; ++_i) {
      if (_i > 0) message += ' | ';
      message += JSON.stringify(values[_i]);
    }

    message += ', got ' + showValue(raw);
    throw new TypeError(message);
  };
}

function asBoolean(raw) {
  if (typeof raw !== 'boolean') {
    throw new TypeError('Expected a boolean, got ' + showValue(raw));
  }

  return raw;
}
function asNumber(raw) {
  if (typeof raw !== 'number') {
    throw new TypeError('Expected a number, got ' + showValue(raw));
  }

  return raw;
}
function asString(raw) {
  if (typeof raw !== 'string') {
    throw new TypeError('Expected a string, got ' + showValue(raw));
  }

  return raw;
}
var asNull = asValue(null);
var asUndefined = asValue(undefined);
function asUnknown(raw) {
  return raw;
} // Deprecated:

var asNone = asOptional(asNull);

/**
 * Adds location information to an error message.
 *
 * Errors can occur inside deeply-nested cleaners,
 * such as "TypeError: Expected a string at .array[0].some.property".
 * To build this information, each cleaner along the path
 * should add its own location information as the stack unwinds.
 *
 * If the error has a `insertStepAt` property, that is the character offset
 * where the next step will go in the error message. Otherwise,
 * the next step just goes on the end of the string with the word "at".
 */
function locateError(error, step, offset) {
  if (error instanceof Error) {
    if (error.insertStepAt == null) {
      error.message += ' at ';
      error.insertStepAt = error.message.length;
    }

    error.message = error.message.slice(0, error.insertStepAt) + step + error.message.slice(error.insertStepAt);
    error.insertStepAt += offset;
  }

  return error;
}

function asArray(cleaner) {
  return function asArray(raw) {
    if (!Array.isArray(raw)) {
      throw new TypeError('Expected an array, got ' + showValue(raw));
    }

    var out = [];

    for (var i = 0; i < raw.length; ++i) {
      try {
        out[i] = cleaner(raw[i]);
      } catch (error) {
        throw locateError(error, '[' + i + ']', 0);
      }
    }

    return out;
  };
}

function asObject(shape) {
  // The key-value version:
  if (typeof shape === 'function') {
    return function asObject(raw) {
      if (typeof raw !== 'object' || raw == null) {
        throw new TypeError('Expected an object, got ' + showValue(raw));
      }

      var out = {};
      var keys = Object.keys(raw);

      for (var i = 0; i < keys.length; ++i) {
        var key = keys[i];
        if (key === '__proto__') continue;

        try {
          out[key] = shape(raw[key]);
        } catch (error) {
          throw locateError(error, '[' + JSON.stringify(key) + ']', 0);
        }
      }

      return out;
    };
  } // The shape-aware version:


  var keys = Object.keys(shape);

  function bindObjectShape(keepRest) {
    return function asObject(raw) {
      if (typeof raw !== 'object' || raw == null) {
        throw new TypeError('Expected an object, got ' + showValue(raw));
      }

      var i;
      var out = {};

      if (keepRest) {
        var toCopy = Object.keys(raw);

        for (i = 0; i < toCopy.length; ++i) {
          var key = toCopy[i];
          if (key === '__proto__') continue;
          out[key] = raw[key];
        }
      }

      for (i = 0; i < keys.length; ++i) {
        var _key = keys[i];

        try {
          out[_key] = shape[_key](raw[_key]);
        } catch (error) {
          throw locateError(error, '.' + _key, 0);
        }
      }

      return out;
    };
  }

  var out = bindObjectShape(false);
  out.shape = shape;
  out.withRest = bindObjectShape(true);
  return out;
} // Deprecated:

var asMap = asObject;

function asTuple() {
  for (var _len = arguments.length, shape = new Array(_len), _key = 0; _key < _len; _key++) {
    shape[_key] = arguments[_key];
  }

  function asTuple(raw) {
    if (!Array.isArray(raw)) {
      throw new TypeError('Expected an array, got ' + showValue(raw));
    }

    var out = [];

    for (var i = 0; i < shape.length; ++i) {
      try {
        out[i] = shape[i](raw[i]);
      } catch (error) {
        throw locateError(error, "[" + i + "]");
      }
    }

    return out;
  }

  return asTuple;
}

function asEither() {
  for (var _len = arguments.length, shape = new Array(_len), _key = 0; _key < _len; _key++) {
    shape[_key] = arguments[_key];
  }

  return function asEither(raw) {
    for (var i = 0; i < shape.length; i++) {
      try {
        return shape[i](raw);
      } catch (error) {
        if (i + 1 >= shape.length) throw error;
      }
    }
  };
}

function asMaybe(cleaner, fallback) {
  return function asMaybe(raw) {
    try {
      return cleaner(raw);
    } catch (e) {
      return typeof fallback === 'function' ? fallback() : fallback;
    }
  };
}

function asCodec(cleaner, uncleaner) {
  return function asCodec(raw) {
    return global[uncleaning] > 0 ? uncleaner(raw) : cleaner(raw);
  };
}
function uncleaner(cleaner) {
  return function uncleaner(raw) {
    // We need to set a flag to indicate that we are un-cleaning.
    // The flag needs to be in a global location,
    // since multiple cleaner implementations should agree
    // which mode we are in.
    if (global[uncleaning] == null) {
      Object.defineProperty(global, uncleaning, {
        value: 0,
        writable: true
      });
    }

    try {
      ++global[uncleaning];
      return cleaner(raw);
    } finally {
      --global[uncleaning];
    }
  };
} // If we cannot find the standardized "globalThis" object,
// fall back on using the "JSON" constructor, which is also well-known.

var global = typeof globalThis === 'object' && globalThis != null ? globalThis : JSON;
/* istanbul ignore next */

var uncleaning = typeof Symbol === 'function' ? Symbol["for"]('uncleaning') : 'uncleaning';

var asDate = asCodec(function asDate(raw) {
  if (typeof raw !== 'string' && !(raw instanceof Date)) {
    throw new TypeError('Expected a date string, got ' + showValue(raw));
  }

  var out = new Date(raw);

  if (out.toJSON() == null) {
    throw new TypeError('Invalid date format, got ' + showValue(raw));
  }

  return out;
}, function wasDate(clean) {
  return clean.toISOString();
});

function asJSON(cleaner) {
  return asCodec(function asJSON(raw) {
    var value = JSON.parse(asString(raw));

    try {
      return cleaner(value);
    } catch (error) {
      throw locateError(error, 'JSON.parse()', 11);
    }
  }, function wasJSON(clean) {
    return JSON.stringify(cleaner(clean));
  });
}




/***/ }),

/***/ "./node_modules/edge-core-js/types.mjs":
/*!*********************************************!*\
  !*** ./node_modules/edge-core-js/types.mjs ***!
  \*********************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChallengeError: () => (/* binding */ ChallengeError),
/* harmony export */   DustSpendError: () => (/* binding */ DustSpendError),
/* harmony export */   InsufficientFundsError: () => (/* binding */ InsufficientFundsError),
/* harmony export */   NetworkError: () => (/* binding */ NetworkError),
/* harmony export */   NoAmountSpecifiedError: () => (/* binding */ NoAmountSpecifiedError),
/* harmony export */   ObsoleteApiError: () => (/* binding */ ObsoleteApiError),
/* harmony export */   OtpError: () => (/* binding */ OtpError),
/* harmony export */   PasswordError: () => (/* binding */ PasswordError),
/* harmony export */   PendingFundsError: () => (/* binding */ PendingFundsError),
/* harmony export */   SameCurrencyError: () => (/* binding */ SameCurrencyError),
/* harmony export */   SpendToSelfError: () => (/* binding */ SpendToSelfError),
/* harmony export */   SwapAboveLimitError: () => (/* binding */ SwapAboveLimitError),
/* harmony export */   SwapBelowLimitError: () => (/* binding */ SwapBelowLimitError),
/* harmony export */   SwapCurrencyError: () => (/* binding */ SwapCurrencyError),
/* harmony export */   SwapPermissionError: () => (/* binding */ SwapPermissionError),
/* harmony export */   UsernameError: () => (/* binding */ UsernameError),
/* harmony export */   asBase16: () => (/* binding */ asBase16),
/* harmony export */   asBase32: () => (/* binding */ asBase32),
/* harmony export */   asBase64: () => (/* binding */ asBase64),
/* harmony export */   asChallengeErrorPayload: () => (/* binding */ asChallengeErrorPayload),
/* harmony export */   asChangeOtpPayload: () => (/* binding */ asChangeOtpPayload),
/* harmony export */   asChangePasswordPayload: () => (/* binding */ asChangePasswordPayload),
/* harmony export */   asChangePin2IdPayload: () => (/* binding */ asChangePin2IdPayload),
/* harmony export */   asChangePin2Payload: () => (/* binding */ asChangePin2Payload),
/* harmony export */   asChangeRecovery2IdPayload: () => (/* binding */ asChangeRecovery2IdPayload),
/* harmony export */   asChangeRecovery2Payload: () => (/* binding */ asChangeRecovery2Payload),
/* harmony export */   asChangeSecretPayload: () => (/* binding */ asChangeSecretPayload),
/* harmony export */   asChangeUsernamePayload: () => (/* binding */ asChangeUsernamePayload),
/* harmony export */   asChangeVouchersPayload: () => (/* binding */ asChangeVouchersPayload),
/* harmony export */   asCreateChallengePayload: () => (/* binding */ asCreateChallengePayload),
/* harmony export */   asCreateKeysPayload: () => (/* binding */ asCreateKeysPayload),
/* harmony export */   asCreateLoginPayload: () => (/* binding */ asCreateLoginPayload),
/* harmony export */   asEdgeBox: () => (/* binding */ asEdgeBox),
/* harmony export */   asEdgeKeyBox: () => (/* binding */ asEdgeKeyBox),
/* harmony export */   asEdgeLobbyReply: () => (/* binding */ asEdgeLobbyReply),
/* harmony export */   asEdgeLobbyRequest: () => (/* binding */ asEdgeLobbyRequest),
/* harmony export */   asEdgeLoginDump: () => (/* binding */ asEdgeLoginDump),
/* harmony export */   asEdgePendingVoucher: () => (/* binding */ asEdgePendingVoucher),
/* harmony export */   asEdgeRepoDump: () => (/* binding */ asEdgeRepoDump),
/* harmony export */   asEdgeSnrp: () => (/* binding */ asEdgeSnrp),
/* harmony export */   asEdgeVoucherDump: () => (/* binding */ asEdgeVoucherDump),
/* harmony export */   asLobbyPayload: () => (/* binding */ asLobbyPayload),
/* harmony export */   asLoginPayload: () => (/* binding */ asLoginPayload),
/* harmony export */   asLoginRequestBody: () => (/* binding */ asLoginRequestBody),
/* harmony export */   asLoginResponseBody: () => (/* binding */ asLoginResponseBody),
/* harmony export */   asMaybeChallengeError: () => (/* binding */ asMaybeChallengeError),
/* harmony export */   asMaybeDustSpendError: () => (/* binding */ asMaybeDustSpendError),
/* harmony export */   asMaybeInsufficientFundsError: () => (/* binding */ asMaybeInsufficientFundsError),
/* harmony export */   asMaybeNetworkError: () => (/* binding */ asMaybeNetworkError),
/* harmony export */   asMaybeNoAmountSpecifiedError: () => (/* binding */ asMaybeNoAmountSpecifiedError),
/* harmony export */   asMaybeObsoleteApiError: () => (/* binding */ asMaybeObsoleteApiError),
/* harmony export */   asMaybeOtpError: () => (/* binding */ asMaybeOtpError),
/* harmony export */   asMaybePasswordError: () => (/* binding */ asMaybePasswordError),
/* harmony export */   asMaybePendingFundsError: () => (/* binding */ asMaybePendingFundsError),
/* harmony export */   asMaybeSameCurrencyError: () => (/* binding */ asMaybeSameCurrencyError),
/* harmony export */   asMaybeSpendToSelfError: () => (/* binding */ asMaybeSpendToSelfError),
/* harmony export */   asMaybeSwapAboveLimitError: () => (/* binding */ asMaybeSwapAboveLimitError),
/* harmony export */   asMaybeSwapBelowLimitError: () => (/* binding */ asMaybeSwapBelowLimitError),
/* harmony export */   asMaybeSwapCurrencyError: () => (/* binding */ asMaybeSwapCurrencyError),
/* harmony export */   asMaybeSwapPermissionError: () => (/* binding */ asMaybeSwapPermissionError),
/* harmony export */   asMaybeUsernameError: () => (/* binding */ asMaybeUsernameError),
/* harmony export */   asMessagesPayload: () => (/* binding */ asMessagesPayload),
/* harmony export */   asOtpErrorPayload: () => (/* binding */ asOtpErrorPayload),
/* harmony export */   asOtpResetPayload: () => (/* binding */ asOtpResetPayload),
/* harmony export */   asPasswordErrorPayload: () => (/* binding */ asPasswordErrorPayload),
/* harmony export */   asRecovery2Auth: () => (/* binding */ asRecovery2Auth),
/* harmony export */   asRecovery2InfoPayload: () => (/* binding */ asRecovery2InfoPayload),
/* harmony export */   asUsernameInfoPayload: () => (/* binding */ asUsernameInfoPayload),
/* harmony export */   wasChallengeErrorPayload: () => (/* binding */ wasChallengeErrorPayload),
/* harmony export */   wasChangeOtpPayload: () => (/* binding */ wasChangeOtpPayload),
/* harmony export */   wasChangePasswordPayload: () => (/* binding */ wasChangePasswordPayload),
/* harmony export */   wasChangePin2IdPayload: () => (/* binding */ wasChangePin2IdPayload),
/* harmony export */   wasChangePin2Payload: () => (/* binding */ wasChangePin2Payload),
/* harmony export */   wasChangeRecovery2IdPayload: () => (/* binding */ wasChangeRecovery2IdPayload),
/* harmony export */   wasChangeRecovery2Payload: () => (/* binding */ wasChangeRecovery2Payload),
/* harmony export */   wasChangeSecretPayload: () => (/* binding */ wasChangeSecretPayload),
/* harmony export */   wasChangeUsernamePayload: () => (/* binding */ wasChangeUsernamePayload),
/* harmony export */   wasChangeVouchersPayload: () => (/* binding */ wasChangeVouchersPayload),
/* harmony export */   wasCreateChallengePayload: () => (/* binding */ wasCreateChallengePayload),
/* harmony export */   wasCreateKeysPayload: () => (/* binding */ wasCreateKeysPayload),
/* harmony export */   wasCreateLoginPayload: () => (/* binding */ wasCreateLoginPayload),
/* harmony export */   wasEdgeBox: () => (/* binding */ wasEdgeBox),
/* harmony export */   wasEdgeLobbyReply: () => (/* binding */ wasEdgeLobbyReply),
/* harmony export */   wasEdgeLobbyRequest: () => (/* binding */ wasEdgeLobbyRequest),
/* harmony export */   wasEdgeLoginDump: () => (/* binding */ wasEdgeLoginDump),
/* harmony export */   wasEdgeRepoDump: () => (/* binding */ wasEdgeRepoDump),
/* harmony export */   wasLobbyPayload: () => (/* binding */ wasLobbyPayload),
/* harmony export */   wasLoginPayload: () => (/* binding */ wasLoginPayload),
/* harmony export */   wasLoginRequestBody: () => (/* binding */ wasLoginRequestBody),
/* harmony export */   wasLoginResponseBody: () => (/* binding */ wasLoginResponseBody),
/* harmony export */   wasMessagesPayload: () => (/* binding */ wasMessagesPayload),
/* harmony export */   wasOtpErrorPayload: () => (/* binding */ wasOtpErrorPayload),
/* harmony export */   wasOtpResetPayload: () => (/* binding */ wasOtpResetPayload),
/* harmony export */   wasPasswordErrorPayload: () => (/* binding */ wasPasswordErrorPayload),
/* harmony export */   wasRecovery2InfoPayload: () => (/* binding */ wasRecovery2InfoPayload),
/* harmony export */   wasUsernameInfoPayload: () => (/* binding */ wasUsernameInfoPayload)
/* harmony export */ });
/* harmony import */ var _types_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./types.js */ "./node_modules/edge-core-js/types.js");
// Generated by rollup-plugin-mjs-entry



const ChallengeError = _types_js__WEBPACK_IMPORTED_MODULE_0__.ChallengeError;
const DustSpendError = _types_js__WEBPACK_IMPORTED_MODULE_0__.DustSpendError;
const InsufficientFundsError = _types_js__WEBPACK_IMPORTED_MODULE_0__.InsufficientFundsError;
const NetworkError = _types_js__WEBPACK_IMPORTED_MODULE_0__.NetworkError;
const NoAmountSpecifiedError = _types_js__WEBPACK_IMPORTED_MODULE_0__.NoAmountSpecifiedError;
const ObsoleteApiError = _types_js__WEBPACK_IMPORTED_MODULE_0__.ObsoleteApiError;
const OtpError = _types_js__WEBPACK_IMPORTED_MODULE_0__.OtpError;
const PasswordError = _types_js__WEBPACK_IMPORTED_MODULE_0__.PasswordError;
const PendingFundsError = _types_js__WEBPACK_IMPORTED_MODULE_0__.PendingFundsError;
const SameCurrencyError = _types_js__WEBPACK_IMPORTED_MODULE_0__.SameCurrencyError;
const SpendToSelfError = _types_js__WEBPACK_IMPORTED_MODULE_0__.SpendToSelfError;
const SwapAboveLimitError = _types_js__WEBPACK_IMPORTED_MODULE_0__.SwapAboveLimitError;
const SwapBelowLimitError = _types_js__WEBPACK_IMPORTED_MODULE_0__.SwapBelowLimitError;
const SwapCurrencyError = _types_js__WEBPACK_IMPORTED_MODULE_0__.SwapCurrencyError;
const SwapPermissionError = _types_js__WEBPACK_IMPORTED_MODULE_0__.SwapPermissionError;
const UsernameError = _types_js__WEBPACK_IMPORTED_MODULE_0__.UsernameError;
const asBase16 = _types_js__WEBPACK_IMPORTED_MODULE_0__.asBase16;
const asBase32 = _types_js__WEBPACK_IMPORTED_MODULE_0__.asBase32;
const asBase64 = _types_js__WEBPACK_IMPORTED_MODULE_0__.asBase64;
const asChallengeErrorPayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.asChallengeErrorPayload;
const asChangeOtpPayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.asChangeOtpPayload;
const asChangePasswordPayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.asChangePasswordPayload;
const asChangePin2IdPayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.asChangePin2IdPayload;
const asChangePin2Payload = _types_js__WEBPACK_IMPORTED_MODULE_0__.asChangePin2Payload;
const asChangeRecovery2IdPayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.asChangeRecovery2IdPayload;
const asChangeRecovery2Payload = _types_js__WEBPACK_IMPORTED_MODULE_0__.asChangeRecovery2Payload;
const asChangeSecretPayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.asChangeSecretPayload;
const asChangeUsernamePayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.asChangeUsernamePayload;
const asChangeVouchersPayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.asChangeVouchersPayload;
const asCreateChallengePayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.asCreateChallengePayload;
const asCreateKeysPayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.asCreateKeysPayload;
const asCreateLoginPayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.asCreateLoginPayload;
const asEdgeBox = _types_js__WEBPACK_IMPORTED_MODULE_0__.asEdgeBox;
const asEdgeKeyBox = _types_js__WEBPACK_IMPORTED_MODULE_0__.asEdgeKeyBox;
const asEdgeLobbyReply = _types_js__WEBPACK_IMPORTED_MODULE_0__.asEdgeLobbyReply;
const asEdgeLobbyRequest = _types_js__WEBPACK_IMPORTED_MODULE_0__.asEdgeLobbyRequest;
const asEdgeLoginDump = _types_js__WEBPACK_IMPORTED_MODULE_0__.asEdgeLoginDump;
const asEdgePendingVoucher = _types_js__WEBPACK_IMPORTED_MODULE_0__.asEdgePendingVoucher;
const asEdgeRepoDump = _types_js__WEBPACK_IMPORTED_MODULE_0__.asEdgeRepoDump;
const asEdgeSnrp = _types_js__WEBPACK_IMPORTED_MODULE_0__.asEdgeSnrp;
const asEdgeVoucherDump = _types_js__WEBPACK_IMPORTED_MODULE_0__.asEdgeVoucherDump;
const asLobbyPayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.asLobbyPayload;
const asLoginPayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.asLoginPayload;
const asLoginRequestBody = _types_js__WEBPACK_IMPORTED_MODULE_0__.asLoginRequestBody;
const asLoginResponseBody = _types_js__WEBPACK_IMPORTED_MODULE_0__.asLoginResponseBody;
const asMaybeChallengeError = _types_js__WEBPACK_IMPORTED_MODULE_0__.asMaybeChallengeError;
const asMaybeDustSpendError = _types_js__WEBPACK_IMPORTED_MODULE_0__.asMaybeDustSpendError;
const asMaybeInsufficientFundsError = _types_js__WEBPACK_IMPORTED_MODULE_0__.asMaybeInsufficientFundsError;
const asMaybeNetworkError = _types_js__WEBPACK_IMPORTED_MODULE_0__.asMaybeNetworkError;
const asMaybeNoAmountSpecifiedError = _types_js__WEBPACK_IMPORTED_MODULE_0__.asMaybeNoAmountSpecifiedError;
const asMaybeObsoleteApiError = _types_js__WEBPACK_IMPORTED_MODULE_0__.asMaybeObsoleteApiError;
const asMaybeOtpError = _types_js__WEBPACK_IMPORTED_MODULE_0__.asMaybeOtpError;
const asMaybePasswordError = _types_js__WEBPACK_IMPORTED_MODULE_0__.asMaybePasswordError;
const asMaybePendingFundsError = _types_js__WEBPACK_IMPORTED_MODULE_0__.asMaybePendingFundsError;
const asMaybeSameCurrencyError = _types_js__WEBPACK_IMPORTED_MODULE_0__.asMaybeSameCurrencyError;
const asMaybeSpendToSelfError = _types_js__WEBPACK_IMPORTED_MODULE_0__.asMaybeSpendToSelfError;
const asMaybeSwapAboveLimitError = _types_js__WEBPACK_IMPORTED_MODULE_0__.asMaybeSwapAboveLimitError;
const asMaybeSwapBelowLimitError = _types_js__WEBPACK_IMPORTED_MODULE_0__.asMaybeSwapBelowLimitError;
const asMaybeSwapCurrencyError = _types_js__WEBPACK_IMPORTED_MODULE_0__.asMaybeSwapCurrencyError;
const asMaybeSwapPermissionError = _types_js__WEBPACK_IMPORTED_MODULE_0__.asMaybeSwapPermissionError;
const asMaybeUsernameError = _types_js__WEBPACK_IMPORTED_MODULE_0__.asMaybeUsernameError;
const asMessagesPayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.asMessagesPayload;
const asOtpErrorPayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.asOtpErrorPayload;
const asOtpResetPayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.asOtpResetPayload;
const asPasswordErrorPayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.asPasswordErrorPayload;
const asRecovery2Auth = _types_js__WEBPACK_IMPORTED_MODULE_0__.asRecovery2Auth;
const asRecovery2InfoPayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.asRecovery2InfoPayload;
const asUsernameInfoPayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.asUsernameInfoPayload;
const wasChallengeErrorPayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.wasChallengeErrorPayload;
const wasChangeOtpPayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.wasChangeOtpPayload;
const wasChangePasswordPayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.wasChangePasswordPayload;
const wasChangePin2IdPayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.wasChangePin2IdPayload;
const wasChangePin2Payload = _types_js__WEBPACK_IMPORTED_MODULE_0__.wasChangePin2Payload;
const wasChangeRecovery2IdPayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.wasChangeRecovery2IdPayload;
const wasChangeRecovery2Payload = _types_js__WEBPACK_IMPORTED_MODULE_0__.wasChangeRecovery2Payload;
const wasChangeSecretPayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.wasChangeSecretPayload;
const wasChangeUsernamePayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.wasChangeUsernamePayload;
const wasChangeVouchersPayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.wasChangeVouchersPayload;
const wasCreateChallengePayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.wasCreateChallengePayload;
const wasCreateKeysPayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.wasCreateKeysPayload;
const wasCreateLoginPayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.wasCreateLoginPayload;
const wasEdgeBox = _types_js__WEBPACK_IMPORTED_MODULE_0__.wasEdgeBox;
const wasEdgeLobbyReply = _types_js__WEBPACK_IMPORTED_MODULE_0__.wasEdgeLobbyReply;
const wasEdgeLobbyRequest = _types_js__WEBPACK_IMPORTED_MODULE_0__.wasEdgeLobbyRequest;
const wasEdgeLoginDump = _types_js__WEBPACK_IMPORTED_MODULE_0__.wasEdgeLoginDump;
const wasEdgeRepoDump = _types_js__WEBPACK_IMPORTED_MODULE_0__.wasEdgeRepoDump;
const wasLobbyPayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.wasLobbyPayload;
const wasLoginPayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.wasLoginPayload;
const wasLoginRequestBody = _types_js__WEBPACK_IMPORTED_MODULE_0__.wasLoginRequestBody;
const wasLoginResponseBody = _types_js__WEBPACK_IMPORTED_MODULE_0__.wasLoginResponseBody;
const wasMessagesPayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.wasMessagesPayload;
const wasOtpErrorPayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.wasOtpErrorPayload;
const wasOtpResetPayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.wasOtpResetPayload;
const wasPasswordErrorPayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.wasPasswordErrorPayload;
const wasRecovery2InfoPayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.wasRecovery2InfoPayload;
const wasUsernameInfoPayload = _types_js__WEBPACK_IMPORTED_MODULE_0__.wasUsernameInfoPayload;


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			loaded: false,
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/node module decorator */
/******/ 	(() => {
/******/ 		__webpack_require__.nmd = (module) => {
/******/ 			module.paths = [];
/******/ 			if (!module.children) module.children = [];
/******/ 			return module;
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";
/*!**********************!*\
  !*** ./src/index.ts ***!
  \**********************/
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var regenerator_runtime_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! regenerator-runtime/runtime */ "./node_modules/regenerator-runtime/runtime.js");
/* harmony import */ var regenerator_runtime_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(regenerator_runtime_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _moneroPlugin__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./moneroPlugin */ "./src/moneroPlugin.ts");


var edgeCorePlugins = {
  monero: _moneroPlugin__WEBPACK_IMPORTED_MODULE_1__.makeMoneroPlugin
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (edgeCorePlugins);

if (typeof window !== 'undefined' && typeof window.addEdgeCorePlugins === 'function') {
  window.addEdgeCorePlugins(edgeCorePlugins);
}
})();

/******/ })()
;