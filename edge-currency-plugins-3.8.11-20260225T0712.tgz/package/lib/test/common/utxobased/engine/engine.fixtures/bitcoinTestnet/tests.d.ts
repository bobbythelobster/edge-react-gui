import { EdgeSpendInfo } from 'edge-core-js/types';
export interface SpendTests {
    [key: string]: EdgeSpendInfo;
}
declare const _default: {
    dummyDataPath: string;
    pluginId: string;
    WALLET_TYPE: string;
    WALLET_FORMAT: string;
    TX_AMOUNT: number;
    'Test Currency code': string;
    key: number[];
    xpub: string;
    'invalid key name': {
        type: string;
        keys: {
            bitcoinKeyz: string;
        };
    };
    'invalid wallet type': {
        type: string;
        keys: {
            bitcoinKeyz: string;
        };
    };
    'Make Engine': {
        network: string;
        id: string;
        userSettings: {
            enableOverrideServers: boolean;
            electrumServers: string[][];
        };
    };
    'Sign message': {
        success: {
            message: string;
            address: string;
            signature: string;
            publicKey: string;
        };
    };
    BlockHeight: {
        uri: string;
        defaultHeight: number;
    };
    ChangeSettings: {
        blockbookServers: never[];
        enableCustomServers: boolean;
    };
    'Address used from cache': {
        wrongFormat: string[];
        notInWallet: string[];
        empty: {
            'P2SH address': string;
        };
        nonEmpty: {
            'P2SH address 1': string;
            'P2SH address 2': string;
            'P2SH address 3': string;
        };
    };
    'Add Gap Limit': {
        derived: string[];
        future: never[];
    };
    Spend: SpendTests;
    InsufficientFundsError: SpendTests;
    Sweep: SpendTests;
};
export default _default;
