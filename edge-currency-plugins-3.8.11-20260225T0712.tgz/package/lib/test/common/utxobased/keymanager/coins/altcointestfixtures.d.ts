import { AddressTypeEnum, BIP43PurposeTypeEnum, ScriptTypeEnum } from '../../../../../src/common/utxobased/keymanager/keymanager';
interface SeedToXPrivTests {
    xpriv: string;
    type: BIP43PurposeTypeEnum;
}
interface XPrivToXPubTests {
    xpriv: string;
    xpub: string;
    type: BIP43PurposeTypeEnum;
}
interface WifToPrivateKeyTests {
    wifKey: string;
}
interface XPrivToWifTests {
    xpriv: string;
    wifKey: string;
    type: BIP43PurposeTypeEnum;
}
interface AddressToScriptPubkeyTests {
    extraMessage?: string;
    address: string;
    scriptPubkey: string;
}
interface XPubToPubkeyTests {
    xpub: string;
    type: BIP43PurposeTypeEnum;
    bip44ChangeIndex: 0 | 1;
    bip44AddressIndex: number;
    scriptType: ScriptTypeEnum;
    addressType: AddressTypeEnum;
    address: string;
    legacyAddress?: string;
}
interface SignMessageTests {
    wif: string;
    message: string;
    signature: string;
}
interface Coin {
    name: string;
    mnemonic: string;
    seedToXPrivTests: SeedToXPrivTests[];
    xprivToXPubTests: XPrivToXPubTests[];
    wifToPrivateKeyTests?: WifToPrivateKeyTests[];
    xprivToWifTests?: XPrivToWifTests[];
    xpubToPubkeyTests: XPubToPubkeyTests[];
    addressToScriptPubkeyTests: AddressToScriptPubkeyTests[];
    signMessageTests?: SignMessageTests[];
}
interface Fixture {
    coins: Coin[];
}
export declare const fixtures: Fixture;
export {};
