import { FixtureType } from '../common';
export declare const bitcoincash: FixtureType;
