import { FixtureType } from '../common';
export declare const smartcash: FixtureType;
