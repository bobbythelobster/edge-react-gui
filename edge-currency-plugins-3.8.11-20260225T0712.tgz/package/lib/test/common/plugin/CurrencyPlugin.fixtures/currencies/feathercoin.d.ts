import { FixtureType } from '../common';
export declare const feathercoin: FixtureType;
