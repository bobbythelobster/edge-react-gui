import { FixtureType } from '../common';
export declare const ecash: FixtureType;
