import { FixtureType } from '../common';
export declare const litecoin: FixtureType;
