import { EdgeEncodeUri, EdgeWalletInfo } from 'edge-core-js/types';
import { EncodeUriMetadata, ExtendedParseUri } from '../../../../src/common/plugin/types';
export interface FixtureType {
    pluginId: string;
    WALLET_TYPE: string;
    WALLET_FORMAT: string;
    'Test Currency code': string;
    key: number[];
    xpub: string;
    'invalid key name': EdgeWalletInfo;
    'invalid wallet type': EdgeWalletInfo;
    importKey: {
        validKeys: string[];
        invalidKeys: string[];
        unsupportedKeys: string[];
    };
    parseUri: {
        [testName: string]: [string, ExtendedParseUri] | [string];
    };
    encodeUri: {
        [testName: string]: [EdgeEncodeUri & EncodeUriMetadata, string] | [EdgeEncodeUri & EncodeUriMetadata];
    };
    getSplittableTypes?: {
        [walletFormat: string]: string[];
    };
}
export declare const key: number[];
export declare const mnemonics: string[];
export declare const airbitzSeeds: string[];
