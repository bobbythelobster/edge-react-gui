import { FixtureType } from './common';
export declare const fixtures: FixtureType[];
