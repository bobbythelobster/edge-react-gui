import { Disklet } from 'disklet';
import { EdgeIo, EdgeLog } from 'edge-core-js/types';
import { PluginInfo } from '../src/common/plugin/types';
import { EdgeCurrencyPluginNativeIo } from '../src/react-native';
export declare const makeFakePluginInfo: () => PluginInfo;
export declare const makeFakeLog: () => EdgeLog;
interface FakeIoConfig {
    disklet?: Disklet;
}
export declare const makeFakeIo: (config?: FakeIoConfig | undefined) => EdgeIo;
export declare const makeFakeNativeIo: () => {
    'edge-currency-plugins': EdgeCurrencyPluginNativeIo;
};
export {};
