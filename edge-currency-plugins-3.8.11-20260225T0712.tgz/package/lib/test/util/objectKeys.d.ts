interface ObjectType {
    [key: string]: unknown;
}
/**
 * A type safe way to get the keys of an object.
 */
export declare const objectKeys: <T extends ObjectType>(object: T) => (keyof T)[];
export {};
