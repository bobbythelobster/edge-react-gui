import { EdgeSpendInfo } from 'edge-core-js/types';
import { FeeInfo } from '../plugin/types';
declare type NetworkFeeOption = EdgeSpendInfo['networkFeeOption'];
/**
 * Calculate the sat/byte mining fee given an amount to spend and a SimpleFeeSettings object
 * @param nativeAmount
 * @param feeInfo
 * @param networkFeeOption
 * @param customNetworkFee
 * @returns {string}
 */
export declare const calcMinerFeePerByte: (nativeAmount: string, feeInfo: FeeInfo, networkFeeOption?: NetworkFeeOption, customNetworkFee?: string | undefined) => string;
export {};
