import { FeeRates } from '../plugin/types';
export declare const asMempoolSpaceFees: import("cleaners").ObjectCleaner<{
    fastestFee: number;
    halfHourFee: number;
    hourFee: number;
}>;
export declare const processMempoolSpaceFees: (fees: unknown) => FeeRates | null;
