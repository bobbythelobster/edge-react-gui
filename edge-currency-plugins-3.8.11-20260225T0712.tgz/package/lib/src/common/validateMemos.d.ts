import { EdgeCurrencyInfo, EdgeSpendInfo } from 'edge-core-js/types';
/**
 * Validates the memos on an spend request.
 * Throws an error if any of the memos are wrong.
 */
export declare function validateMemos(spendInfo: EdgeSpendInfo, currencyInfo: EdgeCurrencyInfo): void;
