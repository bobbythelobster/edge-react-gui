import { Disklet } from 'disklet';
import { Memlet } from 'memlet';
import { AddressByScriptPubkeyBaselet, LastUsedByFormatPathBaselet, ScriptPubkeyByPathBaselet, TxByIdBaselet, TxIdByBlockHeightBaselet, TxIdByDateBaselet, UtxoByIdBaselet, UtxoIdsByScriptPubkeyBaselet } from './Models/baselet';
interface MakeBaseletsConfig {
    storage: Disklet | Memlet;
}
declare type Executor<BaseletName extends keyof AllBaselets, T> = (tables: AllBaselets[BaseletName]) => Promise<T>;
interface AllBaselets {
    address: AddressBaselets;
    tx: TransactionBaselets;
    utxo: UtxoBaselets;
}
interface AddressBaselets {
    addressByScriptPubkey: AddressByScriptPubkeyBaselet;
    scriptPubkeyByPath: ScriptPubkeyByPathBaselet;
    lastUsedByFormatPath: LastUsedByFormatPathBaselet;
}
interface TransactionBaselets {
    txById: TxByIdBaselet;
    txIdsByBlockHeight: TxIdByBlockHeightBaselet;
    txIdsByDate: TxIdByDateBaselet;
}
interface UtxoBaselets {
    utxoById: UtxoByIdBaselet;
    utxoIdsByScriptPubkey: UtxoIdsByScriptPubkeyBaselet;
}
export interface Baselets {
    address: <T>(fn: Executor<'address', T>) => Promise<T>;
    tx: <T>(fn: Executor<'tx', T>) => Promise<T>;
    utxo: <T>(fn: Executor<'utxo', T>) => Promise<T>;
    all: AddressBaselets & TransactionBaselets & UtxoBaselets;
}
export declare const makeBaselets: (config: MakeBaseletsConfig) => Promise<Baselets>;
export {};
