import { CountBase, CountBaseOptions, HashBase, HashBaseOptions, RangeBase, RangeBaseOptions } from 'baselet';
import { ChangePath } from '../../../plugin/types';
import { AddressData, TransactionData, UtxoData } from '../types';
export declare const addressPathToPrefix: (path: ChangePath) => string;
export declare type ScriptPubkeyByPathBaselet = CountBase<string>;
export declare const scriptPubkeyByPathOptions: CountBaseOptions;
export declare type AddressByScriptPubkeyBaselet = HashBase<AddressData>;
export declare const addressByScriptPubkeyOptions: HashBaseOptions;
export declare type LastUsedByFormatPathBaselet = HashBase<number>;
export declare const lastUsedByFormatPathOptions: HashBaseOptions;
export interface TxIdByBlockHeight {
    txid: string;
    blockHeight: number;
}
export declare type TxIdByBlockHeightBaselet = RangeBase<TxIdByBlockHeight, 'blockHeight', 'txid'>;
export declare const txIdsByBlockHeightOptions: RangeBaseOptions<'blockHeight', 'txid'>;
export declare type TxByIdBaselet = HashBase<TransactionData>;
export declare const txByIdOptions: HashBaseOptions;
export interface TxIdByDate {
    txid: string;
    date: number;
}
export declare type TxIdByDateBaselet = RangeBase<TxIdByDate, 'date', 'txid'>;
export declare const txIdsByDateOptions: RangeBaseOptions<'date', 'txid'>;
export declare type UtxoByIdBaselet = HashBase<UtxoData>;
export declare const utxoByIdOptions: HashBaseOptions;
export declare type UtxoIdsByScriptPubkeyBaselet = HashBase<string[]>;
export declare const utxoIdsByScriptPubkeyOptions: HashBaseOptions;
