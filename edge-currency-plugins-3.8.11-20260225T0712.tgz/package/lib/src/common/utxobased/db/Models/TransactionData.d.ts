import { EdgeTransaction } from 'edge-core-js/types';
import { PluginInfo } from '../../../plugin/types';
import { UtxoWalletTools } from '../../engine/UtxoWalletTools';
import { DataLayer } from '../DataLayer';
import { TransactionData } from '../types';
export declare const fromEdgeTransaction: (tx: EdgeTransaction) => TransactionData;
interface ToEdgeTransactionArgs {
    walletId: string;
    tx: TransactionData;
    walletTools: UtxoWalletTools;
    dataLayer: DataLayer;
    pluginInfo: PluginInfo;
}
export declare const toEdgeTransaction: (args: ToEdgeTransactionArgs) => Promise<EdgeTransaction>;
export {};
