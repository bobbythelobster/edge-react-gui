import { Disklet } from 'disklet';
import { EdgeGetTransactionsOptions } from 'edge-core-js/types';
import { AddressPath, ChangePath } from '../../plugin/types';
import { AddressData, TransactionData, UtxoData } from './types';
interface DataLayerConfig {
    disklet: Disklet;
}
interface SaveTransactionArgs {
    tx: TransactionData;
    scriptPubkeys?: string[];
}
interface FetchTransactionArgs {
    blockHeight?: number;
    blockHeightMax?: number;
    txId?: string;
    options?: EdgeGetTransactionsOptions & {
        endDate?: Date;
        startDate?: Date;
        startEntries?: number;
        startIndex?: number;
    };
}
interface FetchUtxosArgs {
    utxoIds?: string[];
    scriptPubkey?: string;
}
interface DumpDataReturn {
    databaseName: string;
    data: unknown;
}
/**
 * The Data Access Layer for the UTXO-based wallet engine.
 *
 * It provides all the methods necessary to interact with underlying
 * database/storage mechanism.
 */
export interface DataLayer {
    clearAll: () => Promise<void>;
    dumpData: () => Promise<DumpDataReturn[]>;
    saveUtxo: (utxo: UtxoData) => Promise<void>;
    removeUtxos: (utxoIds: string[]) => Promise<void>;
    fetchUtxos: (args: FetchUtxosArgs) => Promise<Array<UtxoData | undefined>>;
    saveTransaction: (args: SaveTransactionArgs) => Promise<TransactionData>;
    numTransactions: () => number;
    removeTransaction: (txId: string) => Promise<void>;
    fetchTransactions: (args: FetchTransactionArgs) => Promise<Array<TransactionData | undefined>>;
    saveAddress: (args: AddressData) => Promise<void>;
    numAddressesByFormatPath: (path: ChangePath) => number;
    lastUsedIndexByFormatPath: (path: ChangePath) => Promise<number>;
    fetchAddress: (args: AddressPath | string) => Promise<AddressData | undefined>;
}
export declare function makeDataLayer(config: DataLayerConfig): Promise<DataLayer>;
export {};
