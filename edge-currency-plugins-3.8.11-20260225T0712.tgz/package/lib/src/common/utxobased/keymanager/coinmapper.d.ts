import { CoinInfo } from './../../plugin/types';
export declare function getCoinFromString(coinName: string): CoinInfo;
