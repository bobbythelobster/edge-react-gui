import { UtxoPickingFunc } from './utxopicker/types';
export * from './utxopicker/types';
export interface UtxoPicker {
    forceUseUtxo: UtxoPickingFunc;
    subtractFee: UtxoPickingFunc;
    accumulative: UtxoPickingFunc;
}
export declare const utxoPicker: UtxoPicker;
