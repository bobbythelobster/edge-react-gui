import { EdgeLog, EdgeMemo } from 'edge-core-js/types';
import { ChangePath, FeeInfo } from '../../plugin/types';
import { UtxoData } from '../db/types';
import { ScriptTemplate, ScriptTemplates } from '../info/scriptTemplates/types';
import * as utxopicker from './utxopicker';
export declare enum BIP43PurposeTypeEnum {
    Airbitz = "airbitz",
    Legacy = "legacy",
    Segwit = "segwit",
    WrappedSegwit = "wrappedSegwit",
    ReplayProtection = "replayProtection"
}
export declare enum AddressTypeEnum {
    p2pkh = "p2pkh",
    p2sh = "p2sh",
    p2wpkh = "p2wpkh",
    p2wsh = "p2wsh",
    p2tr = "p2tr"
}
export declare enum ScriptTypeEnum {
    p2wpkh = "p2wpkh",
    p2wpkhp2sh = "p2wpkhp2sh",
    p2wsh = "p2wsh",
    p2pk = "p2pk",
    p2pkh = "p2pkh",
    p2sh = "p2sh",
    p2tr = "p2tr",
    replayProtection = "replayprotection",
    replayProtectionP2SH = "replayprotectionp2sh"
}
export declare const asScriptTypeEnum: import("cleaners").Cleaner<ScriptTypeEnum>;
export declare enum TransactionInputTypeEnum {
    Legacy = "legacy",
    Segwit = "segwit"
}
export interface VerifyAddressArgs {
    address: string;
    coin: string;
}
export declare enum VerifyAddressEnum {
    good = "good",
    legacy = "legacy",
    bad = "bad"
}
export interface SeedOrMnemonicToXPrivArgs {
    seed: string;
    type: BIP43PurposeTypeEnum;
    coinType?: number;
    account?: number;
    coin: string;
}
export interface XPrivToXPubArgs {
    xpriv: string;
    type: BIP43PurposeTypeEnum;
    coin: string;
}
export interface XPrivToPrivateKeyArgs {
    xpriv: string;
    type: BIP43PurposeTypeEnum;
    bip44ChangeIndex: number;
    bip44AddressIndex: number;
    coin: string;
}
export interface XPubToPubkeyArgs {
    xpub: string;
    type: BIP43PurposeTypeEnum;
    bip44ChangeIndex: number;
    bip44AddressIndex: number;
    coin: string;
}
export interface AddressToScriptPubkeyArgs {
    address: string;
    addressType?: AddressTypeEnum;
    coin: string;
}
export interface PubkeyToScriptPubkeyArgs {
    pubkey: string;
    scriptTemplates?: ScriptTemplates;
    scriptType: ScriptTypeEnum;
}
export interface PubkeyToScriptPubkeyReturn {
    scriptPubkey: string;
    redeemScript?: string;
}
export interface ScriptPubkeyToAddressArgs {
    scriptPubkey: string;
    addressType: AddressTypeEnum;
    coin: string;
    redeemScript?: string;
    includeCashaddrPrefix?: boolean;
}
export interface ScriptPubkeyToAddressReturn {
    address: string;
    legacyAddress: string;
}
export interface ScriptPubkeyToScriptHashArgs {
    scriptPubkey: string;
    scriptType: ScriptTypeEnum;
    coin: string;
}
export interface ScriptPubkeyToP2SHArgs {
    scriptPubkey: string;
    coin?: string;
}
export interface ScriptPubkeyToP2SHReturn {
    scriptPubkey: string;
    redeemScript: string;
    address?: string;
}
export interface WIFToPrivateKeyEncodingArgs {
    wifKey: string;
    coin: string;
}
export interface PrivateKeyEncoding {
    hex: string;
    compressed: boolean;
}
export interface PrivateKeyToWIFArgs {
    privateKey: string;
    coin: string;
}
export interface TxInput {
    type: TransactionInputTypeEnum;
    prevTxid: string;
    index: number;
    prevTx?: string;
    prevScriptPubkey?: string;
    redeemScript?: string;
    value?: number;
}
export interface TxOutput {
    scriptPubkey: string;
    amount: number;
}
export interface MakeTxArgs {
    forceUseUtxo: UtxoData[];
    utxos: UtxoData[];
    targets: MakeTxTarget[];
    memos: EdgeMemo[];
    feeRate: number;
    enableRbf: boolean;
    coin: string;
    currencyCode: string;
    freshChangeAddress: string;
    subtractFee?: boolean;
    log?: EdgeLog;
    outputSort: 'bip69' | 'targets';
    memoIndex?: number;
}
export interface MakeTxTarget {
    address?: string;
    scriptPubkey?: string;
    value?: number;
}
export interface MakeTxReturn extends Required<utxopicker.UtxoPickerResult> {
    hex: string;
    psbtBase64: string;
}
export interface SignTxArgs {
    coin: string;
    feeInfo: FeeInfo;
    psbtBase64: string;
    privateKeyEncodings: PrivateKeyEncoding[];
}
interface SignTxReturn {
    id: string;
    hex: string;
}
export interface Bip32 {
    public: number;
    private: number;
}
export declare function bip43PurposeNumberToTypeEnum(num: number): BIP43PurposeTypeEnum;
export interface SelectedCoinPrefixes {
    messagePrefix: string;
    wif: number;
    legacyXPriv: number;
    legacyXPub: number;
    wrappedSegwitXPriv?: number;
    wrappedSegwitXPub?: number;
    segwitXPriv?: number;
    segwitXPub?: number;
    pubkeyHash: number;
    scriptHash: number;
    bech32?: string;
    cashaddr?: string;
}
export declare const verifyAddress: (args: VerifyAddressArgs) => VerifyAddressEnum;
export declare const getAddressTypeFromAddress: (address: string, coinName: string) => AddressTypeEnum;
export declare function seedOrMnemonicToXPriv(args: SeedOrMnemonicToXPrivArgs): string;
export declare const xprivToXPub: (args: XPrivToXPubArgs) => string;
export declare function derivationLevelScriptHash(scriptTemplate: ScriptTemplate): number;
export declare const isPathUsingDerivationLevelScriptHash: (scriptTemplate: ScriptTemplate, path: ChangePath) => boolean;
export declare const xpubToPubkey: (args: XPubToPubkeyArgs) => string;
export declare const addressToScriptPubkey: (args: AddressToScriptPubkeyArgs) => string;
export declare function scriptPubkeyToAddress(args: ScriptPubkeyToAddressArgs): ScriptPubkeyToAddressReturn;
export declare function scriptPubkeyToScriptHash(args: ScriptPubkeyToScriptHashArgs): string;
export declare function scriptPubkeyToP2SH(args: ScriptPubkeyToP2SHArgs): ScriptPubkeyToP2SHReturn;
export declare function pubkeyToScriptPubkey(args: PubkeyToScriptPubkeyArgs): PubkeyToScriptPubkeyReturn;
export declare const toNewFormat: (address: string, coinName: string) => string;
export declare const xprivToPrivateKey: (args: XPrivToPrivateKeyArgs) => string;
export declare function privateKeyToWIF(args: PrivateKeyToWIFArgs): string;
export declare const wifToPrivateKeyEncoding: (args: WIFToPrivateKeyEncodingArgs) => PrivateKeyEncoding;
export declare function privateKeyEncodingToPubkey(privateKeyEncoding: PrivateKeyEncoding): string;
export declare function signMessageBase64(message: string, privateKey: string): string;
export declare function makeTx(args: MakeTxArgs): MakeTxReturn;
export declare function signTx(args: SignTxArgs): Promise<SignTxReturn>;
export {};
