/// <reference types="node" />
import { Buffer } from 'buffer';
export declare enum CashaddrTypeEnum {
    pubkeyhash = "pubkeyhash",
    scripthash = "scripthash"
}
export interface BitcoinCashScriptHash {
    scriptHash: Buffer;
    type: CashaddrTypeEnum;
}
export declare const hashToCashAddress: (scriptHash: string, type: CashaddrTypeEnum, cashAddrPrefix: string, includePrefix?: boolean) => string;
export declare const cashAddressToHash: (address: string, cashAddrPrefixes: string[]) => BitcoinCashScriptHash;
