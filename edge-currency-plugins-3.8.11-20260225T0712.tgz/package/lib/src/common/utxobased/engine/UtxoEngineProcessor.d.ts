/// <reference types="node" />
import { EdgeFreshAddress, EdgeIo, EdgeLog, EdgeTransaction } from 'edge-core-js/types';
import { EngineEmitter } from '../../plugin/EngineEmitter';
import { ChangePath, CurrencyFormat, EngineConfig, PluginInfo } from '../../plugin/types';
import { DataLayer } from '../db/DataLayer';
import { AddressData, UtxoData } from '../db/types';
import { SafeWalletInfo } from '../keymanager/cleaners';
import { AddressResponse, AddressUtxosResponse, BlockbookAccountUtxo, TransactionResponse } from '../network/blockbookApi';
import { WsTask } from '../network/Socket';
import AwaitLock from './await-lock';
import { ServerStates } from './ServerStates';
import { UtxoWalletTools } from './UtxoWalletTools';
export interface UtxoEngineProcessor {
    processedPercent: number;
    start: () => Promise<void>;
    stop: () => Promise<void>;
    deriveScriptAddress: (script: string) => Promise<EdgeFreshAddress>;
    getFreshAddress: (params: {
        branch?: number;
        forceIndex?: number;
    }) => Promise<EdgeFreshAddress>;
    addGapLimitAddresses: (addresses: string[]) => Promise<void>;
    broadcastTx: (transaction: EdgeTransaction) => Promise<string>;
    refillServers: () => void;
    getServerList: () => string[];
    setServerList: (serverList: string[]) => void;
    loadWifs: (wifs: string[]) => Promise<void>;
    processUtxos: (utxos: UtxoData[]) => Promise<void>;
}
export interface UtxoEngineProcessorConfig extends EngineConfig {
    dataLayer: DataLayer;
    seenTxCheckpoint: (value?: string) => string | undefined;
    walletTools: UtxoWalletTools;
    walletInfo: SafeWalletInfo;
}
export declare function makeUtxoEngineProcessor(config: UtxoEngineProcessorConfig): UtxoEngineProcessor;
interface CommonParams {
    pluginInfo: PluginInfo;
    walletInfo: SafeWalletInfo;
    walletTools: UtxoWalletTools;
    dataLayer: DataLayer;
    emitter: EngineEmitter;
    taskCache: TaskCache;
    pendingTimeouts: Set<NodeJS.Timeout>;
    updateProgressRatio: () => void;
    updateSeenTxCheckpoint: () => void;
    io: EdgeIo;
    log: EdgeLog;
    maxSeenTxBlockHeight: number;
    seenTxCheckpoint: (value?: string) => string | undefined;
    serverStates: ServerStates;
    walletFormats: CurrencyFormat[];
    lock: AwaitLock;
}
interface TaskCache {
    readonly addressForTransactionsCache: AddressForTransactionsCache;
    readonly addressForUtxosCache: AddressForUtxosCache;
    readonly addressSubscribeCache: AddressSubscribeCache;
    readonly blockbookUtxoCache: BlockbookUtxoCache;
    readonly dataLayerUtxoCache: DataLayerUtxoCache;
    readonly transactionSpecificUpdateCache: TransactionSpecificUpdateCache;
    readonly transactionUpdateCache: TransactionUpdateCache;
}
interface AddressForTransactionsCache {
    [key: string]: {
        processing: boolean;
        path: ChangePath;
        page: number;
        blockHeight: number;
    };
}
interface AddressForUtxosCache {
    [key: string]: {
        processing: boolean;
        path: ChangePath;
    };
}
interface AddressSubscribeCache {
    [key: string]: {
        processing: boolean;
        path: ChangePath;
    };
}
interface DataLayerUtxoCache {
    [key: string]: {
        processing: boolean;
        full: boolean;
        utxos: UtxoData[];
        path: ChangePath;
    };
}
interface BlockbookUtxoCache {
    [key: string]: {
        blockbookUtxo: BlockbookAccountUtxo;
        processing: boolean;
        path: ChangePath;
        address: AddressData;
        requiredCount: number;
    };
}
interface TransactionSpecificUpdateCache {
    [key: string]: {
        processing: boolean;
    };
}
interface TransactionUpdateCache {
    [key: string]: {
        processing: boolean;
    };
}
/**
 * The pickNextTask generator is responsible for selecting the next WsTask
 * to be done by the network layer. It will yield WsTasks or booleans for early
 * exit, and it will return a boolean when it's done.
 */
declare type PickNextTaskGenerator = AsyncGenerator<boolean | WsTask<unknown>, boolean, AddressUtxosResponse & AddressResponse & TransactionResponse>;
export declare function pickNextTask(common: CommonParams, serverUri: string): PickNextTaskGenerator;
export {};
