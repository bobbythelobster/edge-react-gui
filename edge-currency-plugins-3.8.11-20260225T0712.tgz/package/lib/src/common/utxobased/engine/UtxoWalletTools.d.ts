import { AddressPath, ChangePath, CurrencyFormat, PluginInfo } from '../../plugin/types';
import { ScriptTemplate } from '../info/scriptTemplates/types';
import { PublicKey } from '../keymanager/cleaners';
import { PrivateKeyEncoding } from '../keymanager/keymanager';
import { CurrencyFormatKeys } from './utils';
export interface WalletToolsConfig {
    pluginInfo: PluginInfo;
    publicKey: PublicKey;
}
export interface UtxoWalletTools {
    getPubkey: (args: AddressPath) => string;
    getScriptPubkey: (args: AddressPath) => ScriptPubkeyReturn;
    getScriptPubkeyFromWif: (wif: string, format: CurrencyFormat) => ScriptPubkeyReturn;
    getAddress: (args: AddressPath) => AddressReturn;
    addressToScriptPubkey: (address: string) => string;
    scriptPubkeyToAddress: (args: ScriptPubkeyToAddressArgs) => AddressReturn;
    getPrivateKey: (args: GetPrivateKeyArgs) => string;
    getPrivateKeyEncodingFromWif: (wif: string) => PrivateKeyEncoding;
    getScriptAddress: (args: GetScriptAddressArgs) => GetScriptAddressReturn;
    signMessageBase64: (args: SignMessageArgs) => string;
}
interface ScriptPubkeyReturn {
    scriptPubkey: string;
    redeemScript?: string;
}
interface ScriptPubkeyToAddressArgs {
    changePath: ChangePath;
    scriptPubkey: string;
}
interface GetPrivateKeyArgs {
    path: AddressPath;
    xprivKeys: CurrencyFormatKeys;
}
interface GetScriptAddressArgs {
    path: AddressPath;
    scriptTemplate: ScriptTemplate;
}
interface AddressReturn {
    address: string;
    legacyAddress: string;
}
interface GetScriptAddressReturn {
    address: string;
    scriptPubkey: string;
    redeemScript: string;
}
interface SignMessageArgs {
    path: AddressPath;
    message: string;
    xprivKeys: CurrencyFormatKeys;
}
export declare function makeUtxoWalletTools(config: WalletToolsConfig): UtxoWalletTools;
export {};
