import { EdgeIo, EdgeLog, EdgeTransaction } from 'edge-core-js/types';
import { EngineEmitter } from '../../plugin/EngineEmitter';
import { PluginState } from '../../plugin/PluginState';
import { PluginInfo } from '../../plugin/types';
import { SafeWalletInfo } from '../keymanager/cleaners';
import { Blockbook } from '../network/Blockbook';
import { AddressResponse, AddressUtxosResponse, BlockbookTransaction } from '../network/blockbookApi';
import Deferred from '../network/Deferred';
import { WsTask, WsTaskGenerator } from '../network/Socket';
import { UtxoInitOptions } from './types';
export interface ServerState {
    blockbook: Blockbook;
    blockSubscriptionStatus: 'unsubscribed' | 'subscribing' | 'subscribed';
    blockHeight: number;
    txids: Set<string>;
    addresses: Set<string>;
}
interface ServerStateConfig {
    engineEmitter: EngineEmitter;
    initOptions: UtxoInitOptions;
    io: EdgeIo;
    log: EdgeLog;
    pluginInfo: PluginInfo;
    pluginState: PluginState;
    walletInfo: SafeWalletInfo;
}
export interface ServerStates {
    setPickNextTaskCB: (callback: (uri: string) => AsyncGenerator<WsTask<unknown> | boolean>) => void;
    stop: () => void;
    serverCanGetTx: (uri: string, txid: string) => boolean;
    serverCanGetAddress: (uri: string, address: string) => boolean;
    serverIsAwareOfAddress: (uri: string, address: string) => boolean;
    getServerState: (uri: string) => ServerState | undefined;
    refillServers: () => void;
    getServerList: () => string[];
    setServerList: (updatedServerList: string[]) => void;
    broadcastTx: (transaction: EdgeTransaction) => Promise<string>;
    watchAddresses: (uri: string, addresses: string[], deferredAddressSub?: Deferred<unknown>) => void;
    watchBlocks: (uri: string) => void;
    getBlockHeight: (uri: string) => number;
    addressQueryTask: (serverUri: string, address: string, params: {
        lastQueriedBlockHeight: number;
        page: number;
    }) => WsTaskGenerator<AddressResponse>;
    transactionQueryTask: (serverUri: string, txId: string) => WsTaskGenerator<BlockbookTransaction>;
    transactionSpecialQueryTask: (serverUri: string, txId: string) => WsTaskGenerator<unknown>;
    utxoListQueryTask: (serverUri: string, address: string) => WsTaskGenerator<AddressUtxosResponse>;
}
export declare function makeServerStates(config: ServerStateConfig): ServerStates;
export {};
