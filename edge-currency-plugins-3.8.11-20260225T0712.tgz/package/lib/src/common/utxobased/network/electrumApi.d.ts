import { Cleaner } from 'cleaners';
/**
 * Websocket Task
 */
export interface ElectrumTask<T> {
    method: string;
    params: unknown;
    cleaner: Cleaner<T>;
}
export interface ElectrumUtxo {
    tx_pos: number;
    value: number;
    tx_hash: string;
    height: number;
}
export declare const asElectrumUtxo: Cleaner<ElectrumUtxo>;
export interface ElectrumTransaction {
    blockhash: string;
    blocktime: number;
    confirmations: number;
    hash: string;
    hex: string;
    locktime: number;
    size: number;
    time: number;
    txid: string;
    version: number;
    vin: Array<{
        scriptSig: {
            asm: string;
            hex: string;
        };
        sequence: number;
        txid: string;
        vout: number;
    }>;
    vout: Array<{
        n: number;
        scriptPubKey: {
            addresses: string[];
            asm: string;
            hex: string;
            reqSigs: number;
            type: string;
        };
        value: number;
    }>;
}
export declare const asElectrumTransaction: (asAddress?: Cleaner<string>) => Cleaner<ElectrumTransaction>;
/**
 * Error Response
 */
export declare type ElectrumErrorResponse = ReturnType<typeof asElectrumErrorResponse>;
export declare const asElectrumErrorResponse: import("cleaners").ObjectCleaner<{
    error: {
        message: any;
    };
}>;
/**
 * Electrum Response Generic
 */
export declare type ElectrumResponse<T> = T;
export declare const asElectrumResponse: <T>(asT: Cleaner<T>) => Cleaner<T>;
/**
 * Ping Message
 */
export declare const pingMessage: () => ElectrumTask<PingResponse>;
export declare type PingResponse = ReturnType<typeof asPingResponse>;
export declare const asPingResponse: Cleaner<undefined>;
/**
 * List Unspent (Get UTXOs)
 */
export declare const listUnspentMessage: (scriptHash: string) => ElectrumTask<ListUnspentResponse>;
export declare type ListUnspentResponse = ElectrumUtxo[];
export declare const asListUnspentResponse: Cleaner<ListUnspentResponse>;
/**
 * Get Address Transactions
 */
export declare const addressTransactionsMessage: (scriptHash: string) => ElectrumTask<AddressTransactionsResponse>;
export declare type AddressTransactionsResponse = ReturnType<typeof asAddressTransactionsResponse>;
export declare const asAddressTransactionsResponse: Cleaner<{
    height: number;
    tx_hash: string;
}[]>;
/**
 * Get Transaction
 */
export declare const transactionMessage: (txHash: string, asAddress?: Cleaner<string>) => ElectrumTask<TransactionResponse>;
export declare type TransactionResponse = ElectrumTransaction;
export declare const asTransactionResponse: (asAddress?: Cleaner<string>) => Cleaner<ElectrumTransaction>;
