import { Cleaner } from 'cleaners';
import { EdgeLog, EdgeTransaction } from 'edge-core-js/types';
import { EngineEmitter } from '../../plugin/EngineEmitter';
import { UtxoInitOptions } from '../engine/types';
import { AddressResponse, AddresssMessageParams, AddressUtxosResponse, BlockbookTask, BlockbookTransaction, BroadcastTxResponse, InfoResponse, SubscribeAddressResponse, TransactionResponse } from './blockbookApi';
import Deferred from './Deferred';
import { TaskGeneratorFn, WsResponse, WsTaskGenerator } from './Socket';
import { SocketEmitter } from './SocketEmitter';
export declare type WatchAddressesCB = (response: SubscribeAddressResponse) => void | Promise<void>;
export declare type WatchBlocksCB = () => void | Promise<void>;
export interface Blockbook {
    isConnected: boolean;
    broadcastTx: (transaction: EdgeTransaction) => Promise<BroadcastTxResponse>;
    connect: () => Promise<void>;
    disconnect: () => Promise<void>;
    fetchAddress: (address: string, params?: AddresssMessageParams) => Promise<AddressResponse>;
    fetchAddressUtxos: (account: string) => Promise<AddressUtxosResponse>;
    fetchInfo: () => Promise<InfoResponse>;
    fetchTransaction: (hash: string) => Promise<TransactionResponse>;
    watchAddresses: (addresses: string[], deferredAddressSub: Deferred<unknown>) => void;
    watchBlocks: (deferredBlockSub: Deferred<unknown>) => void;
    promisifyWsMessage: <T>(message: BlockbookTask<T>) => Promise<T>;
    addressQueryTask: (address: string, params: {
        asBlockbookAddress?: Cleaner<string> | undefined;
        lastQueriedBlockHeight: number;
        page: number;
    }) => WsTaskGenerator<AddressResponse>;
    transactionQueryTask: (txId: string) => WsTaskGenerator<BlockbookTransaction>;
    transactionSpecialQueryTask: (txId: string) => WsTaskGenerator<unknown>;
    utxoListQueryTask: (address: string, params: {
        asBlockbookAddress?: Cleaner<string> | undefined;
    }) => WsTaskGenerator<AddressUtxosResponse>;
}
interface BlockbookConfig {
    asAddress?: Cleaner<string>;
    asResponse?: Cleaner<WsResponse>;
    connectionUri: string;
    engineEmitter: EngineEmitter;
    initOptions: UtxoInitOptions;
    log: EdgeLog;
    taskGeneratorFn: TaskGeneratorFn;
    ping?: () => Promise<void>;
    socketEmitter: SocketEmitter;
    walletId: string;
}
export declare function makeBlockbook(config: BlockbookConfig): Blockbook;
export {};
