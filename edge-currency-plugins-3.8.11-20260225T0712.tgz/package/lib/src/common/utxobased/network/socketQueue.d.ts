interface UpdateQueue {
    id: string;
    action?: string;
    updateFunc: () => void;
}
export declare function pushUpdate(update: UpdateQueue): void;
export declare function removeIdFromQueue(id: string): void;
export {};
