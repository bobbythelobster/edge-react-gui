import { InnerSocket, InnerSocketCallbacks } from './types';
export declare function setupBrowser(uri: string, callbacks: InnerSocketCallbacks): InnerSocket;
