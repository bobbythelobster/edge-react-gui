import { InnerSocket, InnerSocketCallbacks } from './types';
export declare function setupWS(uri: string, callbacks: InnerSocketCallbacks): InnerSocket;
