import { Cleaner } from 'cleaners';
import { EdgeLog } from 'edge-core-js/types';
import { UtxoInitOptions } from '../engine/types';
import Deferred from './Deferred';
import { SocketEmitter } from './SocketEmitter';
import { ReadyState } from './types';
export declare type OnFailHandler = (error: Error) => void;
export interface WsTask<T> {
    method: string;
    params: unknown;
    cleaner?: Cleaner<T>;
}
export declare type WsTaskGenerator<T> = Generator<WsTask<T>, T, T>;
export declare type WsTaskAsyncGenerator<T> = AsyncGenerator<WsTask<T> | boolean, boolean, T>;
export interface WsSubscription<T> {
    method: string;
    params: unknown;
    cb: (value: T) => void;
    subscribed: boolean;
    cleaner: Cleaner<T>;
    deferred: Deferred<unknown>;
}
export interface Socket {
    readyState: ReadyState;
    connect: () => Promise<void>;
    disconnect: () => void;
    submitTask: <T>(task: WsTask<T>, generator: WsTaskAsyncGenerator<T>) => void;
    subscribe: <T>(subscription: WsSubscription<T>) => void;
    isConnected: () => boolean;
}
export declare type TaskGeneratorFn = (uri: string) => WsTaskAsyncGenerator<unknown>;
interface SocketConfig {
    asResponse?: Cleaner<WsResponse>;
    emitter: SocketEmitter;
    healthCheck: () => Promise<void>;
    initOptions: UtxoInitOptions;
    log: EdgeLog;
    queueSize?: number;
    taskGeneratorFn: TaskGeneratorFn;
    timeout?: number;
    walletId: string;
}
export declare type WsResponse = WsResponseMessage[];
export interface WsResponseMessage {
    id: string;
    data?: unknown;
    error?: {
        message: string;
    } | {
        connected: string;
    };
}
export declare function makeSocket(uri: string, config: SocketConfig): Socket;
export {};
