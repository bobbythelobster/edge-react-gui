import { UtxoPicker } from '../../keymanager/utxopicker';
export declare function makeDogeUtxoPicker(): UtxoPicker;
