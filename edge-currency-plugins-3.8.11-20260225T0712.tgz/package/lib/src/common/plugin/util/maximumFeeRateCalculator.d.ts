import { EdgeCurrencyInfo } from 'edge-core-js/types';
/**
 * Calculates a maximum fee rate of 1 USD per vByte given a USD exchange rate
 * (usdPrice).
 */
export declare const maximumFeeRateCalculator: (currencyInfo: EdgeCurrencyInfo, usdPrice: number) => string | undefined;
