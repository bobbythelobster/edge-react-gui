import { EdgeCurrencyTools, EdgeIo } from 'edge-core-js/types';
import { PluginInfo } from './types';
/**
 * The core currency plugin.
 * Provides information about the currency,
 * as well as generic (non-wallet) functionality.
 */
export declare function makeCurrencyTools(io: EdgeIo, pluginInfo: PluginInfo): EdgeCurrencyTools;
