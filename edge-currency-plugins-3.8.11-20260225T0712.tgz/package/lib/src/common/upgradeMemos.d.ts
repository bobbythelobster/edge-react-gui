import { EdgeCurrencyInfo, EdgeSpendInfo } from 'edge-core-js/types';
/**
 * Upgrades the memo fields inside an EdgeSpendTarget,
 * since we need to be runtime-compatible with legacy core versions.
 */
export declare function upgradeMemos(spendInfo: EdgeSpendInfo, currencyInfo: EdgeCurrencyInfo): EdgeSpendInfo;
