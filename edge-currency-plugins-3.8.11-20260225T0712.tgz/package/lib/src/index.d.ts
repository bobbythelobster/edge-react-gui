import { EdgeCorePlugins } from 'edge-core-js/types';
declare const plugins: EdgeCorePlugins;
declare global {
    interface Window {
        addEdgeCorePlugins?: (plugins: EdgeCorePlugins) => void;
    }
}
export default plugins;
